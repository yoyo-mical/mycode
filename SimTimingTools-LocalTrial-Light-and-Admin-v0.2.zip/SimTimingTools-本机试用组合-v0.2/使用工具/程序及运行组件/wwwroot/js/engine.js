// =====================================================================
// Sim-Timing-Generator 2026 —— 计算引擎（等价翻译 modInitialize + clsSignalCKV）
// =====================================================================
window.STGEngine = (function () {
  'use strict';

  var CFG = window.STG_CONFIG;

  function num(v) { var n = parseFloat(v); return isNaN(n) ? 0 : n; }
  function round6(value) { return Math.round(value*1e6)/1e6; }
  function int(v) { var n = parseInt(v, 10); return isNaN(n) ? 0 : n; }

  // 向波形 Map 写入一个 (时间,电压) 点（同时间去重、保留最后值，等价 Scripting.Dictionary）
  function putPoint(map, t, v) {
    var rt = Math.round(t * 1e6) / 1e6;
    var rv = Math.round(v * 1e6) / 1e6;
    map.set(rt, rv);
  }

  // 波形 Map → 按时间升序的 [t,v] 数组
  function toArray(map) {
    var keys = Array.from(map.keys()).sort(function (a, b) { return a - b; });
    return keys.map(function (k) { return [k, map.get(k)]; });
  }

  // 电压字符串 → 数值
  function voltage(strV, vals) { return CFG.resolveVoltage(strV, vals); }

  // =====================================================================
  // 时间轴初始化（等价 modInitialize.InitTimeLine：7 时间段 + Touch/preCharge）
  // =====================================================================
  function initTimeline(vals) {
    var n = {};
    var delay = num(vals.delay);
    var STVtCKV = num(vals.STVtCKV);
    var CKV_period = num(vals.CKV_period);
    var dumHeader_n = int(vals.dumHeader_n);
    var dumTail_m = int(vals.dumTail_m);
    var SimCol = int(vals.DisplayRow);
    if (SimCol < 1) throw new Error("DisplayRow 必须为正整数。");
    var BlankingTime = num(vals.BlankingTime);

    // ① frameDelay
    n.frameDelay_start = 0;
    n.frameDelay_end = delay;

    // ② dumHeader
    n.STVstart = delay;
    n.CKVstart = delay + num(vals.STVtr) + STVtCKV;
    var dumHeader_line = [];
    for (var i = 1; i <= dumHeader_n; i++) {
      dumHeader_line[i] = n.CKVstart + i * CKV_period;
    }
    n.dumHeader_start = delay;
    n.dumHeader_end = n.CKVstart + dumHeader_n * CKV_period;

    // ③ display
    var display_line = [];
    // display_line 保存各行结束边界，首行起点直接接 dumHeader 结束。
    display_line[1] = n.dumHeader_end + CKV_period;
    for (var i2 = 2; i2 <= SimCol; i2++) display_line[i2] = display_line[i2 - 1] + CKV_period;
    n.display_start = n.dumHeader_end;
    n.display_end = display_line[SimCol];

    // ④ dumTail
    var dumTail_line = [];
    var dumTail_start = display_line[SimCol];
    for (var i3 = 1; i3 <= dumTail_m; i3++) dumTail_line[i3] = dumTail_start + i3 * CKV_period;
    n.dumTail_start = dumTail_start;
    n.dumTail_end = dumTail_line[dumTail_m];

    // ⑤ frameEnd
    n.FrameEnd_start = n.dumTail_end;
    n.FrameEnd_end = n.dumTail_end + BlankingTime;

    // ⑥ Touch 插入
    var IsTouchExist = (String(vals.isTpExist).toUpperCase() === 'Y');
    var TPstart = int(vals.TPstart);
    var pos = String(vals.TpPosition || 'displayLine').toUpperCase();
    var touch_start_time = 0, touch_end_time = 0, touchOffset = 0;

    if (IsTouchExist && TPstart > 0) {
      if (pos === 'DISPLAYLINE') {
        if (TPstart >= SimCol) TPstart = SimCol;
        touch_start_time = display_line[TPstart];
      } else if (pos === 'DUMHEADER') {
        if (TPstart >= dumHeader_n) TPstart = dumHeader_n;
        touch_start_time = dumHeader_line[TPstart];
      } else if (pos === 'DUMTAIL') {
        if (TPstart >= dumTail_m) TPstart = dumTail_m;
        touch_start_time = dumTail_line[TPstart];
      } else {
        IsTouchExist = false;
      }
    } else {
      IsTouchExist = false;
    }

    if (IsTouchExist) {
      touch_end_time = touch_start_time + CFG.touchDuration(vals);
      touchOffset = touch_end_time - touch_start_time;
      n.Touch_start = touch_start_time;
      n.Touch_end = touch_end_time;
      n.Touch_duration = touchOffset;

      if (pos === 'DUMHEADER') {
        for (var a = TPstart + 1; a <= dumHeader_n; a++) dumHeader_line[a] += touchOffset;
        n.dumHeader_end += touchOffset;
        for (var b = 1; b <= SimCol; b++) display_line[b] += touchOffset;
        n.display_start += touchOffset; n.display_end = display_line[SimCol];
        for (var c = 1; c <= dumTail_m; c++) dumTail_line[c] += touchOffset;
        n.dumTail_end = dumTail_line[dumTail_m];
      } else if (pos === 'DISPLAYLINE') {
        for (var d = TPstart + 1; d <= SimCol; d++) display_line[d] += touchOffset;
        n.display_end += touchOffset;
        for (var e = 1; e <= dumTail_m; e++) dumTail_line[e] += touchOffset;
        n.dumTail_end = dumTail_line[dumTail_m];
      } else if (pos === 'DUMTAIL') {
        for (var f = TPstart + 1; f <= dumTail_m; f++) dumTail_line[f] += touchOffset;
        n.dumTail_end += touchOffset;
      }
      n.FrameEnd_start = n.dumTail_end;
      n.FrameEnd_end = n.FrameEnd_start + BlankingTime;
    } else {
      n.Touch_start = 0; n.Touch_end = 0; n.Touch_duration = 0;
    }
    n.isTouchExist = IsTouchExist;
    n.TPstart = TPstart;

    // ⑦ preCharge：本轮定义仅用于 display 中的 Touch 之后。
    var CKHPreCharge = Number(vals.CKHPreCharge);
    if (!Number.isInteger(CKHPreCharge) || CKHPreCharge < 0) throw new Error('CKHPreCharge 必须是非负整数（行数）。');
    var isPreChargeValid = CKHPreCharge > 0 && IsTouchExist && pos === 'DISPLAYLINE';
    n.preCharge_start = 0; n.preCharge_end = 0; n.preCharge_duration = 0;
    if (isPreChargeValid) {
      var preChargeOffset = CKHPreCharge * CKV_period;
      n.preCharge_start = touch_end_time;
      n.preCharge_end = touch_end_time + preChargeOffset;
      n.preCharge_duration = preChargeOffset;
      for (var j = TPstart + 1; j <= SimCol; j++) display_line[j] += preChargeOffset;
      n.display_end += preChargeOffset;
      for (var k = 1; k <= dumTail_m; k++) dumTail_line[k] += preChargeOffset;
      n.dumTail_end += preChargeOffset;
      n.FrameEnd_start = n.dumTail_end;
      n.FrameEnd_end = n.FrameEnd_start + BlankingTime;
    }

    // 插入 Touch / preCharge 后，尾部起点必须随显示结束一同顺延。
    n.dumTail_start = n.display_end;

    // 时间段配置（供信号生成使用）
    n.periods = {
      frameDelay: { start: n.frameDelay_start, end: n.frameDelay_end },
      dumHeader: { start: n.dumHeader_start, end: n.dumHeader_end },
      display: { start: n.display_start, end: n.display_end },
      dumTail: { start: n.dumTail_start, end: n.dumTail_end },
      frameEnd: { start: n.FrameEnd_start, end: n.FrameEnd_end },
      Touch: { start: n.Touch_start, end: n.Touch_end },
      preCharge: { start: n.preCharge_start, end: n.preCharge_end }
    };

    return n;
  }

  // Video 以 CKH 固定点①为锚点，按物理 Data 与 AA 连接读取完整 Pattern。
  function generateVideo(vals, tl) {
    var P = window.STGPattern, count = Number(vals.Videonum), mux = Number(vals.CKHnum);
    if (!P) throw new Error('Pattern 模块尚未加载。');
    if (!Number.isInteger(count) || count < 2 || count % 2 !== 0) throw new Error('Video 条数必须为正偶数。');
    var tr = Number(vals.Videotr), tf = Number(vals.Videotf), lead = Number(vals.VideoTCKH);
    if ([tr,tf,lead].some(function(n){return !Number.isFinite(n) || n < 0;})) throw new Error('Video 上升、下降及提前时间必须为非负有限数值。');
    var config = P.prepare(vals.PatternConfig, vals), map = config.maps[String(mux)] || {}, frame = vals.CKHModeFrame === 'negative' ? 'negative' : 'positive';
    var ground = voltage('GND',vals), black = voltage('Black',vals), signals = {}, displayIndex = 0, rowNumbers = {};
    var ckhRows=tl.CKH_rows||[];
    ckhRows.forEach(function(row,i){if(row.segment === 'display')rowNumbers[i+1]=++displayIndex;});
    // Every precharge row samples the first display row after the inserted section.
    var nextDisplayRow=null;
    for(var rowIndex=ckhRows.length-1;rowIndex>=0;rowIndex--){
      if(ckhRows[rowIndex].segment==='display')nextDisplayRow=rowNumbers[rowIndex+1];
      else if(ckhRows[rowIndex].segment==='preCharge'){
        if(nextDisplayRow===null)throw new Error('Video 预充电之后没有可读取的显示行。');
        rowNumbers[rowIndex+1]=nextDisplayRow;
      }
    }
    tl.Video_slots = [];
    for (var video = 1; video <= count; video++) {
      var events = [], last = ground, settled = 0, sig = new Map(); putPoint(sig,0,ground);
      if (tl.dumHeader_end > tl.dumHeader_start) events.push({time:tl.dumHeader_start,value:black,publicEdge:true});
      if (tl.dumTail_end > tl.dumTail_start) events.push({time:tl.dumTail_start,value:black,publicEdge:true});
      if (tl.isTouchExist && String(vals.TpPosition).toUpperCase() === 'DISPLAYLINE') events.push({time:tl.Touch_start,value:ground,publicEdge:true});
      (tl.CKH_points || []).forEach(function(pulse){
        if (pulse.segment !== 'display' && pulse.segment !== 'preCharge') return;
        var row = rowNumbers[pulse.row], target = map[video+':'+pulse.channel];
        if (!target || !COLORS_FOR_VIDEO.includes(target.color) || !Number.isInteger(Number(target.pixel))) throw new Error('Video'+video+' / CKH'+pulse.channel+' 的 Data 连接无效。');
        var data = (Number(target.pixel)-1)*3+COLORS_FOR_VIDEO.indexOf(target.color)+1;
        if (data < 1 || data > config.dataColumns) throw new Error('Video 的 Data 连接超出图像范围。');
        var aa = P.aaTarget(vals,row,data,config.dataColumns), time = pulse.points[0][0]-lead;
        if (time < 0 || time >= tl.FrameEnd_end) throw new Error('Video 提前时间使切换起点超出时间轴。');
        var value = aa ? P.voltage(config,row,aa.pixel,aa.color,frame) : null;
        if (aa && value === null) throw new Error('第'+row+'行的 Pattern 电压无效。');
        var record = {video:video,row:row,modeRow:pulse.row,segment:pulse.segment,channel:pulse.channel,data:data,target:aa,time:time,voltage:value,hold:!aa};
        tl.Video_slots.push(record); if (aa) events.push({time:time,value:value,slot:record});
      });
      events.sort(function(a,b){return a.time-b.time;});
      var changes = events.filter(function(event){if(event.value === last)return false;last=event.value;return true;}); last=ground;
      changes.forEach(function(event,i){
        var rise = event.value > last;
        var duration = event.publicEdge ? num(vals[rise?'tr_pub':'tf_pub']) : rise ? tr : tf;
        var next = i+1 < changes.length ? changes[i+1].time : tl.FrameEnd_start;
        if (event.time < settled-1e-9 || event.time+duration > next+1e-9) throw new Error('Video'+video+' 电压变化时间超过下一切换点，请减小 Videotr/Videotf 或公共边沿时间。');
        putPoint(sig,event.time,last); putPoint(sig,event.time+duration,event.value);
        last=event.value; settled=event.time+duration;
      });
      putPoint(sig,tl.FrameEnd_start,last); putPoint(sig,tl.FrameEnd_end,last);
      // Touch 与 frameEnd 沿用公共分段过渡与 TP 方波/正弦规则，预充电随 CKH 时隙读取后续第一条显示行，不覆盖为固定电压。
      overlaySignalSegments(sig,vals,tl,vals.VideoTPTermVstr,vals.VideoBlankingVstr,ground,true);
      signals['video'+video]=sig;
    }
    tl.Video_slots.sort(function(a,b){return a.time-b.time || a.video-b.video;});
    return signals;
  }
  var COLORS_FOR_VIDEO = ['R','G','B'];

  // =====================================================================
  // 平直信号（VGH/VGL/VCOM/U2D/D2U/GAS）
  // =====================================================================
  function flatSignal(voltageVal, tEnd) {
    var sig = new Map();
    putPoint(sig, 0, voltageVal);
    putPoint(sig, tEnd, voltageVal);
    return sig;
  }

  // =====================================================================
  // CKV 信号组（等价 clsSignalCKV：dumHeader/display/dumTail 内循环脉冲）
  // 每个 CKV_i 独立一条波形，脉冲结构 tr + width + tf + gap
  // =====================================================================
  function pulseEdgeShape(vals, prefix, edge, end, normalTime) {
      var eqEnabled = String(vals[prefix + 'EQ_SET']) === '是';
      var points = [], time = 0;
      if (!eqEnabled) return { points: [[normalTime, end]], duration: normalTime };
      var ramp = num(vals[prefix + edge + 'EQ']);
      var hold = num(vals[prefix + edge + 'EQwidth']);
      var levels = [num(vals[prefix + edge + 'EQVoltage'])];
      var second = num(vals[prefix + edge + 'EQVoltage2']);
      if (second !== 0) levels.push(second);
      levels.forEach(function (level) {
        time += ramp;
        points.push([time, level]);
        time += hold;
        points.push([time, level]);
      });
      time += ramp;
      points.push([time, end]);
      return { points: points, duration: time };
    }

  function generateCKV(vals, tl) {
    var VGH = num(vals.VGH), VGL = num(vals.VGL);
    var tr = num(vals.CKV_tr), tf = num(vals.CKV_tf);
    var width = num(vals.CKV_width), gap = num(vals.CKV_gap);
    var CKVnum = int(vals.CKVnum); if (CKVnum < 1) CKVnum = 1;
    var CKVstart = int(vals.CKVstart); if (CKVstart < 1) CKVstart = 1;
    var rise = pulseEdgeShape(vals, 'CKV', 'tr', VGH, tr);
    tl.CKV_rise_duration = rise.duration;
    var fall = pulseEdgeShape(vals, 'CKV', 'tf', VGL, tf);
    var timing = CFG.ckvTiming(vals);
    width = Math.max(0, timing.width);
    var runtime = num(vals.CKV_period);
    if (runtime <= 0) runtime = 1;

    var signals = {};
    for (var i = 1; i <= CKVnum; i++) signals['CKV' + i] = new Map();

    var periodNames = ['dumHeader', 'display', 'dumTail'];
    var slotIndex = 0;
    tl.CKV_rows = [];
    periodNames.forEach(function (pname) {
      var p = tl.periods[pname];
      if (!p || (p.start === 0 && p.end === 0)) return;
      // dumHeader 从 STV 起点开始；首个 CKV 点1需延后 STVtCKV。
      var t = pname === 'dumHeader' ? tl.CKVstart : p.start;
      while (t + runtime <= p.end + 1e-9) {
        // 插入时段暂停行脉冲，不推进通道编号；恢复时使用下一通道。
        var pause = [tl.periods.Touch, tl.periods.preCharge].find(function (period) {
          return period.end > period.start && t >= period.start - 1e-9 && t < period.end - 1e-9;
        });
        if (pause) { t = pause.end; continue; }
        var sigIdx = ((CKVstart - 1 + slotIndex) % CKVnum) + 1;
        var sig = signals['CKV' + sigIdx];
        tl.CKV_rows.push({ start: t, point2: t + tr, point3: t + tr + num(vals.CKV_width),
          shapePoint2: t + rise.duration, shapePoint3: t + rise.duration + width,
          end: t + runtime, channel: sigIdx, segment: pname });
        putPoint(sig, t, VGL);
        rise.points.forEach(function (point) { putPoint(sig, t + point[0], point[1]); });
        var fallStart = t + rise.duration + width;
        putPoint(sig, fallStart, VGH);
        fall.points.forEach(function (point) { putPoint(sig, fallStart + point[0], point[1]); });
        putPoint(sig, t + runtime, VGL);
        t += runtime;
        slotIndex++;
      }
    });

    for (var k = 1; k <= CKVnum; k++) {
      var sig2 = signals['CKV' + k];
      putPoint(sig2, 0, VGL);
      putPoint(sig2, tl.FrameEnd_end, VGL);
      overlaySignalSegments(sig2, vals, tl, vals.CKVtpTermVstr, vals.CKVblankingVstr);
    }
    return signals;
  }

  // CKH基本Mux顺序：本行首个点1=CKV点2+VTH，后续点1接上一个点5。
  function generateCKH(vals, tl) {
    var count = Number(vals.CKHnum), tr = Number(vals.CKH_tr), tf = Number(vals.CKH_tf);
    var width = Number(vals.CKH_Width), gap = Number(vals.CKH_gap), offset = Number(vals.VTH);
    if (!Number.isInteger(count) || count < 1) throw new Error('CKHnum 必须是正整数。');
    if ([tr, tf, width, gap, offset].some(function (v) { return !Number.isFinite(v) || v < 0; })) throw new Error('CKH边沿、宽度、gap和VTH必须是非负有限数值。');
    var duration = tr + width + tf + gap;
    if (duration <= 0) throw new Error('CKH单个周期必须大于零。');
    var eqErrors = CFG.validateCKHEQ(vals);
    if (eqErrors.length) throw new Error(eqErrors.join('\n'));
    var timing = CFG.ckhTiming(vals);
    width = Math.max(0, timing.width);
    var rise = pulseEdgeShape(vals, 'CKH', 'tr', num(vals.VGH), tr);
    var fall = pulseEdgeShape(vals, 'CKH', 'tf', num(vals.VGL), tf);
    var signals = {}, low = num(vals.VGL), high = num(vals.VGH);
    tl.CKH_points = [];
    for (var i = 1; i <= count; i++) signals['ckh' + i] = flatSignal(low, tl.FrameEnd_end);
    var displayRows = tl.CKV_rows.filter(function (row) { return row.segment === 'display'; });
    var preChargeRows = [];
    for (var pre = 0; pre < int(vals.CKHPreCharge) && tl.preCharge_duration > 0; pre++) {
      var preStart = tl.preCharge_start + pre * num(vals.CKV_period);
      preChargeRows.push({ start: preStart, point2: preStart + num(vals.CKV_tr), point3: preStart + num(vals.CKV_tr) + num(vals.CKV_width),
        end: preStart + num(vals.CKV_period), segment: 'preCharge', virtual: true });
    }
    var rows = displayRows.concat(preChargeRows).sort(function (a, b) { return a.start - b.start; });
    tl.CKH_rows = rows;
    var modePrefix = 'CKHMode_'  + count + '_' + (vals.CKHModeFrame === 'negative' ? 'negative' : 'positive');
    var repeat = Number(vals[modePrefix + '_rows']);
    if (!Number.isInteger(repeat) || repeat < 1 || repeat > 512) throw new Error('CKH_Mode重复行数必须是1～512的整数。');
    var sequences = [];
    for (var line = 1; line <= repeat; line++) {
      var sequence = String(vals[modePrefix + '_' + line] || '').trim().split(/[\s,，]+/).map(Number);
      if (sequence.length !== count || new Set(sequence).size !== count || sequence.some(function (channel) { return !Number.isInteger(channel) || channel < 1 || channel > count; })) throw new Error('CKH_Mode第' + line + '行必须将1～' + count + '各填写一次。');
      sequences.push(sequence);
    }
    rows.forEach(function (row, rowIndex) {
      var start = row.point2 + offset;
      if (start + count * duration > row.end + 1e-9) throw new Error('第' + (rowIndex + 1) + '行的CKH序列超过CKV行周期，请调整CKH数量/时长、VTH或CKV周期。');
      var sequence = sequences[rowIndex % repeat];
      for (var slot = 0; slot < count; slot++) {
        var channel = sequence[slot];
        var t = start + slot * duration;
        var point3 = t + rise.duration + width;
        var points = [[t, low], [t + rise.duration, high], [point3, high], [point3 + fall.duration, low], [t + duration, low]];
        var waveform = [[t, low]].concat(rise.points.map(function (p) { return [t + p[0], p[1]]; }),
          [[point3, high]], fall.points.map(function (p) { return [point3 + p[0], p[1]]; }), [[t + duration, low]]);
        waveform.forEach(function (point) { putPoint(signals['ckh' + channel], point[0], point[1]); });
        tl.CKH_points.push({ row: rowIndex + 1, segment: row.segment, virtual: !!row.virtual, channel: channel,
          points: [[t, low], [t + tr, high], [t + tr + num(vals.CKH_Width), high], [t + duration - gap, low], [t + duration, low]],
          shapePoints: points });
      }
    });
    // RGBBGR 只连接连续行的末路与下一行首路，原始锚点不移动。
    // Touch 会中断连续性，继续使用公共 Touch 波形；预充电行参与连接。
    tl.CKH_bridges = [];
    if (String(vals.RGBBGR) === '是') {
      for (var rowIndex = 1; rowIndex < rows.length; rowIndex++) {
        if (Math.abs(rows[rowIndex - 1].end - rows[rowIndex].start) > 1e-9) continue;
        var previous = tl.CKH_points[rowIndex * count - 1];
        var next = tl.CKH_points[rowIndex * count];
        if (previous.channel !== next.channel) continue;
        var sig = signals['ckh' + previous.channel];
        var from = previous.shapePoints[2][0], to = next.shapePoints[1][0];
        Array.from(sig.keys()).forEach(function (time) {
          if (time >= from - 1e-6 && time <= to + 1e-6) sig.delete(time);
        });
        putPoint(sig, from, high);
        putPoint(sig, to, high);
        previous.mergedNext = true;
        next.mergedPrevious = true;
        tl.CKH_bridges.push({ channel: previous.channel, fromRow: rowIndex, toRow: rowIndex + 1, start: from, end: to });
      }
    }
    Object.keys(signals).forEach(function (name) {
      overlaySignalSegments(signals[name], vals, tl, vals.CKHtpTermVstr, vals.CKHBlankingVstr, low, true);
    });
    return signals;
  }

  // =====================================================================
  // Greset：单脉冲（GSTDelay 后上升 GSTtr，保持 GSTwidth，下降 GSTtf）
  // =====================================================================
  function generateGreset(vals, tl, index) {
    var prefix = "GST" + index, fallback = CFG.defaults();
    function setting(suffix) { var key = prefix + suffix; return vals[key] === undefined ? fallback[key] : vals[key]; }
    var sig = new Map();
    var base = num(vals.VGL);
    var high = voltage(setting('Value'), vals);
    var d = num(setting('Delay')), tr = num(setting('tr')), tf = num(setting('tf')), w = num(setting('width'));
    putPoint(sig, 0, base);
    putPoint(sig, d, base);
    putPoint(sig, d + tr, high);
    putPoint(sig, d + tr + w, high);
    putPoint(sig, d + tr + w + tf, base);
    putPoint(sig, tl.FrameEnd_end, base);
    overlaySignalSegments(sig, vals, tl, setting('tpTermVstr'), setting('blankingVstr'), base);
    return sig;
  }

  // =====================================================================
  // 对已有 PWL 覆盖一个独立时段；过渡占用该时段开头。
  function valueAt(sig, time) {
    var points = toArray(sig);
    for (var i = 1; i < points.length; i++) {
      if (time <= points[i][0]) {
        var a = points[i - 1], b = points[i];
        return a[1] + (b[1] - a[1]) * (time - a[0]) / (b[0] - a[0]);
      }
    }
    return points[points.length - 1][1];
  }

  function transition(sig, time, from, to, vals, available) {
    var duration = to > from ? num(vals.tr_pub) : to < from ? num(vals.tf_pub) : 0;
    if (duration > available + 1e-9) throw new Error('公共 tr/tf 超过后段可用时间，请减小公共边沿时间或增加该时段延时。');
    putPoint(sig, time, from);
    putPoint(sig, time + duration, to);
    return time + duration;
  }

  function overlaySignalSegments(sig, vals, tl, touchBaseSetting, frameEndSetting, normalBase, preservePreCharge) {
    var VGL = normalBase === undefined ? num(vals.VGL) : normalBase;
    function nextEvent(time) {
      var times = Array.from(sig.keys()).filter(function (t) { return t > time + 1e-9; });
      return times.length ? Math.min.apply(null, times) : tl.FrameEnd_end;
    }
    function cover(start, end, base, pulse) {
      var before = valueAt(sig, start), after = valueAt(sig, end);
      Array.from(sig.keys()).forEach(function (t) { if (t >= start && t <= end) sig.delete(t); });
      var front = pulse ? num(vals.TPfrontDelay) : end - start;
      var edgeTime = function (from, to) { return to > from ? num(vals.tr_pub) : to < from ? num(vals.tf_pub) : 0; };
      var rawBase = base;
      var settled;
      if (pulse) {
        base = rawBase + num(vals.TPbaseOffset);
        // 偏移仅在中间 pulse 区；前后各留1us平坦区，过渡另扣。
        var lead = edgeTime(before, rawBase), offsetRise = edgeTime(rawBase, base);
        if (lead + offsetRise + 1 > front + 1e-9) throw new Error('TPfrontDelay 不足以容纳公共过渡和1微秒平坦区。');
        transition(sig, start, before, rawBase, vals, lead);
        var offsetStart = start + front - 1 - offsetRise;
        putPoint(sig, offsetStart, rawBase);
        transition(sig, offsetStart, rawBase, base, vals, offsetRise);
        var t = start + front;
        putPoint(sig, t, base);
        for (var i = 0; i < int(vals.TPnum); i++) {
          putPoint(sig, t, base);
          if (String(vals.TPpulseShape || '方波') === '正弦波') {
            // 全正弦从基线出发再回到基线；Gap融入周期，64段PWL。
            var duration = num(vals.TPtr) + num(vals.TPwidth) + num(vals.TPTf) + num(vals.TPGap);
            if (duration <= 0) throw new Error('全正弦周期 TPtr＋TPwidth＋TPTf＋TPGap 必须大于零。');
            for (var sample = 1; sample <= 64; sample++) {
              putPoint(sig, t + duration * sample / 64,
                sample === 64 ? base : base + num(vals.TPpulseDeltaV) * (1 - Math.cos(2 * Math.PI * sample / 64)) / 2);
            }
            t += duration;
          } else {
            t += num(vals.TPtr); putPoint(sig, t, base + num(vals.TPpulseDeltaV));
            t += num(vals.TPwidth); putPoint(sig, t, base + num(vals.TPpulseDeltaV));
            t += num(vals.TPTf); putPoint(sig, t, base);
            t += num(vals.TPGap); putPoint(sig, t, base);
          }
        }
        var offsetFall = edgeTime(base, rawBase), exitDuration = edgeTime(rawBase, after);
        if (1 + offsetFall + exitDuration > num(vals.TPbackDelay) + 1e-9) throw new Error('TPbackDelay 不足以容纳1微秒平坦区和公共过渡。');
        putPoint(sig, t + 1, base);
        transition(sig, t + 1, base, rawBase, vals, offsetFall);
        // 退出Touch的过渡仍占back末尾，不占下一行CKV。
        var exitStart = end - exitDuration;
        putPoint(sig, exitStart, rawBase);
        transition(sig, exitStart, rawBase, after, vals, exitDuration);
      } else {
        settled = transition(sig, start, before, base, vals, front);
        putPoint(sig, settled, base);
        putPoint(sig, end, base);
      }
      if (!pulse) transition(sig, end, base, after, vals, nextEvent(end) - end);
    }
    if (tl.isTouchExist) {
      cover(tl.Touch_start, tl.Touch_end, voltage(touchBaseSetting, vals), true);
    }
    if (tl.preCharge_duration > 0 && !preservePreCharge) cover(tl.preCharge_start, tl.preCharge_end, VGL, false);
    applyFrameEnd(sig, vals, tl, frameEndSetting);
  }

  function applyFrameEnd(sig, vals, tl, baseSetting) {
    var start = tl.FrameEnd_start, end = tl.FrameEnd_end;
    var from = valueAt(sig, start), blanking = voltage(baseSetting, vals);
    Array.from(sig.keys()).forEach(function (t) { if (t >= start) sig.delete(t); });
    transition(sig, start, from, blanking, vals, end - start);
    putPoint(sig, end, blanking);
  }

  // STVi 对应 dumHeader 中第 i 个 CKV 脉冲。五点结构，gap=0。
  // =====================================================================
  function generateSTV(vals, tl) {
    var signals = {};
    var base = num(vals.VGL), high = num(vals.VGH);
    var tr = num(vals.STVtr), tf = num(vals.STVtf);
    tl.STV_points = {};
    function shiftTime(time) {
      if (tl.isTouchExist && time >= tl.Touch_start - 1e-9) time += tl.Touch_duration;
      if (tl.preCharge_duration > 0 && time >= tl.preCharge_start - 1e-9) time += tl.preCharge_duration;
      return time;
    }
    for (var i = 1; i <= int(vals.STVnum); i++) {
      var name = 'stv' + i;
      var ckvPoint1 = tl.CKVstart + (i - 1) * num(vals.CKV_period);
      var startOffset = shiftTime(ckvPoint1) - ckvPoint1;
      var ckvPoint4 = ckvPoint1 + num(vals.CKV_period) - num(vals.CKV_gap);
      var p2 = ckvPoint1 - num(vals.STVtCKV);
      var p1 = p2 - tr;
      var p3 = ckvPoint4 + num(vals.CKVtSTV);
      var p4 = p3 + tf;
      p1 += startOffset; p2 += startOffset; p3 = shiftTime(p3); p4 = shiftTime(p4);
      if (tl.isTouchExist && [p1, p2, p3, p4].some(function (time) { return time >= tl.Touch_start && time < tl.Touch_end; })) {
        throw new Error(name.toUpperCase() + ' 边沿与 Touch 时段重叠，请调整 Touch 插入行或 STV/CKV 间隔。');
      }
      if (p4 > tl.FrameEnd_start + 1e-6) throw new Error(name.toUpperCase() + ' 下降沿进入 frameEnd，请调整 CKVtSTV 或 STVtf。');
      var points = [[p1, base], [p2, high], [p3, high], [p4, base], [p4, base]];
      tl.STV_points[name] = points;
      var sig = new Map();
      putPoint(sig, 0, base);
      points.forEach(function (point) { putPoint(sig, point[0], point[1]); });
      putPoint(sig, tl.FrameEnd_end, base);
      overlaySignalSegments(sig, vals, tl, vals.STVtpTermVstr, vals.STVblankingVstr);
      signals[name] = sig;
    }
    return signals;
  }

  // =====================================================================
  // 汇总：生成全部信号（返回 {名称: [[t,v],...]} 已排序数组）
  // =====================================================================
  function generateFrame(vals) {
    vals = window.STG_CONFIG.normalizeValues(vals);
    var errors = CFG.validateCKV(vals).concat(CFG.validateSTV(vals));
    if (errors.length) throw new Error(errors.join('\n'));
    var tl = initTimeline(vals);
    var tEnd = tl.FrameEnd_end;
    var VGL = num(vals.VGL);

    var map = {
      greset1: generateGreset(vals, tl, 1),
      greset2: generateGreset(vals, tl, 2),
      vgh: flatSignal(num(vals.VGH), tEnd),
      vgl: flatSignal(num(vals.VGL), tEnd),
      u2d: flatSignal(num(vals.VGH), tEnd),
      d2u: flatSignal(num(vals.VGL), tEnd),
      gas: flatSignal(VGL, tEnd),
      vcom: flatSignal(num(vals.VCOM), tEnd)
    };

    // 公共电压信号也生成Touch，基准分别使用自身公共电压。
    overlaySignalSegments(map.vgh, vals, tl, 'VGH', 'VGH', num(vals.VGH));
    overlaySignalSegments(map.vgl, vals, tl, 'VGL', 'VGL', num(vals.VGL));
    overlaySignalSegments(map.vcom, vals, tl, 'VCOM', 'VCOM', num(vals.VCOM));

    // 控制信号：普通段固定电压，frameEnd/Touch使用各自配置。
    overlaySignalSegments(map.u2d, vals, tl, vals.U2DtpTermVstr, vals.U2DblankingVstr, num(vals.VGH));
    overlaySignalSegments(map.d2u, vals, tl, vals.D2UtpTermVstr, vals.D2UblankingVstr, VGL);
    overlaySignalSegments(map.gas, vals, tl, vals.GAStpTermVstr, vals.GASblankingVstr, VGL);

    var stv = generateSTV(vals, tl);
    Object.keys(stv).forEach(function (name) { map[name] = stv[name]; });
    var ckv = generateCKV(vals, tl);
    Object.keys(ckv).forEach(function (name) { map[name.toLowerCase()] = ckv[name]; });
    var ckh = generateCKH(vals, tl);
    Object.keys(ckh).forEach(function (name) { map[name] = ckh[name]; });
    var video = generateVideo(vals, tl);
    Object.keys(video).forEach(function (name) { map[name] = video[name]; });

    // 转成排序数组
    var out = {};
    Object.keys(map).forEach(function (name) { out[name] = toArray(map[name]); });
    return { timeline: tl, signals: out };
  }

  // 完整周期按正帧、负帧生成；每帧独立使用对应的 CKH_Mode 与 Video 极性。
  function generateAll(vals) {
    var positive,negative;
    try{positive=generateFrame(Object.assign({},vals,{CKHModeFrame:'positive'}));}catch(error){throw new Error('正帧：'+error.message);}
    try{negative=generateFrame(Object.assign({},vals,{CKHModeFrame:'negative'}));}catch(error){throw new Error('负帧：'+error.message);}
    var offset=positive.timeline.FrameEnd_end,total=offset+negative.timeline.FrameEnd_end,signals={};
    Object.keys(positive.signals).forEach(function(name){
      var points=positive.signals[name].map(function(p){return p.slice();});
      negative.signals[name].forEach(function(p){var next=[round6(p[0]+offset),p[1]],previous=points[points.length-1];if(!previous||previous[0]!==next[0]||previous[1]!==next[1])points.push(next);});
      signals[name]=points;
    });
    var timeline=Object.assign({},positive.timeline,{frameCount:2,frameDuration:offset,cycleEnd:total,FrameEnd_start:offset+negative.timeline.FrameEnd_start,FrameEnd_end:total});
    timeline.frames=[{polarity:'positive',start:0,end:offset,timeline:positive.timeline},{polarity:'negative',start:offset,end:total,timeline:negative.timeline}];
    ['CKV_rows','CKH_rows','CKH_points','Video_slots'].forEach(function(key){
      function shift(items,amount,frame){return (items||[]).map(function(item){var result=Object.assign({},item,{frame:frame});['start','end','point1','point2','point3','shapePoint2','shapePoint3','time'].forEach(function(k){if(typeof item[k]==='number')result[k]=round6(item[k]+amount);});['points','shapePoints'].forEach(function(k){if(Array.isArray(item[k]))result[k]=item[k].map(function(p){return [round6(p[0]+amount),p[1]];});});return result;});}
      timeline[key]=shift(positive.timeline[key],0,'positive').concat(shift(negative.timeline[key],offset,'negative'));
    });
    return {timeline:timeline,signals:signals};
  }

  return {
    initTimeline: initTimeline,
    voltage: voltage,
    flatSignal: flatSignal,
    generateVideo: generateVideo,
    generateFrame: generateFrame,
    generateAll: generateAll
  };
})();


