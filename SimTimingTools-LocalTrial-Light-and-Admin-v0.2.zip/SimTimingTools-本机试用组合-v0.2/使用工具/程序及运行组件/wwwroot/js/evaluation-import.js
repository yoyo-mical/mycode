(function(global){'use strict';
function normalize(name){return String(name).toLowerCase().replace(/[\s_\-（）()]/g,'').replace(/μ|µ/g,'u');}
var aliases={ckvwidth:'CKV_width',ckv宽度:'CKV_width',ckvperiod:'CKV_period',ckv周期:'CKV_period',ckvtr:'CKV_tr',ckv上升时间:'CKV_tr',ckvtf:'CKV_tf',ckvtoff:'CKV_tf',ckv下降时间:'CKV_tf',ckvgap:'CKV_gap',ckhwidth:'CKH_Width',ckh宽度:'CKH_Width',ckhtr:'CKH_tr',ckhtf:'CKH_tf',ckhtoff:'CKH_tf',ckhgap:'CKH_gap',vth:'VTH',htv:'HTV'};
function numeric(value){var match=String(value).trim().match(/^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)\s*(?:us|μs|µs)?$/i);return match&&Number.isFinite(Number(match[1]))?match[1]:null;}
function parse(text,custom){var lines=String(text).replace(/^\uFEFF/,'').split(/\r?\n/).map(function(line){return line.split('\t').map(function(cell){return cell.trim().replace(/^"|"$/g,'');});}),rows=[];
lines.forEach(function(cells,line){for(var i=0;i<cells.length;i++){var name=cells[i];if(!name||numeric(name)!==null)continue;var key=(custom||{})[normalize(name)]||aliases[normalize(name)],value=null;
if(normalize(name)==='ckhnum'||normalize(name)==='ckhnumber')continue;
for(var j=i+1;j<cells.length;j++){if(!cells[j])continue;if(aliases[normalize(cells[j])]||(custom||{})[normalize(cells[j])])break;value=numeric(cells[j]);if(value!==null)break;}
if(value===null&&lines[line+1]&&lines[line+1][i]!==undefined)value=numeric(lines[line+1][i]);
if(value!==null)rows.push({name:name,key:key||'',value:value,line:line+1});
}});return rows;}
function check(values){var v=function(key){return Number(values[key]);},period=v('CKV_width')+v('CKV_tr')+v('CKV_tf')+v('CKV_gap'),divisor=v('CKH_Width')+v('CKH_tr')+v('CKH_tf')+v('CKH_gap'),count=(v('CKV_width')+v('CKH_gap')-v('VTH')-v('HTV'))/divisor,nearest=Math.round(count),valid=Number.isFinite(count)&&Math.abs(count-nearest)<1e-6&&[2,3,4,6].includes(nearest),messages=[];
if(!Number.isFinite(period)||Math.abs(v('CKV_period')-period)>1e-6)messages.push('CKV_period：原值 '+values.CKV_period+'；计算值 '+period+'；差值 '+(v('CKV_period')-period)+' μs');
if(!valid){var candidate=Number.isFinite(nearest)?nearest:0,used=candidate*(v('CKH_Width')+v('CKH_tr')+v('CKH_tf'))+(candidate-1)*v('CKH_gap')+v('VTH')+v('HTV');messages.push('CKHnum：计算值 '+count+'，需为 2、3、4、6。按 '+candidate+' 路核对：CKV_width 原值 '+values.CKV_width+'；CKH 合计 '+used+'；差值 '+(v('CKV_width')-used)+' μs。');}
return {count:valid?nearest:count,period:period,errors:messages};}
global.STGEvaluationImport={normalize:normalize,parse:parse,check:check};
})(window);
