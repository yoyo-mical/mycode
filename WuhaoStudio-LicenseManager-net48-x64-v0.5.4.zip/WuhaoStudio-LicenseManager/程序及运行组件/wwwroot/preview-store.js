import {setKeyStatus,requireKey,refreshKeyStatus,setKeyBusy} from './key-settings.js';
import {clone,migrate,validateBook,products} from './organizations.js?v=20261112-import';
export {products};
export const STORAGE_KEY='';
let serial=0;const pending=new Map();
const webview=globalThis.chrome?.webview;
if(webview)webview.addEventListener('message',event=>{const response=event.data;if(response?.type!=='admin')return;const p=pending.get(response.id);if(!p)return;pending.delete(response.id);response.ok?p.resolve(response.result):p.reject(Error(response.error||'本机管理操作失败'));});
function native(operation,details={}){
 if(!webview)return Promise.reject(Error('请使用解压后的 WuhaoLicenseManager.exe 打开管理工具。'));
 return new Promise((resolve,reject)=>{const id=String(++serial);pending.set(id,{resolve,reject});webview.postMessage(JSON.stringify({id,operation,...details}));});
}
globalThis.desktopAdmin={run:native};
export class PreviewStore {
 constructor(){this.book=null;}
 async run(operation,details={}){
  if(operation==='init'){const result=await native('init');setKeyStatus(result.keyStatus);const book=validateBook(migrate(result.book));this.book=clone(book);return {book,warning:book.organizations.some(o=>o.legacyPaths)?'原管理数据已保留，请先为待整理组织配置共享路径。':''};}
  if(operation==='saveDraft'){validateBook(details.book);const saved=await native('saveBook',{book:details.book});this.book=clone(saved);return true;}
  if(operation==='signMany'){requireKey();setKeyBusy(true);try{const result=await native('signSelected',{ids:details.lists.map(l=>l.id)});this.book=clone(result.book);return result.results;}catch(e){try{await refreshKeyStatus();}catch{}throw e;}finally{setKeyBusy(false);}}
  if(operation==='backupKey'){requireKey();return native('backupKey');}
  throw Error('本机操作不受支持');
 }
}
export function createBackup(book){const data=clone(book);delete data.kind;delete data.version;delete data.backupVersion;delete data.exportedUtc;return {kind:'WuhaoLicenseManagementBackup',backupVersion:1,exportedUtc:new Date().toISOString(),...data};}
export function parseImport(text){const data=JSON.parse(text.replace(/^\ufeff/,''));if(!data||typeof data!=='object')throw Error('请选择有效的管理备份');if(data.payload&&data.signature)throw Error('这是授权名单，请使用“导入授权名单”');if(!['WuhaoLicenseManagementBackup','SimTimingManagementPreview'].includes(data.kind))throw Error('请选择本工具导出的管理备份');if(data.kind==='WuhaoLicenseManagementBackup'&&data.backupVersion!==1)throw Error('此管理备份格式暂不支持');const book=migrate(data);delete book.kind;delete book.version;delete book.backupVersion;delete book.exportedUtc;return validateBook(book);}
