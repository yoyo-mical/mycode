// Metadata only: file contents and passwords never cross the WebView bridge.
let status={state:'loading',message:'正在读取密钥设置',path:''};
const $=s=>document.querySelector(s);
export function setKeyStatus(value){
 status=value||{state:'unavailable',message:'密钥状态无法读取，请检查设置',path:''};
 $('#keyStatus').textContent=status.message;
 $('#keyLocation').textContent=status.path||'尚未选择';
 $('#configureKey').textContent=status.state==='configured'?'重新选择密钥文件':'选择原加密密钥文件';
 $('#keySummary').textContent=status.state==='configured'?'已配置':status.state==='loading'?'读取中':'需要配置';
}
export function setKeyBusy(value){for(const id of ['configureKey','refreshKeyStatus','backupKey'])$('#'+id).disabled=value;}
export function requireKey(){
 if(status.state==='configured')return;
 $('#keySettings').open=true;$('#configureKey').focus();throw Error(status.message+'。请先完成签发密钥设置。');
}
export async function refreshKeyStatus(){setKeyStatus(await window.desktopAdmin.run('keyStatus'));}
$('#configureKey').onclick=async()=>{
 const button=$('#configureKey');button.disabled=true;$('#keyError').textContent='';
 try {setKeyStatus(await window.desktopAdmin.run('configureKey'));$('#keyError').textContent='验证通过，已记住密钥文件位置。后续签发只需输入原管理密码。';}
 catch(e){$('#keyError').textContent=e.message;}
 finally{button.disabled=false;}
};
$('#refreshKeyStatus').onclick=()=>refreshKeyStatus().catch(e=>$('#keyError').textContent=e.message);
