// =====================================================================
// Sim-Timing-Generator 2026 —— 前端交互与渲染
// =====================================================================
(function (global) {
  'use strict';

  // Keep accidental Ctrl+wheel from zooming the entire waveform workspace.
  document.addEventListener('wheel',function(event){if(activeTab==='wave'&&event.ctrlKey)event.preventDefault();},{capture:true,passive:false});

  var CFG = global.STG_CONFIG;
  var ENG = global.STGEngine;

  var state = {
    modeMux: null,
    vals: null,          // 当前参数值（扁平对象）
    result: null,        // generateAll 结果 { timeline, signals }
    chart: null,         // echarts 实例
    visible: {},         // 信号显隐 {名称: true/false}
    theme: 'light',      // 波形图背景主题
    zoomWindow: {start:0,end:100},
    panelWidth: 220,
    lineWidth: 1.3,      // 信号线粗细
    sortPreset: 'default',
    listCategories: ['CKV'],
    filterMenuOpen: false,
    tableSignals: null,
    groups: null,        // 子图分组：[[sig], [sigA, sigB], ...]
    dragSrc: null,       // 拖拽源信号名
    dragBefore: false    // 拖出时插入到目标前还是后
  };

  // 信号展示顺序（对齐 Excel Output 列序）
  var SIGNAL_ORDER = ['greset1', 'greset2', 'stv', 'vgh', 'vgl', 'u2d', 'd2u', 'gas', 'vcom'];
  var PALETTE = ['#e6194b', '#3cb44b', '#4363d8', '#f58231', '#911eb4', '#42d4f4',
    '#f032e6', '#bfef45', '#fabed4', '#469990', '#9a6324', '#800000', '#aaffc3', '#000075'];

  // 波形图背景主题
  var THEMES = {
    light: { name: '浅色', bg: '#ffffff', text: '#333333', splitLine: '#e2e6ec', cross: '#e53935', border: '#d5dae2', axis: '#888' },
    dark: { name: '深色', bg: '#151b28', text: '#c8d0dc', splitLine: '#2a3444', cross: '#ff6b6b', border: '#2a3444', axis: '#7a8aa0' },
    paper: { name: '米色', bg: '#fdf6e3', text: '#586e75', splitLine: '#ece3c8', cross: '#cb4b16', border: '#e6dcbf', axis: '#93a1a1' },
    grid: { name: '蓝图网格', bg: '#f4f7fb', text: '#334466', splitLine: '#d3dce6', cross: '#003366', border: '#c5d0dd', axis: '#7a8aa0' }
  };

  function getTheme() { return THEMES[state.theme] || THEMES.light; }

  function $(id) { return document.getElementById(id); }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = text;
    return e;
  }
  function num(v) { var n = parseFloat(v); return isNaN(n) ? 0 : n; }

  // 数值格式化（SPICE 输出用）
  function fmt(x) {
    if (x === 0) return '0';
    var s = x.toFixed(2).replace(/\.?0+$/, '');
    return s;
  }

  // ---- 页签 ----
  var TABS = [
    { id: 'params', label: '参数配置' },
    { id: 'pattern', label: 'Pattern / Video 映射' },
    { id: 'wave', label: '时序波形' },
    { id: 'output', label: '时序文本' },
    { id: 'table', label: '时序表格' },
    { id: 'logic', label: '信号逻辑' }
  ];
  var activeTab = 'params';

  function renderTabs() {
    var nav = $('tabnav');
    nav.innerHTML = '';
    TABS.forEach(function (t, idx) {
      if (t.id === 'logic') return;
      if (idx === 2) { nav.appendChild(el('span', 'tab-sep')); }
      var b = el('button', 'tab' + (t.id === activeTab ? ' active' : ''), t.label);
      b.onclick = function () { showTab(t.id); };
      nav.appendChild(b);
    });
  }

  function showTab(id) {
    if (['wave', 'output', 'table'].indexOf(id) >= 0 && !state.result) {
      alert('请先修正参数并生成波形。');
      return;
    }
    if (activeTab === 'params') state.vals = collectValues();
    activeTab = id;
    renderTabs();
    if (state.chart) { try { var oldChartDiv=state.chart.getDom();if(oldChartDiv._viewportObserver)oldChartDiv._viewportObserver.disconnect();state.chart.dispose(); } catch (e) { /* ignore */ } state.chart = null; }
    var content = $('content');
    content.innerHTML = '';
    content.classList.remove('pattern-page');
    if (id === 'params') renderParams(content);
    else if (id === 'wave') renderWave(content);
    else if (id === 'output') renderOutput(content);
    else if (id === 'table') renderTable(content);
    else if (id === 'logic') renderSignalLogic(content);
    else if (id === 'pattern') global.STGPattern.render(content, state.vals, function (config) {
      state.vals.PatternConfig = config;
      saveToStorage(state.vals);
    }, function (patch) {
      state.vals = syncVideoCount(Object.assign({}, state.vals, patch), Object.prototype.hasOwnProperty.call(patch, 'Videonum') || Object.prototype.hasOwnProperty.call(patch, 'CKHnum'));
      saveToStorage(state.vals);
      showTab('pattern');
    });
  }

  // 三块沟通模板，以示意波形核对；不改变引擎输出。
  function syncVideoCount(vals, recalculate) {
    if (vals.Inversionmode === "Frame") vals.Inversionmode = "Zigzag";
    var videos = Number(vals.Videonum), mux = Number(vals.CKHnum);
    var valid = Number.isInteger(videos) && videos > 0 && videos % 2 === 0 && [2,3,4,6].includes(mux);
    if (valid && (recalculate || vals.SimCol === undefined)) vals.SimCol = videos * mux;
    var input = document.querySelector('[data-key="Videonum"]');
    if (input) { input.readOnly = false; input.min = 2; input.step = 2; input.setCustomValidity(valid ? '' : 'Video 条数必须为正偶数，CKHnum 必须为 2、3、4、6。'); input.title = 'Video 条数必须为正偶数'; }
    var columns = document.querySelector('[data-key="SimCol"]');
    if (columns) {
      columns.value = vals.SimCol; columns.readOnly = false; columns.title = 'Video 条数 × CKHnum';
      var mismatch=valid&&Number(vals.SimCol)!==videos*mux;
      columns.classList.toggle('calculation-warning',mismatch);
      var row=columns.closest('.param-row'),hint=row.querySelector('.column-calculation');
      if(!hint){hint=el('span','column-calculation');row.appendChild(hint);}
      hint.textContent=mismatch?'计算值：'+videos*mux+'（Video 条数 × Mux）':'';
    }
    return vals;
  }
  function collectValues() {
    var vals = Object.assign({}, state.vals);
    var inputs = document.querySelectorAll('[data-key]');
    inputs.forEach(function (inp) {
      var key = inp.getAttribute('data-key');
      if (inp.tagName === 'SELECT' || inp.type === 'text') vals[key] = inp.value;
      else vals[key] = inp.value; // 数字也以字符串存，引擎里 num() 转换
    });
    return syncVideoCount(vals);
  }

  function updateEvaluation(vals, changedKey) {
    function number(key){var value=vals[key];return value!==''&&Number.isFinite(Number(value))?Number(value):NaN;}
    if(changedKey==='CKHnum' && [2,3,4,6].includes(number('CKHnum'))){var patch=global.STGEvaluationImport.reconcile(vals,vals.CKHnum);if(patch)Object.keys(patch).forEach(function(key){vals[key]=patch[key];var input=document.querySelector('[data-key="'+key+'"]');if(input)input.value=patch[key];});}
    var ckvs=['CKV_width','CKV_tr','CKV_tf','CKV_gap'],ckhs=['CKV_width','CKH_Width','CKH_tr','CKH_tf','CKH_gap','VTH','HTV'];
    var period=ckvs.reduce(function(sum,key){return sum+number(key);},0);
    var divisor=number('CKH_Width')+number('CKH_tr')+number('CKH_tf')+number('CKH_gap');
    var count=(number('CKV_width')+number('CKH_gap')-number('VTH')-number('HTV'))/divisor;
    function set(key,value){if(!Number.isFinite(value))return;vals[key]=Math.round(value*1e9)/1e9;var input=document.querySelector('[data-key="'+key+'"]');if(input)input.value=vals[key];}
    if(ckvs.includes(changedKey))set('CKV_period',period);
    if(ckhs.includes(changedKey)){var nearest=Math.round(count);set('CKHnum',Math.abs(count-nearest)<1e-6 && [2,3,4,6].includes(nearest)?nearest:count);}
    function hint(key,expected,valid){var input=document.querySelector('[data-key="'+key+'"]');if(!input)return;var row=input.closest('.param-row'),note=row.querySelector('.evaluation-hint');if(!note){note=el('span','evaluation-hint');row.appendChild(note);}input.classList.toggle('invalid',!valid);input.setAttribute('aria-invalid',String(!valid));note.textContent=valid?'':(Number.isFinite(expected)?'计算值：'+Math.round(expected*1e9)/1e9+(key==='CKHnum'?'；须为 2、3、4、6':' μs'):'请填写有效的时序参数');}
    hint('CKV_period',period,Number.isFinite(period)&&Math.abs(number('CKV_period')-period)<1e-6);
    hint('CKHnum',count,Number.isFinite(count)&&Math.abs(number('CKHnum')-count)<1e-6&&[2,3,4,6].includes(number('CKHnum')));
    syncVideoCount(vals, ckhs.includes(changedKey)||changedKey==='Videonum'||changedKey==='CKHnum');
    syncModeMux(vals);
  }

  function showGenerationErrors(errors) {
    var old=document.querySelector('.generation-error-dialog');if(old)old.remove();
    var dialog=el('dialog','generation-error-dialog'),heading=el('h2','','无法生成新波形'),intro=el('p','','请检查以下参数，修正后再点击“生成波形”。'),list=el('ol');
    heading.id='generation-error-heading';dialog.setAttribute('aria-labelledby',heading.id);
    errors.forEach(function(message){
      var row=el('li'),description=el('div','',message),hint='检查相关参数是否为空、是否为有效数字，以及时序是否超出可用范围。';
      if(/Stringlong/.test(message))hint='在基础设置的输出格式中，填写至少 64 的整数字符上限；不需要分行时关闭自动续行。';
      else if(/SimCol/.test(message))hint='检查 SimCol、Video 条数和 CKHnum：SimCol 应等于 Video 条数 × CKHnum。';
      else if(/CKH_Mode|CKHMode/.test(message))hint='在 CKH_Mode 中检查对应帧和行；通道 1～Mux 必须各出现一次，不能重复或漏填。';
      else if(/Video.*连接|Data/.test(message))hint='到 Pattern / Video 映射检查 Video、CKH 与 Data 的连接，确保 Data 位于图像范围内。';
      else if(/Video|Videotr|Videotf/.test(message))hint='检查 Video 条数、上升 / 下降时间及提前时间；边沿须在下一次切换前完成。';
      else if(/CKH/.test(message))hint='检查 CKHnum、CKH 宽度、tr / tf、gap、VTH，以及 CKV 行周期是否容纳完整 CKH 序列。';
      else if(/TP|Touch|公共/.test(message))hint='检查 Touch 插入位置、前后延时和公共边沿时间，确保各段有足够时间且不与 STV / CKV 重叠。';
      else if(/STV|CKV/.test(message))hint='检查对应信号的周期、宽度、边沿时间与间隔，确保时序不重叠、不超出帧范围。';
      row.appendChild(description);row.appendChild(el('p','generation-check-hint',hint));list.appendChild(row);
    });
    var actions=el('div','generation-error-actions'),go=el('button','tbtn','检查参数配置'),close=el('button','tbtn','关闭');
    go.onclick=function(){dialog.close();showTab('params');};close.onclick=function(){dialog.close();};actions.appendChild(go);actions.appendChild(close);
    dialog.appendChild(heading);dialog.appendChild(intro);dialog.appendChild(list);dialog.appendChild(actions);document.body.appendChild(dialog);dialog.addEventListener('close',function(){dialog.remove();});dialog.showModal();
  }

  // ---- 生成 ----
  async function generate() {
    if (!window.STGDesktop || !(await window.STGDesktop.requestPermission())) { alert("授权检查未通过，请重新打开程序或联系工具管理员。"); return; }
    var vals = collectValues();
    var errors = CFG.validateCKV(vals).concat(CFG.validateSTV(vals));
    if (!Number.isInteger(Number(vals.Videonum)) || Number(vals.Videonum) < 2 || Number(vals.Videonum) % 2 !== 0) errors.push("Video 条数必须为正偶数，仿真子列数 = Video 条数 × CKHnum。");
    if (Number(vals.SimCol)!==Number(vals.Videonum)*Number(vals.CKHnum)) errors.push('SimCol 与 Video 条数 × Mux 不一致，当前连接无法完整生成；计算值为 '+(Number(vals.Videonum)*Number(vals.CKHnum))+'。');
    if(vals.SpiceWrap!=='关闭'&&(!Number.isInteger(Number(vals.Stringlong))||Number(vals.Stringlong)<64))errors.push('Stringlong 每行字符上限必须是至少 64 的整数；或关闭自动续行。');
    var mux=Number(vals.CKHnum);
    if([2,3,4,6].includes(mux))['positive','negative'].forEach(function(frame){
      var prefix='CKHMode_'+mux+'_'+frame+'_',count=Number(vals[prefix+'rows']);
      if(!Number.isInteger(count)||count<1||count>512){errors.push((frame==='positive'?'正帧':'负帧')+'：CKH_Mode 行数必须为 1～512。');return;}
      for(var line=1;line<=count;line++){var order=String(vals[prefix+line]||'').trim().split(/[\s,，]+/).map(Number);if(order.length!==mux||new Set(order).size!==mux||order.some(function(n){return !Number.isInteger(n)||n<1||n>mux;}))errors.push((frame==='positive'?'正帧':'负帧')+'：CKH_Mode 第'+line+'行必须将 1～'+mux+' 各填写一次。');}
    });
    if (errors.length) {
      showGenerationErrors(errors);
      return;
    }
    var result;
    try { result = ENG.generateAll(vals); }
    catch (error) { showGenerationErrors(error.message.split('\n')); return; }
    state.vals = vals;
    state.result = result;
    updateTouchDuration(state.vals);
    // 初始化显隐
    var names = signalNames();
    names.forEach(function (n) { state.visible[n] = true; });
    state.listCategories = ['CKV','CKH','Video','GIP'];
    state.tableSignals = names.slice();
    syncGroups();
    saveToStorage(state.vals);
    // 若当前在结果页则刷新（清空重绘）
    if (activeTab === 'output' || activeTab === 'table' || activeTab === 'wave') {
      showTab(activeTab);
    }
  }

  function signalNames() {
    var stvs = Object.keys(state.result.signals).filter(function (name) { return /^stv[0-9]+$/.test(name); }).sort(function (a, b) { return Number(a.slice(3)) - Number(b.slice(3)); });
    var names = ['greset1', 'greset2'].concat(stvs, SIGNAL_ORDER.filter(function (name) { return name !== 'greset1' && name !== 'greset2' && name !== 'stv'; }));
    Object.keys(state.result.signals).forEach(function (n) {
      if (names.indexOf(n) < 0) names.push(n);
    });
    return names.filter(function (n) { return state.result.signals[n]; });
  }

  var SIGNAL_CATEGORIES = ['CKV', 'CKH', 'GIP', 'Video'];
  function signalCategory(name) {
    if (/^ckv\d+$/i.test(name)) return 'CKV';
    if (/^x?ckh\d+$/i.test(name)) return 'CKH';
    if (/^video\d+$/i.test(name)) return 'Video';
    return 'GIP';
  }
  var SORT_PRESETS = {
    default: {label:'默认顺序',order:['CKV','CKH','GIP','Video']},
    name: {label:'名称顺序'}
  };
  function listedSignal(name) { return state.listCategories.includes(signalCategory(name)); }
  function listedGroupIndices() { var indices=[];state.groups.forEach(function(group,i){if(group.some(listedSignal))indices.push(i);});return indices; }
  function sortSignalGroups(preset,allGroups) {
    var selected=SORT_PRESETS[preset||'default']||SORT_PRESETS.default,names=signalNames();
    var indices=allGroups?state.groups.map(function(_,i){return i;}):listedGroupIndices();
    var groups=indices.map(function(i){return state.groups[i];});
    function firstName(group){var shown=allGroups?group:group.filter(listedSignal);return shown.slice().sort(function(a,b){return a.localeCompare(b,undefined,{numeric:true});})[0];}
    function rank(group){var shown=allGroups?group:group.filter(listedSignal);return Math.min.apply(null,shown.map(function(n){return selected.order.indexOf(signalCategory(n));}));}
    groups.sort(function(a,b){return selected.order?(rank(a)-rank(b)||names.indexOf(firstName(a))-names.indexOf(firstName(b))):firstName(a).localeCompare(firstName(b),undefined,{numeric:true});});
    indices.forEach(function(i,index){state.groups[i]=groups[index];});
  }

  // ---- 分组（合并/拆开）辅助 ----
  // 信号所在组索引
  function groupIndexOf(name) {
    if (!state.groups || !state.groups.length) return -1;
    for (var i = 0; i < state.groups.length; i++) {
      if (state.groups[i].indexOf(name) >= 0) return i;
    }
    return -1;
  }

  // 把 src 并入 dst 所在组
  function mergeInto(src, dst) {
    var si = groupIndexOf(src), di = groupIndexOf(dst);
    if (si < 0 || di < 0 || si === di) return;
    state.groups[si] = state.groups[si].filter(function (n) { return n !== src; });
    if (state.groups[si].length === 0) state.groups.splice(si, 1);
    di = groupIndexOf(dst); // 上面可能删除了组，重新定位
    state.sortPreset='custom';
    state.groups[di].push(src);
    state.visible[src] = true;state.visible[dst] = true;
  }

  // 从组内拖出单个信号（独立成新组，插到原组之后）
  function pullOut(name) {
    var gi = groupIndexOf(name);
    if (gi < 0) return;
    var grp = state.groups[gi];
    if (grp.length <= 1) return;
    state.sortPreset='custom';
    state.groups[gi] = grp.filter(function (n) { return n !== name; });
    state.groups.splice(gi + 1, 0, [name]);
  }

  // 移动分组块（排序）：把 from 移到 to 位置（before=true 插到 to 前，否则插到后）
  function moveGroup(from, to, before) {
    if (from < 0 || to < 0 || from === to) return;
    state.sortPreset='custom';
    var arr = state.groups;
    var grp = arr.splice(from, 1)[0];
    var newTo = from < to ? to - 1 : to;
    var insertIdx = before ? newTo : newTo + 1;
    if (insertIdx < 0) insertIdx = 0;
    if (insertIdx > arr.length) insertIdx = arr.length;
    arr.splice(insertIdx, 0, grp);
  }

  // 拖信号到分组块位置：拖出该信号独立成新组，插到目标组前/后
  function pullOutTo(name, gi, before) {
    if (!state.groups[gi]) return;
    var fromGi = groupIndexOf(name);
    if (fromGi < 0) return;
    var grp = state.groups[fromGi];
    if (grp.length <= 1) { moveGroup(fromGi, gi, before); return; }
    state.sortPreset='custom';
    state.groups[fromGi] = grp.filter(function (n) { return n !== name; });
    var arr = state.groups;
    var insertIdx = before ? gi : gi + 1;
    if (insertIdx < 0) insertIdx = 0;
    if (insertIdx > arr.length) insertIdx = arr.length;
    arr.splice(insertIdx, 0, [name]);
  }

  // 同步分组：补新信号、移除失效信号
  function syncGroups() {
    var names = signalNames();
    if (!state.groups || !state.groups.length) {
      state.groups = names.map(function (n) { return [n]; });
      sortSignalGroups(undefined,true);
      return;
    }
    var existing = {};
    state.groups.forEach(function (g) { g.forEach(function (n) { existing[n] = true; }); });
    state.groups = state.groups
      .map(function (g) { return g.filter(function (n) { return names.indexOf(n) >= 0; }); })
      .filter(function (g) { return g.length > 0; });
    names.forEach(function (n) { if (!existing[n]) state.groups.push([n]); });
  }

  // 当前要显示的分组（只含可见信号的组，且至少一个可见）
  function visibleGroups() {
    if (!state.groups || !state.groups.length) return [];
    return state.groups
      .map(function (g) { return g.filter(function (n) { return listedSignal(n) && state.visible[n]; }); })
      .filter(function (g) { return g.length > 0; });
  }

  // ---- 存储 ----
  var STORE_KEY = 'stg_params_v1';
  function saveToStorage(vals) {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(vals)); } catch (e) { /* ignore */ }
  }
  function loadFromStorage() {
    try {
      var s = localStorage.getItem(STORE_KEY);
      return s ? JSON.parse(s) : null;
    } catch (e) { return null; }
  }

  // ---- 保存/加载方案 ----
  function savePlan() {
    var vals = collectValues();
    var blob = new Blob([JSON.stringify(vals, null, 2)], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'STG方案_' + timestamp() + '.json';
    a.click();
    URL.revokeObjectURL(a.href);
  }
  function loadPlan() {
    var inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = '.json';
    inp.onchange = function () {
      var f = inp.files[0];
      if (!f) return;
      var r = new FileReader();
      r.onload = function () {
        try {
          state.vals = Object.assign(CFG.defaults(), CFG.normalizeValues(JSON.parse(r.result)));
          applyValues(state.vals);
          generate();
          if (activeTab === 'pattern') showTab('pattern');
        } catch (e) { alert('方案文件解析失败'); }
      };
      r.readAsText(f);
    };
    inp.click();
  }
  function timestamp() {
    var d = new Date();
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return '' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes());
  }

  function renderQuickConfiguration(container) {
    var box=el('section','quick-configuration');
    var bar=el('div','quick-actions');var open=el('button','tbtn','粘贴电性参数');open.type='button';bar.appendChild(open);
    var preset=el('select');preset.setAttribute('aria-label','其他参数默认配置');
    [['factory','工具默认配置'],['personal','我的默认配置']].forEach(function(pair){var opt=el('option','',pair[1]);opt.value=pair[0];preset.appendChild(opt);});bar.appendChild(preset);
    var applyDefault=el('button','tbtn','应用到其他参数'),saveDefault=el('button','tbtn','保存为我的默认配置');bar.appendChild(applyDefault);bar.appendChild(saveDefault);box.appendChild(bar);
    var status=el('p','quick-status');status.setAttribute('role','status');box.appendChild(status);
    var editor=el('div','paste-editor');editor.hidden=true;var text=el('textarea');text.placeholder='从 Excel 复制参数名称和值，整块粘贴到这里';text.setAttribute('aria-label','电性参数粘贴内容');editor.appendChild(text);
    var review=el('button','tbtn','识别并检查'),apply=el('button','tbtn','填入电性评估表');apply.disabled=true;editor.appendChild(review);editor.appendChild(apply);var preview=el('div','paste-preview');editor.appendChild(preview);box.appendChild(editor);container.appendChild(box);
    var evaluation=CFG.groups.find(function(g){return g.id==='eval';}).params.map(function(p){return p.key;}),rows=[],aliases={};try{aliases=JSON.parse(localStorage.getItem('stg_evaluation_aliases')||'{}');}catch(e){}
    function refresh(){preview.innerHTML='';var table=el('table','paste-table');var patch={},duplicates=[];rows.forEach(function(row){var tr=el('tr');tr.appendChild(el('td','',row.name));var td=el('td'),select=el('select');var ignore=el('option','','不导入');ignore.value='';select.appendChild(ignore);
      evaluation.filter(function(k){return k!=='CKHnum';}).forEach(function(key){var opt=el('option','',key);opt.value=key;select.appendChild(opt);});select.value=row.key;select.onchange=function(){row.key=select.value;refresh();};td.appendChild(select);tr.appendChild(td);tr.appendChild(el('td','',row.value));table.appendChild(tr);if(row.key){if(patch[row.key]!==undefined)duplicates.push(row.key);patch[row.key]=row.value;}});preview.appendChild(table);
      var merged=Object.assign({},state.vals,patch),result=global.STGEvaluationImport.check(merged);var message=el('div',result.errors.length||duplicates.length?'paste-errors':'paste-success');message.setAttribute('role','status');
      var missing=evaluation.filter(function(key){return key!=='CKHnum'&&patch[key]===undefined;});
      message.textContent=(duplicates.length?'重复参数：'+duplicates.join('、')+'。 ':'')+(result.errors.length?result.errors.join('\n'):'公式检查通过，CKHnum = '+result.count)+(missing.length?'\n未粘贴的参数沿用当前值：'+missing.join('、'):'');preview.appendChild(message);apply.disabled=!Object.keys(patch).length||!!duplicates.length;apply._patch=patch;apply._result=result;
    }
    open.onclick=function(){editor.hidden=!editor.hidden;if(!editor.hidden)text.focus();};
    text.oninput=function(){apply.disabled=true;preview.innerHTML='';};
    review.onclick=function(){rows=global.STGEvaluationImport.parse(text.value,aliases);refresh();if(!rows.length)preview.textContent='未识别到参数名和值，请复制含名称及数值的单元格区域。';};
    apply.onclick=function(){state.vals=Object.assign({},collectValues(),apply._patch,{CKHnum:apply._result.count});rows.forEach(function(row){if(row.key)aliases[global.STGEvaluationImport.normalize(row.name)]=row.key;});try{localStorage.setItem('stg_evaluation_aliases',JSON.stringify(aliases));}catch(e){}syncVideoCount(state.vals,true);saveToStorage(state.vals);applyValues(state.vals);showTab('params');var card=document.querySelector('.acc-item');if(card)card.classList.add('open');};
    saveDefault.onclick=function(){state.vals=collectValues();var other={};Object.keys(state.vals).forEach(function(key){if(!evaluation.includes(key))other[key]=state.vals[key];});try{localStorage.setItem('stg_personal_defaults',JSON.stringify(other));status.textContent='已保存其他参数为我的默认配置。';}catch(e){status.textContent='浏览器无法保存默认配置。';}};
    applyDefault.onclick=function(){state.vals=collectValues();var defaults=CFG.defaults();if(preset.value==='personal'){try{defaults=JSON.parse(localStorage.getItem('stg_personal_defaults')||'null');}catch(e){defaults=null;}if(!defaults){status.textContent='尚未保存我的默认配置。';return;}}
      if(preset.value==='factory'){[2,3,4,6].forEach(function(mux){['positive','negative'].forEach(function(frame){for(var line=1;line<=2;line++){var order=Array.from({length:mux},function(_,i){return i+1;});if(line===2)order.reverse();defaults['CKHMode_'+mux+'_'+frame+'_'+line]=order.join(' ');}});});}
      Object.keys(defaults).forEach(function(key){if(!evaluation.includes(key))state.vals[key]=defaults[key];});if(preset.value==='factory')delete state.vals.PatternConfig;syncVideoCount(state.vals,true);saveToStorage(state.vals);applyValues(state.vals);showTab('params');document.querySelector('.quick-status').textContent='其他参数已应用默认配置，电性评估表保持当前值。';};
  }

  // ---- 参数配置页（折叠卡片 + 搜索）----
  function renderParams(container) {
    syncVideoCount(state.vals);
    renderQuickConfiguration(container);
    var search = el('div', 'param-search');
    var si = el('input');
    si.type = 'text';
    si.placeholder = '搜索参数（按名称/编号）...';
    search.appendChild(si);
    container.appendChild(search);

    var wrap = el('div', 'param-acc');
    container.appendChild(wrap);

    CFG.groups.forEach(function (g, gi) {
      var item = el('div', 'acc-item');

      // 封面
      var cover = el('div', 'acc-cover');
      var top = el('div', 'acc-cover-top');
      var title = el('span', 'acc-title', g.title.replace(/^\d+\.\s*/, ''));
      top.appendChild(title);
      top.appendChild(el('span', 'acc-icon', g.icon || ''));
      cover.appendChild(top);

      var preview = el('div', 'acc-preview');
      if (g.id === 'tp') {
        var durationRow = el('div', 'pv-row tp-time-row');
        durationRow.appendChild(el('span', 'pv-name', 'TPtime'));
        var duration = el('output', 'pv-val tp-duration');
        duration.id = 'tp-duration';
        duration.setAttribute('aria-label', 'TPtime 总时长');
        duration.setAttribute('aria-live', 'polite');
        durationRow.appendChild(duration);
        preview.appendChild(durationRow);
      }
      (g.id === 'ckh-mode' ? [] : g.params.slice(0, g.id === 'tp' ? 2 : 3)).forEach(function (p) {
        var r = el('div', 'pv-row');
        r.appendChild(el('span', 'pv-name', p.label));
        r.appendChild(el('span', 'pv-val', formatPreview(p)));
        preview.appendChild(r);
      });
      if (g.id === 'ckh-mode') preview.appendChild(el('div', 'pv-row', '正帧 / 负帧 · 2 / 3 / 4 / 6mux'));
      cover.appendChild(preview);

      var bottom = el('div', 'acc-cover-bottom');
      bottom.appendChild(el('span', 'acc-count', '共 ' + g.params.length + ' 个参数'));
      bottom.appendChild(el('span', 'acc-arrow', '▼'));
      cover.appendChild(bottom);

      cover.onclick = function () { item.classList.toggle('open'); };
      item.appendChild(cover);

      // 展开体
      var body = el('div', 'acc-body');
      if (g.id === 'ckh-mode') {
        renderCKHMode(body);
      } else if (g.sections) {
        body.classList.add('param-sections');
        g.sections.forEach(function (section) {
          var group = el('section', 'param-section');
          if (section.fullWidth) group.classList.add('full-width');
          if (section.compact) group.classList.add('compact');
          else group.appendChild(el('h2', 'param-section-title', section.title));
          var grid = el('div', 'param-grid');
          section.keys.forEach(function (key) {
            var p = g.params.find(function (param) { return param.key === key; });
            grid.appendChild(buildParamRow(p));
          });
          group.appendChild(grid);
          body.appendChild(group);
        });
      } else {
        var grid = el('div', 'param-grid');
        g.params.forEach(function (p) {
          grid.appendChild(buildParamRow(p));
        });
        body.appendChild(grid);
      }
      if (g.id === 'ckv' || g.id === 'ckh') {
        var notice = el('div', 'eq-timing-notice');
        notice.id = g.id + '-eq-notice';
        notice.setAttribute('role', 'status');
        notice.setAttribute('aria-live', 'polite');
        body.appendChild(notice);
      }
      item.appendChild(body);
      wrap.appendChild(item);
    });

    syncVideoCount(state.vals);
    updateTouchDuration(state.vals);
    updateEQNotices(state.vals);
    updateEvaluation(state.vals);
    function onParamEdit(event) {
      var key = event.target.getAttribute('data-key');
      if (['DumVSR', 'endCKV', 'VSR_Mode'].indexOf(key) >= 0) {
        var rows = CFG.deriveDummyRows(collectValues());
        if (rows) Object.keys(rows).forEach(function (rowKey) {
          var input = wrap.querySelector('[data-key="' + rowKey + '"]');
          input.value = rows[rowKey];
        });
      }
      state.vals = collectValues();
      // Finish typing the requested count before matching widths; other fields retain live calculation.
      updateEvaluation(state.vals, key==='CKHnum' && event.type==='input' ? undefined : key);
      saveToStorage(state.vals);
      updateTouchDuration(state.vals);
      updateEQNotices(state.vals);
    }
    wrap.addEventListener('input', onParamEdit);
    wrap.addEventListener('change', onParamEdit);

    si.oninput = function () {
      var q = si.value.trim().toLowerCase();
      wrap.querySelectorAll('.acc-item').forEach(function (it) {
        var rows = it.querySelectorAll('.param-row');
        var hit = 0;
        rows.forEach(function (r) {
          var t = (r.getAttribute('data-search') || '');
          var show = !q || t.indexOf(q) >= 0;
          r.style.display = show ? '' : 'none';
          if (show) hit++;
        });
        it.querySelectorAll('.param-section').forEach(function (section) {
          var hasHit = Array.prototype.some.call(section.querySelectorAll('.param-row'), function (row) {
            return row.style.display !== 'none';
          });
          section.style.display = hasHit ? '' : 'none';
        });
        if (q) {
          if (hit > 0) it.classList.add('open');
          else it.classList.remove('open');
        }
      });
      if (!q) renderParamsRestore(wrap);
    };
  }

  function renderCKHMode(body) {
    var help=el('details','mode-help');
    var helpToggle=el('summary','','?');helpToggle.setAttribute('aria-label','CKH_Mode 使用说明');helpToggle.title='使用说明';help.appendChild(helpToggle);
    help.appendChild(el('p','mode-note','从左到右 = 时隙先后；数字 = CKH 通道编号。例如 3 4 2 1 表示依次触发 CKH3 → CKH4 → CKH2 → CKH1。每行独立配置。'));
    body.appendChild(help);
    var controls = el('div', 'mode-controls');
    var panels = [];
    var buttons = [];
    body.appendChild(controls);
    [2, 3, 4, 6].forEach(function (mux) {
      var button = el('button', 'tbtn', mux + 'mux');
      button.type = 'button';
      button.setAttribute('data-mode-mux',mux);
      controls.appendChild(button);
      buttons.push(button);
      var panel = el('div', 'mode-frames');
      panel.hidden = true;
      panel.setAttribute('data-mode-mux',mux);
      panels.push(panel);
      ['positive', 'negative'].forEach(function (frame) {
        var section = el('section', 'param-section mode-frame');
        section.appendChild(el('h2', 'param-section-title', frame === 'positive' ? '正帧' : '负帧'));
        var countKey = 'CKHMode_' + mux + '_' + frame + '_rows';
        var rowCount = Math.max(1, Math.min(512, parseInt(state.vals[countKey], 10) || 2));
        var countInput = el('input');
        countInput.type = 'hidden';
        countInput.setAttribute('data-key', countKey);
        countInput.value = rowCount;
        section.appendChild(countInput);
        var table = el('table', 'mode-table');
        var header = el('tr');
        header.appendChild(el('th', '', '行'));
        header.appendChild(el('th', '', 'CKH 触发顺序 →'));
        table.appendChild(header);
        for (var line = 1; line <= rowCount; line++) {
          var row = el('tr', 'param-row');
          row.setAttribute('data-search', ('ckh_mode ckh model ' + mux + 'mux ' + frame + ' line' + line).toLowerCase());
          row.appendChild(el('th', '', 'line' + line));
          var cell = el('td');
          var input = el('input');
          var key = 'CKHMode_' + mux + '_' + frame + '_' + line;
          input.type = 'text';
          input.setAttribute('data-key', key);
          input.setAttribute('aria-label', (frame === 'positive' ? '正帧' : '负帧') + ' ' + mux + 'mux line' + line);
          input.value = state.vals[key] || '';
          input.placeholder = '填写 ' + mux + ' 个通道编号';
          var hint = el('div', 'mode-error');
          hint.setAttribute('role', 'status');
          input.oninput = (function (field, message, count) {
            return function () {
              var parts = field.value.trim().split(/[\s,，]+/);
              var valid = parts.length === count && parts.every(function (x) { return /^[1-6]$/.test(x) && Number(x) <= count; }) && new Set(parts).size === count;
              field.setAttribute('aria-invalid', field.value.trim() && !valid ? 'true' : 'false');
              message.textContent = field.value.trim() && !valid ? '请将 1～' + count + ' 各填写一次，以空格分隔。' : '';
            };
          })(input, hint, mux);
          input.oninput();
          cell.appendChild(input);
          cell.appendChild(hint);
          row.appendChild(cell);
          table.appendChild(row);
        }
        section.appendChild(table);
        var actions = el('div', 'mode-controls');
        var add = el('button', 'tbtn', '+ 增加一行');
        var remove = el('button', 'tbtn', '移除末行');
        add.type = remove.type = 'button';
        add.disabled = rowCount >= 512;
        remove.disabled = rowCount <= 1;
        function resizeRows(count) {
          state.vals = collectValues();
          state.vals[countKey] = count;
          state.modeMux = mux;
          saveToStorage(state.vals);
          body.innerHTML = '';
          renderCKHMode(body);
        }
        add.onclick = function () { resizeRows(rowCount + 1); };
        remove.onclick = function () { resizeRows(rowCount - 1); };
        actions.appendChild(add);
        actions.appendChild(remove);
        section.appendChild(actions);
        panel.appendChild(section);
      });
      body.appendChild(panel);
      button.onclick = function () {
        state.modeMux = mux;
        panels.forEach(function (p) { p.hidden = p !== panel; });
        buttons.forEach(function (b) { b.classList.toggle('active', b === button); b.setAttribute('aria-pressed', b === button ? 'true' : 'false'); });
      };
    });
    syncModeMux(state.vals);
  }

  function syncModeMux(vals) {
    document.querySelectorAll('.mode-controls [data-mode-mux]').forEach(function(button){
      var active=Number(button.getAttribute('data-mode-mux'))===Number(vals.CKHnum);
      button.disabled=!active;button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));
    });
    document.querySelectorAll('.mode-frames[data-mode-mux]').forEach(function(panel){panel.hidden=Number(panel.getAttribute('data-mode-mux'))!==Number(vals.CKHnum);});
  }

  function renderParamsRestore(wrap) {
    wrap.querySelectorAll('.acc-item').forEach(function (it) {
      it.classList.remove('open');
      it.querySelectorAll('.param-row').forEach(function (r) { r.style.display = ''; });
      it.querySelectorAll('.param-section').forEach(function (section) { section.style.display = ''; });
    });
  }

  function updateEQNotices(vals) {
    ['CKV', 'CKH'].forEach(function (prefix) {
      var output = $(prefix.toLowerCase() + '-eq-notice');
      if (!output) return;
      output.hidden = String(vals[prefix + 'EQ_SET']) !== '是';
      if (output.hidden) return;
      var errors = prefix === 'CKV' ? CFG.validateCKVEQ(vals) : CFG.validateCKHEQ(vals);
      output.classList.toggle('invalid', errors.length > 0);
      output.textContent = '';
      output.appendChild(el('strong', '', prefix + ' EQ 时间调整'));
      output.appendChild(el('p', '', '相位锚点2、3按 Normal 参数固定；EQ 仅改变实际形状拐点，引用信号不随 EQ 移动。'));
      if (errors.length) {
        errors.forEach(function (error) { output.appendChild(el('p', '', error)); });
        return;
      }
      var timing = prefix === 'CKV' ? CFG.ckvTiming(vals) : CFG.ckhTiming(vals);
      function time(value) { return String(Number(value.toFixed(6))) + ' μs'; }
      [['tr', '上升沿', timing.rise], ['tf', '下降沿', timing.fall]].forEach(function (edge) {
        var normal = Number(vals[prefix + '_' + edge[0]]), difference = edge[2] - normal;
        var action = difference > 1e-9 ? '多出的 ' + time(difference) + ' 从高电平保持段扣除。'
          : difference < -1e-9 ? '省下的 ' + time(-difference) + ' 补回高电平保持段（点2～点3）。'
          : '时间相同，不调整高电平保持段。';
        output.appendChild(el('p', '', edge[1] + '：EQ 总时间 ' + time(edge[2]) + '，普通 ' + edge[0] + ' ' + time(normal) + '；' + action));
      });
      var widthKey = prefix === 'CKV' ? 'CKV_width' : 'CKH_Width';
      output.appendChild(el('p', '', '高电平保持时间：' + time(Number(vals[widthKey])) + ' → ' + time(Math.max(0, timing.width)) + '。周期与 gap 保持不变。'));
    });
  }

  function updateTouchDuration(vals) {
    var output = $('tp-duration');
    if (!output) return;
    var enabled = String(vals.isTpExist).toUpperCase() === 'Y';
    output.textContent = String(Number(CFG.touchDuration(vals).toFixed(6))) + ' μs';
    output.classList.toggle('inactive', !enabled);
    output.parentElement.classList.toggle('inactive', !enabled);
    output.setAttribute('aria-disabled', String(!enabled));
  }

  function buildParamRow(p) {
    var row = el('div', 'param-row');
    row.setAttribute('data-search', (p.label + ' ' + p.key).toLowerCase());
    row.appendChild(el('label', '', p.label));
    var val = state.vals[p.key];
    if (p.type === 'select') {
      var sel = el('select');
      sel.setAttribute('data-key', p.key);
      p.options.forEach(function (o) {
        var opt = el('option', '', o);
        opt.value = o;
        if (String(val) === String(o)) opt.selected = true;
        sel.appendChild(opt);
      });
      row.appendChild(sel);
    } else {
      var inp = el('input');
      inp.setAttribute('data-key', p.key);
      inp.type = (p.type === 'number') ? 'number' : 'text';
      inp.step = 'any';
      inp.value = val;
      if(p.key==='CKHnum'){inp.readOnly=false;inp.disabled=false;inp.step='1';inp.min='2';inp.max='6';inp.setAttribute('aria-label','CKHnum');inp.onkeydown=function(event){if(event.key==='Enter'){event.preventDefault();inp.blur();}};inp.title='输入 2、3、4、6，自动匹配 CKH_Width、CKV_width、CKV_period，其他电性参数保持不变。';}
      if(['CKV_gap','CKH_gap','VTH','HTV'].includes(p.key)){inp.title='允许负数：gap 表示通道交叠，VTH / HTV 表示前后时序偏移。';}
      if(p.key==='Stringlong'){inp.min='64';inp.step='1';inp.title='开启自动续行后，每行最多包含这些字符；续行以 + 开头，时间和电压数值对保持完整。';}
      row.appendChild(inp);
    }
    if (p.unit) row.appendChild(el('span', 'unit', p.unit));
    return row;
  }

  // 封面参数预览：当前值 + 单位
  function formatPreview(p) {
    var val = state.vals[p.key];
    var s = (val === undefined || val === '') ? p.def : val;
    return String(s) + (p.unit ? ' ' + p.unit : '');
  }

  function applyValues(vals) {
    syncVideoCount(vals);
    document.querySelectorAll('[data-key]').forEach(function (inp) {
      var key = inp.getAttribute('data-key');
      if (vals[key] !== undefined) inp.value = vals[key];
    });
    updateTouchDuration(vals);
    var controls = document.querySelector('.mode-controls');
    if (controls) {
      var body = controls.parentElement;
      body.innerHTML = '';
      renderCKHMode(body);
    }
    updateEQNotices(vals);
  }

  // ---- SPICE 文本 ----
  function toSpice(result) {
    var names = signalNames(), lines = [];
    var wrap = state.vals.SpiceWrap !== '关闭', limit = Number(state.vals.Stringlong);
    if(wrap&&(!Number.isInteger(limit)||limit<64))throw new Error('Stringlong 每行字符上限必须是至少 64 的整数；或关闭自动续行。');
    names.forEach(function (name) {
      var pts = result.signals[name];
      if (!pts || !pts.length) return;
      var line = 'v' + name + ' ' + name + ' 0 pwl (';
      function append(chunk){
        if(wrap&&line.length+chunk.length>limit){lines.push(line);line='+'+chunk;}
        else line+=chunk;
      }
      pts.forEach(function (p) { append(' ' + fmt(p[0]) + 'u ' + fmt(p[1]) + 'v'); });
      append('  R 0u)');
      lines.push(line);
    });
    return lines.join('\n');
  }

  // ---- 时序文本页 ----
  function renderOutput(container) {
    var wrap = el('div', 'output-wrap');
    var tb = el('div', 'output-toolbar');
    var copy = el('button', 'tbtn', '复制全部');
    var dl = el('button', 'tbtn', '下载 .txt');
    tb.appendChild(copy);
    tb.appendChild(dl);
    wrap.appendChild(tb);

    var code = el('pre', 'output-code');
    if (!state.result) {
      code.textContent = '请先生成波形';
    } else {
      try{code.textContent = toSpice(state.result);}
      catch(error){code.textContent=error.message;copy.disabled=true;dl.disabled=true;}
    }
    wrap.appendChild(code);
    container.appendChild(wrap);

    copy.onclick = function () {
      var text = code.textContent;
      navigator.clipboard.writeText(text).then(function () {
        copy.textContent = '已复制';
        setTimeout(function () { copy.textContent = '复制全部'; }, 1200);
      });
    };
    dl.onclick = function () {
      var blob = new Blob([code.textContent], { type: 'text/plain' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'STG_timing.txt';
      a.click();
      URL.revokeObjectURL(a.href);
    };
  }

  // 渲染信号列表（合并区 + 把手排序 + 拖拽合并 + 拖出单个信号）
  function renderSignalList(list) {
    list.innerHTML = '';
    var presets=el('div','signal-presets');
    function presetSelect(label,options,value,action){
      var wrap=el('label','signal-preset-field');wrap.appendChild(el('span','',label));
      var select=el('select');select.setAttribute('aria-label',label+'方案');
      var custom=el('option','','当前顺序');custom.value='custom';custom.disabled=true;select.appendChild(custom);
      Object.keys(options).forEach(function(key){var option=el('option','',options[key].label);option.value=key;select.appendChild(option);});
      select.title='仅排序当前筛选到的信号组，保留合并关系；可跨分类拖拽调整';
      select.value=value;select.onchange=function(){action(select.value);};wrap.appendChild(select);presets.appendChild(wrap);
    }
    presetSelect('排序',SORT_PRESETS,state.sortPreset,function(key){state.sortPreset=key;sortSignalGroups(key);renderSignalList(list);renderChart();});
    var filter=el('details','signal-list-filter');filter.open=state.filterMenuOpen;
    var summary=el('summary',''),filterLabel=el('span','','显示：'),filterValue=el('span','filter-value');
    summary.appendChild(filterLabel);summary.appendChild(filterValue);summary.setAttribute('aria-label','列表显示筛选');filter.appendChild(summary);
    var menu=el('div','signal-filter-menu');filter.appendChild(menu);
    var filterKeys=['CKV','CKH','Video','GIP','all','none'],boxes={};
    function refreshFilter(){filterKeys.forEach(function(key){boxes[key].checked=key==='all'?state.listCategories.length===4&&signalNames().every(function(n){return state.visible[n];}):key==='none'?state.listCategories.length===0:state.listCategories.includes(key);boxes[key].indeterminate=key==='all'&&state.listCategories.length===4&&!boxes[key].checked&&signalNames().some(function(n){return state.visible[n];});});filterValue.textContent=state.listCategories.length===4?(boxes.all.checked?'全部显示':'全部分类 · 部分隐藏'):state.listCategories.length?['CKV','CKH','Video','GIP'].filter(function(key){return state.listCategories.includes(key);}).join(' + '):'全部隐藏';}
    filterKeys.forEach(function(key){var label=el('label','signal-filter-option'),box=el('input');box.type='checkbox';box.setAttribute('data-list-filter',key);box.setAttribute('aria-label',key==='all'?'全部显示':key==='none'?'全部隐藏':key);boxes[key]=box;label.appendChild(box);label.appendChild(el('span','',key==='all'?'全部显示':key==='none'?'全部隐藏':key));menu.appendChild(label);
      box.onchange=function(){if(key==='all'){state.listCategories=box.checked?['CKV','CKH','Video','GIP']:[];if(box.checked)signalNames().forEach(function(n){state.visible[n]=true;});}else if(key==='none'){state.listCategories=box.checked?[]:['CKV','CKH','Video','GIP'];if(!box.checked)signalNames().forEach(function(n){state.visible[n]=true;});}else if(box.checked){if(!state.listCategories.includes(key))state.listCategories.push(key);}else state.listCategories=state.listCategories.filter(function(category){return category!==key;});state.filterMenuOpen=true;state.sortPreset='custom';renderSignalList(list);renderChart();var next=list.querySelector('[data-list-filter="'+key+'"]');if(next)next.focus();};
    });refreshFilter();filter.ontoggle=function(){if(filter.isConnected)state.filterMenuOpen=filter.open;};presets.appendChild(filter);
    list.appendChild(presets);
    var shownIndices=listedGroupIndices();
    if(!shownIndices.length)list.appendChild(el('div','signal-list-empty','信号列表和波形已全部隐藏。'));
    state.groups.forEach(function (grp, gi) {
      var shown=grp.filter(listedSignal);if(!shown.length)return;
      var position=shownIndices.indexOf(gi),previous=shownIndices[position-1],next=shownIndices[position+1];
      var gblock = el('div', 'sig-group' + (grp.length > 1 ? ' merged' : ''));
      gblock.setAttribute('data-gi', gi);

      // 上移/下移按钮
      var up = el('button', 'move-btn', '▲');
      up.title = '上移';up.setAttribute('aria-label','上移');up.disabled=position===0;
      up.onclick = function (ev) {
        ev.stopPropagation();
        if (previous !== undefined) { moveGroup(gi, previous, true); renderSignalList(list); renderChart(); }
      };
      var down = el('button', 'move-btn', '▼');
      down.title = '下移';down.setAttribute('aria-label','下移');down.disabled=position===shownIndices.length-1;
      down.onclick = function (ev) {
        ev.stopPropagation();
        if (next !== undefined) { moveGroup(gi, next, false); renderSignalList(list); renderChart(); }
      };

      if (grp.length > 1) {
        var ghead = el('div', 'sig-group-head');
        ghead.appendChild(up);
        ghead.appendChild(down);
        var groupTitle=el('span','gh-title','合并区 '+(gi+1)+' · '+Array.from(new Set(shown.map(signalCategory))).join(' + '));groupTitle.title=grp.join(' + ');ghead.appendChild(groupTitle);
        gblock.appendChild(ghead);
      }

      shown.forEach(function (n) {
        var row = el('div', 'sig-row' + (state.visible[n] ? '' : ' off'));
        row.setAttribute('draggable', 'true');
        row.setAttribute('data-sig', n);
        row.title='点击显隐；拖到中间合并，拖到上沿或下沿调整顺序';

        if (grp.length === 1) { row.appendChild(up); row.appendChild(down); }

        var dot = el('span', 'dot');
        dot.style.background = signalColor(n);
        row.appendChild(dot);
        row.appendChild(el('span', 'name', n));

        if (grp.length > 1) {
          var pb = el('button', 'pull-btn', '拖出');
          pb.title = '拖出该信号';
          pb.onclick = function (ev) {
            ev.stopPropagation();
            pullOut(n);
            renderSignalList(list);
            renderChart();
          };
          row.appendChild(pb);
        }

        row.onclick = function () {
          state.visible[n] = !state.visible[n];
          renderSignalList(list);
          renderChart();
        };

        row.addEventListener('dragstart', function (ev) {
          state.dragSrc = n;
          try { ev.dataTransfer.setData('text/plain', n); } catch (e) { /* ignore */ }
          ev.dataTransfer.effectAllowed = 'move';
          ev.stopPropagation();
          row.classList.add('dragging');
        });
        row.addEventListener('dragover', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          ev.dataTransfer.dropEffect = 'move';
          if (state.dragSrc && state.dragSrc !== n) {
            var bounds=row.getBoundingClientRect(),edge=ev.clientY-bounds.top<6?'insert-before':bounds.bottom-ev.clientY<6?'insert-after':'drop-target';
            row.classList.remove('drop-target','insert-before','insert-after');row.classList.add(edge);
          }
        });
        row.addEventListener('dragleave', function () { row.classList.remove('drop-target','insert-before','insert-after'); });
        row.addEventListener('drop', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          row.classList.remove('drop-target','insert-before','insert-after');
          if (state.dragSrc && state.dragSrc !== n) {
            var bounds=row.getBoundingClientRect();
            if(ev.clientY-bounds.top<6)pullOutTo(state.dragSrc,gi,true);
            else if(bounds.bottom-ev.clientY<6)pullOutTo(state.dragSrc,gi,false);
            else mergeInto(state.dragSrc, n);
            renderSignalList(list);
            renderChart();
          }
          state.dragSrc = null;
        });
        row.addEventListener('dragend', function () {
          state.dragSrc = null;
          row.classList.remove('dragging');
          list.querySelectorAll('.drop-target').forEach(function (r) { r.classList.remove('drop-target'); });
        });

        gblock.appendChild(row);
      });

      // 分组块作为 drop 目标（拖出）
      gblock.addEventListener('dragover', function (ev) {
        ev.preventDefault();
        ev.dataTransfer.dropEffect = 'move';
        if (state.dragSrc) {
          var rect = gblock.getBoundingClientRect();
          state.dragBefore = (ev.clientY - rect.top) < rect.height / 2;
          gblock.classList.remove('insert-before', 'insert-after');
          gblock.classList.add(state.dragBefore ? 'insert-before' : 'insert-after');
        }
      });
      gblock.addEventListener('dragleave', function () { gblock.classList.remove('insert-before', 'insert-after'); });
      gblock.addEventListener('drop', function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        gblock.classList.remove('insert-before', 'insert-after');
        if (state.dragSrc) {
          pullOutTo(state.dragSrc, gi, state.dragBefore);
          renderSignalList(list);
          renderChart();
        }
        state.dragSrc = null;
      });

      list.appendChild(gblock);
    });
  }

  // ---- 波形页 ----
  function renderWave(container) {
    var page = el('div', 'chart-page');

    var panel = el('div', 'signal-panel');
    panel.appendChild(el('div', 'panel-title', '信号列表（分类显隐 · 点击单条显隐）'));
    var list = el('div', 'signal-list');
    renderSignalList(list);
    panel.appendChild(list);
    page.appendChild(panel);
    var splitter=el('div','wave-splitter');splitter.tabIndex=0;splitter.setAttribute('role','separator');splitter.setAttribute('aria-orientation','vertical');splitter.setAttribute('aria-label','调整信号列表和波形宽度');splitter.title='左右拖动调整宽度；双击恢复默认';page.appendChild(splitter);
    try{var saved=Number(localStorage.getItem('stg_wave_panel_width'));if(Number.isFinite(saved)&&saved>=150)state.panelWidth=saved;}catch(e){}
    function setPanelWidth(width,save){
      var maximum=Math.max(150,Math.min(700,page.clientWidth-200));state.panelWidth=Math.max(150,Math.min(maximum,width));panel.style.flexBasis=state.panelWidth+'px';
      splitter.setAttribute('aria-valuemin','150');splitter.setAttribute('aria-valuemax',String(maximum));splitter.setAttribute('aria-valuenow',String(Math.round(state.panelWidth)));
      if(save)try{localStorage.setItem('stg_wave_panel_width',String(state.panelWidth));}catch(e){}
      if(state.chart)state.chart.resize();
    }
    splitter.onpointerdown=function(event){
      event.preventDefault();splitter.setPointerCapture(event.pointerId);var start=event.clientX,width=panel.getBoundingClientRect().width;
      splitter.classList.add('dragging');
      splitter.onpointermove=function(move){setPanelWidth(width+move.clientX-start,true);};
      function finish(){splitter.classList.remove('dragging');splitter.onpointermove=null;splitter.onpointerup=null;splitter.onpointercancel=null;}
      splitter.onpointerup=finish;splitter.onpointercancel=finish;
    };
    splitter.onkeydown=function(event){if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();setPanelWidth(state.panelWidth+(event.key==='ArrowLeft'?-10:10),true);}};
    splitter.ondblclick=function(){setPanelWidth(220,true);};

    var area = el('div', 'wave-area');
    var toolbar = el('div', 'wave-toolbar');
    var reset = el('button', 'tbtn', '重置视图');
    var png = el('button', 'tbtn', '导出 PNG');
    toolbar.appendChild(reset);
    toolbar.appendChild(png);

    // 背景主题切换
    toolbar.appendChild(el('span', 'hint', '背景主题：'));
    var themeSel = el('select');
    themeSel.className = 'tbtn';
    Object.keys(THEMES).forEach(function (key) {
      var o = el('option', '', THEMES[key].name);
      o.value = key;
      if (state.theme === key) o.selected = true;
      themeSel.appendChild(o);
    });
    themeSel.onchange = function () {
      state.theme = themeSel.value;
      renderChart();
    };
    toolbar.appendChild(themeSel);

    // 线宽控制
    toolbar.appendChild(el('span', 'hint', '线宽：'));
    var lwVal = el('span', 'hint', state.lineWidth.toFixed(1));
    var lw = el('input');
    lw.type = 'range';
    lw.min = '0.5';
    lw.max = '4';
    lw.step = '0.1';
    lw.value = state.lineWidth;
    lw.style.width = '80px';
    lw.oninput = function () {
      state.lineWidth = parseFloat(lw.value);
      lwVal.textContent = state.lineWidth.toFixed(1);
      renderChart();
    };
    toolbar.appendChild(lw);
    toolbar.appendChild(lwVal);

    area.appendChild(toolbar);
    var chartDiv = el('div', 'wave-chart');
    var scrollFrame=el('div','wave-scroll-frame'),viewport=el('div','wave-viewport');viewport.id='wave-vertical-viewport';viewport.appendChild(chartDiv);scrollFrame.appendChild(viewport);area.appendChild(scrollFrame);
    var rail=el('div','wave-vertical-rail'),thumb=el('div','wave-vertical-thumb');rail.appendChild(thumb);scrollFrame.appendChild(rail);rail.tabIndex=0;rail.setAttribute('role','scrollbar');rail.setAttribute('aria-label','上下滚动波形');rail.title='左键拖动滚动条上下查看波形';rail.setAttribute('aria-orientation','vertical');rail.setAttribute('aria-controls',viewport.id);rail.setAttribute('aria-valuemin','0');
    function syncVerticalScroll(){
      var max=Math.max(0,viewport.scrollHeight-viewport.clientHeight);rail.hidden=max<1;scrollFrame.classList.toggle('has-vertical-scroll',max>=1);
      var size=Math.max(36,rail.clientHeight*viewport.clientHeight/Math.max(1,viewport.scrollHeight)),travel=Math.max(0,rail.clientHeight-size);
      thumb.style.height=size+'px';thumb.style.top=(max?viewport.scrollTop/max*travel:0)+'px';rail.setAttribute('aria-valuemax',String(Math.round(max)));rail.setAttribute('aria-valuenow',String(Math.round(viewport.scrollTop)));
    }
    chartDiv._syncVerticalScroll=syncVerticalScroll;viewport.addEventListener('scroll',syncVerticalScroll);
    thumb.onpointerdown=function(ev){ev.preventDefault();ev.stopPropagation();thumb.setPointerCapture(ev.pointerId);var start=ev.clientY,initial=viewport.scrollTop;
      thumb.onpointermove=function(move){var max=viewport.scrollHeight-viewport.clientHeight,travel=rail.clientHeight-thumb.clientHeight;if(travel>0)viewport.scrollTop=initial+(move.clientY-start)*max/travel;};
      function end(){thumb.onpointermove=null;thumb.onpointerup=null;thumb.onpointercancel=null;}thumb.onpointerup=end;thumb.onpointercancel=end;
    };
    rail.onclick=function(ev){if(ev.target===thumb)return;var bounds=rail.getBoundingClientRect();viewport.scrollTop+=(ev.clientY-bounds.top<parseFloat(thumb.style.top)?-1:1)*viewport.clientHeight*.85;};
    rail.onkeydown=function(ev){var step=ev.key==='ArrowDown'?60:ev.key==='ArrowUp'?-60:ev.key==='PageDown'?viewport.clientHeight*.85:ev.key==='PageUp'?-viewport.clientHeight*.85:null;if(step!==null){ev.preventDefault();viewport.scrollTop+=step;}else if(ev.key==='Home'||ev.key==='End'){ev.preventDefault();viewport.scrollTop=ev.key==='Home'?0:viewport.scrollHeight;}};

    viewport.addEventListener('wheel',function(ev){ev.preventDefault();},{capture:true,passive:false});
    page.appendChild(area);
    container.appendChild(page);

    setPanelWidth(state.panelWidth,false);
    state.chart = echarts.init(chartDiv,null,{devicePixelRatio:window.devicePixelRatio});
    state.chart.on('datazoom',rememberZoomWindow);
    installContinuousReadout(chartDiv);
    var observer=new ResizeObserver(function(){if(state.chart&&!state.chart.isDisposed())renderChart();});observer.observe(viewport);
    chartDiv._viewportObserver=observer;

    reset.onclick = function () {
      state.zoomWindow={start:0,end:100};
      state.chart.dispatchAction({ type: 'dataZoom', start: 0, end: 100 });
    };
    png.onclick = function () {
      var url = state.chart.getDataURL({ pixelRatio: 2, backgroundColor: getTheme().bg });
      var a = document.createElement('a');
      a.href = url;
      a.download = 'STG波形.png';
      a.click();
    };

    renderChart();
  }

  function voltageAt(points,time) {
    if(!points||!points.length||time<points[0][0]||time>points[points.length-1][0])return null;
    var lo=0,hi=points.length;
    while(lo<hi){var mid=(lo+hi)>>1;if(points[mid][0]<=time)lo=mid+1;else hi=mid;}
    var a=points[Math.max(0,lo-1)],b=points[lo];
    if(!b||a[0]===time)return a[1];
    return a[1]+(b[1]-a[1])*(time-a[0])/(b[0]-a[0]);
  }
  function installContinuousReadout(chartDiv) {
    var chart=state.chart;
    var model=state.timeCursors||(state.timeCursors={items:[],next:1,shown:false,readout:false,pair:[]});
    var panel=el('div','cursor-panel'),controls=el('div','cursor-controls'),list=el('div','cursor-list'),result=el('span','cursor-delta');
    var toggle=el('button','tbtn'),add=el('button','tbtn','添加游标'),clear=el('button','tbtn','清空游标');
    var readLabel=el('label','cursor-readout-toggle'),read=el('input');read.type='checkbox';read.checked=model.readout;
    readLabel.appendChild(read);readLabel.appendChild(document.createTextNode('显示时间 / 电压读数'));
    controls.appendChild(toggle);controls.appendChild(add);controls.appendChild(clear);controls.appendChild(readLabel);controls.appendChild(result);
    chartDiv.closest('.wave-area').querySelector('.wave-toolbar').appendChild(controls);panel.appendChild(list);chartDiv.closest('.wave-area').insertBefore(panel,chartDiv.parentNode.parentNode);
    var overlay=el('div','time-cursor-overlay'),tip=el('div','wave-continuous-readout');
    chartDiv.style.position='relative';chartDiv.tabIndex=0;chartDiv.appendChild(overlay);chartDiv.appendChild(tip);
    tip.style.cssText='position:absolute;display:none;pointer-events:none;z-index:20;background:rgba(20,28,40,.94);color:white;padding:8px 10px;border-radius:6px;font-size:12px;white-space:pre-line;max-width:280px';
    function number(v){return Number(v.toFixed(6)).toString();}
    function geometry(){
      if(!state.result||!visibleGroups().length)return null;
      var opt=chart.getOption();if(!opt||!opt.grid||!opt.yAxis)return null;var grid=opt.grid[0],axis=opt.yAxis[0];if(!grid||!axis)return null;
      var top=typeof grid.top==='number'?grid.top:parseFloat(grid.top)*chartDiv.clientHeight/100;
      var left=typeof grid.left==='number'?grid.left:parseFloat(grid.left)*chartDiv.clientWidth/100;
      var right=chartDiv.clientWidth-(typeof grid.right==='number'?grid.right:parseFloat(grid.right)*chartDiv.clientWidth/100);
      var start=chart.convertFromPixel({xAxisIndex:0},left),end=chart.convertFromPixel({xAxisIndex:0},right);
      if(![top,left,right,start,end].every(Number.isFinite))return null;
      return {left:left,right:right,top:top,start:start,end:end};
    }
    function update(){
      toggle.textContent=model.shown?'隐藏测量游标':'显示测量游标';
      list.hidden=!model.shown;clear.disabled=!model.items.length;
      var a=model.items.find(function(c){return c.id===model.pair[0];}),b=model.items.find(function(c){return c.id===model.pair[1];});
      result.textContent=model.shown&&a&&b?'Δt（'+a.label+' ↔ '+b.label+'）= '+number(Math.abs(b.time-a.time))+' μs':'';
      model.items.forEach(function(c){var input=list.querySelector('[data-cursor-input="'+c.id+'"]');if(input&&document.activeElement!==input)input.value=number(c.time);});
      paint();
    }
    function rebuild(){
      list.textContent='';
      model.items.forEach(function(c){
        var row=el('div','cursor-row'),select=el('input'),label=el('label'),input=el('input'),remove=el('button','tbtn','删除');
        select.type='checkbox';select.checked=model.pair.includes(c.id);select.setAttribute('aria-label','用 '+c.label+' 测量时间差');
        select.onchange=function(){model.pair=model.pair.filter(function(id){return id!==c.id;});if(select.checked){if(model.pair.length===2)model.pair.shift();model.pair.push(c.id);}rebuild();};
        label.appendChild(select);label.appendChild(document.createTextNode(c.label));input.type='number';input.step='any';input.value=number(c.time);input.dataset.cursorInput=c.id;input.setAttribute('aria-label',c.label+' 时间（微秒）');
        input.onchange=function(){var value=Number(input.value);if(input.value!==''&&Number.isFinite(value)){c.time=Math.max(0,Math.min(state.result.timeline.FrameEnd_end,value));}input.value=number(c.time);update();};
        remove.onclick=function(){model.items=model.items.filter(function(item){return item!==c;});model.pair=model.pair.filter(function(id){return id!==c.id;});rebuild();};
        row.appendChild(label);row.appendChild(input);row.appendChild(el('span','','μs'));row.appendChild(remove);list.appendChild(row);
      });
      if(model.items.length)list.appendChild(el('span','hint','勾选两根测量 Δt · 拖动顶部手柄 · 输入时间精调'));
      update();chart.resize();
    }
    function paint(){
      overlay.textContent='';var g=geometry();if(!g)return;
      if(state.result.timeline.frameCount===2){var frameX=chart.convertToPixel({xAxisIndex:0},state.result.timeline.frameDuration);if(frameX>=g.left&&frameX<=g.right){var label=el('div','wave-frame-label','负帧开始');label.style.left=Math.max(g.left,Math.min(frameX, g.right-78))+'px';overlay.appendChild(label);}}
      if(!model.shown)return;
      model.items.forEach(function(c){
        var x=chart.convertToPixel({xAxisIndex:0},c.time);if(!Number.isFinite(x)||x<g.left||x>g.right)return;
        var line=el('div','time-cursor-line'),handle=el('button','time-cursor-handle',c.label);
        line.style.left=x+'px';line.style.top=Math.max(0,g.top)+'px';line.style.bottom='34px';
        handle.type='button';handle.setAttribute('aria-label','拖动 '+c.label+' 时间游标');handle.style.left=x+'px';handle.style.top=Math.max(0,g.top-28)+'px';
        function begin(ev){
          ev.preventDefault();ev.stopPropagation();handle.setPointerCapture(ev.pointerId);
          function move(e){var rect=chartDiv.getBoundingClientRect(),geo=geometry();if(!geo)return;var px=Math.max(geo.left,Math.min(geo.right,e.clientX-rect.left));c.time=chart.convertFromPixel({xAxisIndex:0},px);line.style.left=px+'px';handle.style.left=px+'px';var input=list.querySelector('[data-cursor-input="'+c.id+'"]');if(input)input.value=number(c.time);var a=model.items.find(function(i){return i.id===model.pair[0];}),b=model.items.find(function(i){return i.id===model.pair[1];});if(a&&b)result.textContent='Δt（'+a.label+' ↔ '+b.label+'）= '+number(Math.abs(b.time-a.time))+' μs';}
          function end(){handle.removeEventListener('pointermove',move);handle.removeEventListener('pointerup',end);handle.removeEventListener('pointercancel',end);update();}
          handle.addEventListener('pointermove',move);handle.addEventListener('pointerup',end);handle.addEventListener('pointercancel',end);
        }
        handle.onpointerdown=begin;handle.onkeydown=function(ev){if(ev.key==='ArrowLeft'||ev.key==='ArrowRight'){ev.preventDefault();c.time=Math.max(g.start,Math.min(g.end,c.time+(g.end-g.start)*(ev.shiftKey?.01:.001)*(ev.key==='ArrowLeft'?-1:1)));update();}};
        overlay.appendChild(line);overlay.appendChild(handle);
      });
    }
    toggle.onclick=function(){model.shown=!model.shown;update();chart.resize();};
    add.onclick=function(){var g=geometry();if(!g)return;model.shown=true;var id=model.next++,c={id:id,label:'T'+id,time:g.start+(g.end-g.start)*(.25+(model.items.length%3)*.25)};model.items.push(c);if(model.pair.length<2)model.pair.push(id);rebuild();};
    clear.onclick=function(){model.items=[];model.pair=[];rebuild();};
    read.onchange=function(){model.readout=read.checked;tip.style.display='none';};
    chart.on('finished',paint);
    chart.getZr().on('mousemove',function(ev){
      if(!model.readout){tip.style.display='none';return;}
      var groups=visibleGroups(),pixel=[ev.offsetX,ev.offsetY],lines=null;
      for(var i=0;i<groups.length;i++)if(chart.containPixel({gridIndex:i},pixel)){
        var coord=chart.convertFromPixel({xAxisIndex:i,yAxisIndex:i},pixel);if(!coord||!Number.isFinite(coord[0]))break;
        lines=['时间: '+number(coord[0])+' μs'];groups[i].forEach(function(name){var v=voltageAt(state.result.signals[name],coord[0]);if(v!==null)lines.push(name+': '+number(v)+' V');});break;
      }
      if(!lines){tip.style.display='none';return;}tip.textContent=lines.join('\n');tip.style.display='block';tip.style.left=Math.max(0,Math.min(ev.offsetX+12,chartDiv.clientWidth-tip.offsetWidth))+'px';tip.style.top=Math.max(0,Math.min(ev.offsetY+12,chartDiv.clientHeight-tip.offsetHeight))+'px';
    });
    chart.getZr().on('globalout',function(){tip.style.display='none';});
    chartDiv.addEventListener('keydown',function(ev){if(ev.key==='Escape'){model.shown=false;model.readout=false;read.checked=false;tip.style.display='none';update();chart.resize();}});
    rebuild();
  }

  function rememberZoomWindow() {
    if(!state.chart)return;
    var options=state.chart.getOption(),zoom=options&&options.dataZoom&&options.dataZoom[0];
    if(zoom&&Number.isFinite(Number(zoom.start))&&Number.isFinite(Number(zoom.end)))state.zoomWindow={start:Number(zoom.start),end:Number(zoom.end)};
  }
  function renderChart() {
    if (!state.chart || !state.result) return;
    rememberZoomWindow();
    var groups = visibleGroups();
    var chartDiv=state.chart.getDom(),viewport=chartDiv.parentNode;
    var availableHeight=viewport.clientHeight,usableHeight=Math.max(10,availableHeight-60);
    chartDiv._waveGroupGap=Math.min(24,usableHeight/10*.3);
    var minimumGroupHeight=(usableHeight-9*chartDiv._waveGroupGap)/10;
    var height=groups.length<=10?availableHeight:Math.ceil(groups.length*minimumGroupHeight+Math.max(0,groups.length-1)*chartDiv._waveGroupGap+60);
    chartDiv.style.height=height+'px';
    state.chart.resize({height:height,width:viewport.clientWidth});
    state.chart.setOption(buildChartOption(groups), true);
    if(chartDiv._syncVerticalScroll)chartDiv._syncVerticalScroll();
  }

  // 信号固定颜色（不随分组变化）
  function signalColor(n) {
    var all = signalNames();
    var idx = all.indexOf(n);
    return PALETTE[(idx < 0 ? 0 : idx) % PALETTE.length];
  }

  function buildChartOption(groups) {
    var N = groups.length;
    var theme = getTheme();
    if (N === 0) {
      return {
        backgroundColor: theme.bg,
        title: { text: '点击左侧信号以显示波形', left: 'center', top: 'middle', textStyle: { fontSize: 14, color: theme.text } }
      };
    }
    var minT = 0, maxT = state.result.timeline.FrameEnd_end;
    var chartHeight=Math.max(1,state.chart.getHeight());
    var gapPixels=state.chart.getDom()._waveGroupGap||0;
    var gap = gapPixels/chartHeight*100;
    var topMargin = 30/chartHeight*100, bottomMargin = 30/chartHeight*100;
    var usable = 100 - topMargin - bottomMargin;
    var each = (usable - gap * (N - 1)) / N;

    var grids = [], xAxes = [], yAxes = [], series = [], titles = [];
    groups.forEach(function (grp, gi) {
      var top = topMargin + gi * (each + gap);
      var groupName = grp.join(' + ');
      grids.push({ left: 48, right: 16, top: top + '%', height: each + '%', borderColor: theme.border });
      titles.push({text:groupName,right:18,top:top*chartHeight/100-Math.min(23,gapPixels+1),padding:0,textStyle:{fontSize:12,fontWeight:500,color:theme.text}});
      // 每个子图（组）一个 xAxis + 一个 yAxis
      xAxes.push({
        type: 'value', gridIndex: gi, min: minT, max: maxT,
        axisLabel: { show: gi === N - 1, fontSize: 9, color: theme.text },
        axisTick: { show: false },
        axisLine: { show: gi === N - 1, lineStyle: { color: theme.axis } },
        splitLine: { show: false }
      });
      yAxes.push({
        type: 'value', gridIndex: gi, scale: true,
        name: '', nameLocation: 'end', nameGap: 6,
        nameTextStyle: { color: theme.text, fontSize: 9, align: 'left' },
        axisLabel: { fontSize: 11, margin: 4, color: theme.text },
        axisLine: { lineStyle: { color: theme.axis } },
        splitNumber: 3,
        splitLine: { lineStyle: { type: 'dashed', color: theme.splitLine } }
      });
      grp.forEach(function (n) {
        var pts = state.result.signals[n];
        if (!pts) return;
        var color = signalColor(n);
        series.push({
          name: n, type: 'line', data: pts,
          xAxisIndex: gi, yAxisIndex: gi,
          showSymbol: false, sampling: 'lttb',
          lineStyle: { width: state.lineWidth, color: color },
          itemStyle: { color: color }
        });
      });
    });

    if(series.length&&state.result.timeline.frameCount===2)series[0].markLine={silent:true,symbol:['none','none'],label:{show:false},lineStyle:{type:'dashed',color:theme.axis},data:[{xAxis:state.result.timeline.frameDuration}]};

    var xIdx = [];
    for (var j = 0; j < N; j++) xIdx.push(j);

    return {
      animation: false,
      backgroundColor: theme.bg,
      title: titles,
      grid: grids,
      xAxis: xAxes,
      yAxis: yAxes,
      series: series,
      tooltip: {
        show: false,
        trigger: 'axis',
        formatter: function (params) {
          if (!params || !params.length) return '';
          var t = params[0].value[0];
          var s = '时间: ' + fmt(t) + ' uS<br>';
          params.forEach(function (p) { s += p.seriesName + ': ' + fmt(p.value[1]) + ' V<br>'; });
          return s;
        }
      },
      dataZoom: [
        {
          type: 'inside', xAxisIndex: xIdx, filterMode: 'none', start:state.zoomWindow.start,end:state.zoomWindow.end,
          zoomOnMouseWheel: true, moveOnMouseMove: true, moveOnMouseWheel: false
        },
        {
          type: 'slider', xAxisIndex: xIdx, bottom: 0, height: 18, start:state.zoomWindow.start,end:state.zoomWindow.end,
          borderColor: theme.border, backgroundColor: theme.splitLine,
          fillerColor: 'rgba(0,51,102,0.2)', textStyle: { color: theme.text, fontSize: 9 }
        }
      ]
    };
  }

  // ---- 时序表格页 ----
  function renderTable(container) {
    var wrap=el('div','table-wrap');container.appendChild(wrap);
    if(!state.result){wrap.appendChild(el('div','empty-hint','请先生成波形'));return;}
    var names=signalNames();
    if(state.tableSignals===null)state.tableSignals=names.filter(function(n){return signalCategory(n)==='CKV';});
    state.tableSignals=state.tableSignals.filter(function(n){return names.includes(n);});
    var toolbar=el('div','table-toolbar'),filter=el('details','table-signal-filter'),summary=el('summary','');summary.setAttribute('aria-label','表格信号筛选');filter.appendChild(summary);
    var menu=el('div','table-signal-menu'),categoryControls={},signalControls={};filter.appendChild(menu);toolbar.appendChild(filter);
    var exportButton=el('button','tbtn','导出 CSV');toolbar.appendChild(exportButton);var count=el('span','table-point-count');toolbar.appendChild(count);wrap.appendChild(toolbar);
    var scroll=el('div','timing-master-scroll'),table=el('table','data-table timing-master-table');table.id='sig-table';scroll.appendChild(table);wrap.appendChild(scroll);
    var empty=el('p','empty-hint','请选择要显示的信号。');wrap.appendChild(empty);
    wrap.appendChild(el('p','table-alignment-note','各信号保留完整点位；同一行是各信号的点号，各自时间以该信号的时间列为准。'));
    function chosen(){return names.filter(function(n){return state.tableSignals.includes(n);});}
    function checkbox(parent,label,key,action){var row=el('label','table-signal-option'),input=el('input');input.type='checkbox';input.setAttribute('data-table-filter',key);input.setAttribute('aria-label',label);row.appendChild(input);row.appendChild(el('span','',label));parent.appendChild(row);input.onchange=function(){action(input.checked);fill();};return input;}
    var shortcuts=el('div','table-category-controls');menu.appendChild(shortcuts);
    ['CKV','CKH','Video','GIP'].forEach(function(category){categoryControls[category]=checkbox(shortcuts,category,'category-'+category,function(checked){var members=names.filter(function(n){return signalCategory(n)===category;});state.tableSignals=checked?Array.from(new Set(state.tableSignals.concat(members))):state.tableSignals.filter(function(n){return !members.includes(n);});});});
    categoryControls.all=checkbox(shortcuts,'全部显示','all',function(checked){state.tableSignals=checked?names.slice():[];});
    categoryControls.none=checkbox(shortcuts,'全部隐藏','none',function(checked){state.tableSignals=checked?[]:names.slice();});
    var individual=el('div','table-individual-signals');menu.appendChild(individual);
    ['CKV','CKH','Video','GIP'].forEach(function(category){individual.appendChild(el('div','table-category-label',category));names.filter(function(n){return signalCategory(n)===category;}).forEach(function(name){signalControls[name]=checkbox(individual,name,'signal-'+name,function(checked){state.tableSignals=checked?Array.from(new Set(state.tableSignals.concat([name]))):state.tableSignals.filter(function(n){return n!==name;});});});});
    function rows(selected){var length=selected.reduce(function(max,name){return Math.max(max,state.result.signals[name].length);},0),result=[];for(var i=0;i<length;i++){var row=[String(i+1)];selected.forEach(function(name){var point=state.result.signals[name][i];row.push(point?String(point[0]):'',point?String(point[1]):'');});result.push(row);}return result;}
    function fill(){var selected=chosen();summary.textContent='显示信号 · '+selected.length+' / '+names.length;exportButton.disabled=!selected.length;empty.hidden=!!selected.length;scroll.hidden=!selected.length;
      Object.keys(signalControls).forEach(function(name){signalControls[name].checked=selected.includes(name);});
      Object.keys(categoryControls).forEach(function(category){var input=categoryControls[category];input.indeterminate=false;if(category==='all')input.checked=selected.length===names.length;else if(category==='none')input.checked=selected.length===0;else{var members=names.filter(function(n){return signalCategory(n)===category;}),number=members.filter(function(n){return selected.includes(n);}).length;input.checked=members.length>0&&number===members.length;input.indeterminate=number>0&&number<members.length;}});
      table.innerHTML='';if(!selected.length){count.textContent='未选择信号';return;}
      var head=el('thead'),top=el('tr'),sub=el('tr'),index=el('th','','点号');index.rowSpan=2;index.scope='col';top.appendChild(index);
      selected.forEach(function(name){var title=el('th','',name);title.colSpan=2;title.scope='colgroup';title.setAttribute('data-table-signal',name);top.appendChild(title);['时间（μs）','电压（V）'].forEach(function(label){var th=el('th','',label);th.scope='col';sub.appendChild(th);});});head.appendChild(top);head.appendChild(sub);table.appendChild(head);
      var data=rows(selected),body=el('tbody');data.forEach(function(values){var row=el('tr');values.forEach(function(value){row.appendChild(el('td','',value));});body.appendChild(row);});table.appendChild(body);count.textContent=selected.length+' 路信号 · '+data.length+' 行';
    }
    exportButton.onclick=function(){var selected=chosen();if(!selected.length)return;var header=['点号'];selected.forEach(function(name){header.push(name+'_时间(μs)',name+'_电压(V)');});var lines=[header].concat(rows(selected)).map(function(row){return row.join(',');});var blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),link=el('a');link.href=url;link.download=selected.length===names.length?'STG_all_signals.csv':'STG_selected_signals.csv';link.click();setTimeout(function(){URL.revokeObjectURL(url);},1000);};
    fill();
  }

  // ---- 初始化 ----
  function init() {
    state.vals = Object.assign(CFG.defaults(), CFG.normalizeValues(loadFromStorage()));
    renderTabs();
    renderParams($('content'));
    generate();
    // 绑定顶栏按钮
    $('btn-generate').onclick = generate;
    $('btn-save').onclick = savePlan;
    $('btn-load').onclick = loadPlan;
  }

  (function watchDisplayDensity(){
    var query=window.matchMedia('(resolution: '+window.devicePixelRatio+'dppx)');
    query.addEventListener('change',function changed(){
      query.removeEventListener('change',changed);
      if(activeTab==='wave' && state.chart){
        var viewport=document.querySelector('.wave-viewport'),top=viewport?viewport.scrollTop:0;
        rememberZoomWindow();showTab('wave');
        var next=document.querySelector('.wave-viewport');if(next)next.scrollTop=top;
      }
      watchDisplayDensity();
    });
  })();
  global.STGApp = { init: init };
  document.addEventListener('DOMContentLoaded', init);
})(window);
