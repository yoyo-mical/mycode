import {issuerPublicKey} from './issuer-public-key.js?v=20261112-import';
import {products,clone,accountKey,validAccount,productPath,saveOrganization,makeList,validateBook,pathKey} from './organizations.js?v=20261112-import';
const MAX_SIZE=8*1024*1024;
function bytes(value){if(typeof value!=='string'||!value.trim())throw Error('授权文件缺少签名封装');try{const raw=atob(value.replace(/[\t\n\r ]/g,''));return Uint8Array.from(raw,c=>c.charCodeAt(0));}catch{throw Error('授权文件的 Base64 编码无效');}}
export async function verifySignedLicense(text){
 if(typeof text!=='string'||text.length>MAX_SIZE)throw Error('授权名单文件过大或内容无效');
 let envelope;try{envelope=JSON.parse(text.replace(/^\ufeff/,''));}catch{throw Error('请选择有效的 JSON 授权名单');}
 if(envelope?.kind)throw Error('这是管理备份，请使用“恢复管理备份”');
 const payload=bytes(envelope?.payload),signature=bytes(envelope?.signature);if(!payload.length)throw Error('授权内容为空');
 if(!globalThis.crypto?.subtle)throw Error('当前浏览器不支持安全验签，请使用最新浏览器打开 HTTPS 网页');
 const key=await crypto.subtle.importKey('jwk',issuerPublicKey,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
 if(!await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,signature,payload))throw Error('原公钥验签失败：文件可能被修改，或不属于原授权密钥');
 // Verify the exact decoded payload bytes BEFORE decoding or parsing JSON.
 let list;try{list=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(payload));}catch{throw Error('签名内的授权内容不是有效 UTF-8 JSON');}
 if(!list||!products.includes(list.product)||!Array.isArray(list.users)||list.users.length>10000)throw Error('授权产品或账号列表不受支持');
 if(list.product==='ElecTest2026'&&(typeof list.issuedUtc!=='string'||!list.issuedUtc.trim()))throw Error('ElecTest2026 名单缺少签发时间');
 if(list.issuedUtc!=null&&(typeof list.issuedUtc!=='string'||(list.issuedUtc.trim()&&!Number.isFinite(Date.parse(list.issuedUtc)))))throw Error('名单签发时间无效');
 const accounts=new Set();const users=list.users.map(u=>{
  if(!u||!validAccount(u.account)||accounts.has(accountKey(u.account))||!['Beta','Standard','Basic','Pro'].includes(u.edition)||(u.enabled!==undefined&&typeof u.enabled!=='boolean')||(u.expiresUtc!=null&&typeof u.expiresUtc!=='string'))throw Error('名单存在无效或重复账号记录');
  accounts.add(accountKey(u.account));const expiry=u.expiresUtc?.trim()?u.expiresUtc:'';if(expiry&&!Number.isFinite(Date.parse(expiry)))throw Error('账号有效期无效');
  // Old DataContract missing bool defaults to false. Expired/disabled grants remain importable.
  return {account:u.account,edition:u.edition,enabled:u.enabled===true,expiresUtc:expiry};
 });
 const digest=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text.replace(/^\ufeff/,''))));const fingerprint=btoa(String.fromCharCode(...digest));return {product:list.product,issuedUtc:list.issuedUtc||'',users,fingerprint};
}
export function planLicenseImport(book,license,{organizationId,newOrganization,fileName,conflicts='keep'}){
 if(!['keep','replace'].includes(conflicts))throw Error('请选择同账号处理方式');
 let data=clone(book),id=organizationId;
 if(newOrganization){const created=saveOrganization(data,newOrganization);data=created.book;id=created.organizationId;}
 const org=data.organizations.find(o=>o.id===id);if(!org||org.archived||org.legacyPaths)throw Error('请选择已配置共享路径的组织，或新增对应组织');
 const destination=productPath(org.directory,license.product,fileName);
 const sameProduct=data.lists.filter(l=>l.organizationId===id&&l.product===license.product);if(sameProduct.length>1)throw Error('该组织存在重复产品文件，请先整理旧名单');let list=sameProduct[0];const oldPath=newOrganization?'':list?.path||'';
 if(data.lists.some(l=>l.id!==list?.id&&pathKey(l.path)===pathKey(destination)))throw Error('该文件名已用于其他产品，请保留各产品独立文件');
 const rows=[],counts={added:0,updated:0,kept:0,unchanged:0};
 for(const user of license.users){
  const foreign=data.organizations.find(o=>o.id!==id&&o.members.some(a=>accountKey(a)===accountKey(user.account)));if(foreign)throw Error(`账号 ${user.account} 已属于“${foreign.name}”，请改选对应组织；不会自动迁移账号`);
 }
 org.productFiles={...org.productFiles,[license.product]:fileName};
 if(!list){list=makeList(org,license.product);data.lists.push(list);}
 list.path=destination;
 for(const user of license.users){
  const index=list.users.findIndex(u=>accountKey(u.account)===accountKey(user.account)),before=index>=0?clone(list.users[index]):null;let decision;
  if(!org.members.some(a=>accountKey(a)===accountKey(user.account)))org.members.push(user.account);
  if(!before){list.users.push({id:crypto.randomUUID(),...user});counts.added++;decision='新增';}
  else if(conflicts==='keep'){counts.kept++;decision='保留现有授权';}
  else{const after={...before,...user};if(JSON.stringify(after)===JSON.stringify(before)){counts.unchanged++;decision='相同，不变';}else{list.users[index]=after;counts.updated++;decision='使用导入记录';}}
  rows.push({account:user.account,before,after:list.users.find(u=>accountKey(u.account)===accountKey(user.account)),decision});
 }
 if(counts.added||counts.updated||oldPath!==destination){list.dirty=true;list.previewed=false;}
 list.verified=false;list.fingerprint=license.fingerprint;list.importSource={verified:true,product:license.product,issuedUtc:license.issuedUtc,importedUtc:new Date().toISOString(),fingerprint:license.fingerprint};
 validateBook(data);return {book:data,organizationId:id,organizationName:org.name,product:license.product,destination,oldPath,rows,counts};
}
