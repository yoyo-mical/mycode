export const products=['SimTimingTools','ElecTest2026'];
export const clone=v=>JSON.parse(JSON.stringify(v));
export const accountKey=a=>a.toUpperCase();
export const pathKey=p=>p.trim().replace(/\\/g,'/').replace(/\/+/g,'/').replace(/\/+$/,'').toLowerCase();
export const validAccount=a=>typeof a==='string'&&/^[^\\\s]+\\[^\\\s]+$/.test(a);
export function validDirectory(p){return typeof p==='string'&&(/^[a-z]:[\\/]/i.test(p)||/^(\\\\|\/\/)[^\\/]+[\\/][^\\/]+/.test(p))&&!p.split(/[\\/]/).some(s=>s==='..'||s==='.')&&!/[\r\n\0]/.test(p);}
export function validLicenseFileName(name){return typeof name==='string'&&name===name.trim()&&name.length>5&&name.length<=180&&/\.json$/i.test(name)&&!/[\\/:*?"<>|\x00-\x1f]/.test(name)&&!/[. ]$/.test(name);}
export function productPath(directory,product,fileName=product+'.licenses.json'){if(!validDirectory(directory)||!products.includes(product))throw Error('请设置有效的 Windows 文件夹或共享目录');if(!validLicenseFileName(fileName))throw Error('请填写独立的 JSON 文件名，不要包含目录或路径字符');return directory.replace(/[\\/]+$/,'')+(directory.includes('\\')?'\\':'/')+fileName;}
export function makeList(org,product){return {id:crypto.randomUUID(),organizationId:org.id,product,name:org.name+' / '+product,path:productPath(org.directory,product,org.productFiles?.[product]),users:[],dirty:true,previewed:false,verified:false};}
export function migrate(book){
 const data=clone(book);
 if(!Array.isArray(data.organizations)){
  // Keep every old record and path exactly as entered; ask the owner to choose a shared directory.
  const org={id:'legacy-organization',name:'待整理组织',directory:'',legacyPaths:true,archived:false,members:[...new Map(data.lists.flatMap(l=>l.users).map(u=>[accountKey(u.account),u.account])).values()]};
  data.organizations=[org];for(const l of data.lists)l.organizationId=org.id;
 }
 const history=[...(data.accountHistory||[]),...data.organizations.flatMap(o=>o.members)];
 data.accountHistory=[...new Map(history.map(a=>[accountKey(a),a])).values()];
 data.schemaVersion=2;return data;
}
export function validateBook(book){
 if(!book||!Array.isArray(book.organizations)||!Array.isArray(book.lists)||book.organizations.length>100||book.lists.length>300)throw Error('预览草稿格式无效');
 if(book.accountHistory!=null&&(!Array.isArray(book.accountHistory)||book.accountHistory.length>10000||book.accountHistory.some(a=>!validAccount(a))||new Set(book.accountHistory.map(accountKey)).size!==book.accountHistory.length))throw Error('历史账号数据无效');
 const ids=new Set(),names=new Set(),directories=new Set(),members=new Map(),paths=new Set(),pairs=new Set();
 for(const o of book.organizations){
  if(!o||typeof o.id!=='string'||ids.has(o.id)||typeof o.name!=='string'||!o.name.trim()||names.has(o.name.trim().toLowerCase())||!Array.isArray(o.members)||typeof o.directory!=='string')throw Error('组织名称或成员数据无效');
  if(o.productFiles!=null&&(typeof o.productFiles!=='object'||Array.isArray(o.productFiles)||Object.entries(o.productFiles).some(([p,n])=>!products.includes(p)||!validLicenseFileName(n))))throw Error('组织产品文件名无效');
  ids.add(o.id);names.add(o.name.trim().toLowerCase());
  if(!o.legacyPaths&&!validDirectory(o.directory))throw Error('请设置有效组织目录');
  if(o.directory){const dir=pathKey(o.directory);if(directories.has(dir))throw Error('不同组织不能共用同一授权目录');directories.add(dir);}
  for(const a of o.members){if(!validAccount(a)||members.has(accountKey(a)))throw Error('成员账号无效、重复或已属于其他组织');members.set(accountKey(a),o.id);}
 }
 for(const l of book.lists){
  const o=book.organizations.find(o=>o.id===l.organizationId);if(!o||!products.includes(l.product)||typeof l.id!=='string'||ids.has(l.id)||typeof l.name!=='string'||typeof l.path!=='string'||!Array.isArray(l.users)||l.users.length>10000)throw Error('产品文件或所属组织无效');
  ids.add(l.id);const pair=o.id+':'+l.product;if(pairs.has(pair)&&!o.legacyPaths)throw Error('同一组织每个产品只能有一个授权文件');pairs.add(pair);
  if(!o.legacyPaths&&pathKey(l.path)!==pathKey(productPath(o.directory,l.product,o.productFiles?.[l.product])))throw Error('产品文件必须位于所属组织的统一目录');
  if(paths.has(pathKey(l.path)))throw Error('授权文件路径重复');paths.add(pathKey(l.path));const accounts=new Set();
  for(const u of l.users){if(!u||typeof u.id!=='string'||ids.has(u.id)||!validAccount(u.account)||members.get(accountKey(u.account))!==o.id||accounts.has(accountKey(u.account))||!['Beta','Standard','Basic','Pro'].includes(u.edition)||typeof u.enabled!=='boolean'||(u.expiresUtc&&!Number.isFinite(Date.parse(u.expiresUtc))))throw Error('账号授权内容或组织归属无效');ids.add(u.id);accounts.add(accountKey(u.account));}
 }
 return book;
}
export function saveOrganization(book,{id,name,directory}){
 const data=clone(book);name=name.trim();directory=directory.trim();if(!name)throw Error('请填写组织名称');if(!validDirectory(directory))throw Error('请填写完整 Windows 文件夹或 UNC 共享目录');
 let org=data.organizations.find(o=>o.id===id);
 if(org){org.name=name;org.directory=directory;org.legacyPaths=false;for(const l of data.lists.filter(l=>l.organizationId===id)){const path=productPath(directory,l.product,org.productFiles?.[l.product]);if(pathKey(l.path)!==pathKey(path)){l.path=path;l.dirty=true;l.previewed=false;l.verified=false;delete l.fingerprint;delete l.importSource;}l.name=name+' / '+l.product;}}
 else{org={id:crypto.randomUUID(),name,directory,members:[],archived:false};data.organizations.push(org);}
 for(const p of products)if(!data.lists.some(l=>l.organizationId===org.id&&l.product===p))data.lists.push(makeList(org,p));
 validateBook(data);return {book:data,organizationId:org.id};
}
export function addMember(book,organizationId,account){
 const data=clone(book),org=data.organizations.find(o=>o.id===organizationId);account=account.trim();if(!org||org.archived)throw Error('请选择可用组织');if(!validAccount(account))throw Error('请填写完整 Windows 账号：域或设备名\\用户名');
 const previous=data.organizations.find(o=>o.members.some(a=>accountKey(a)===accountKey(account)));if(previous)throw Error(`该账号已属于“${previous.name}”，不能重复添加；本页不会自动迁移授权`);
 org.members.push(account);validateBook(data);return data;
}

// A single account editor: checked products are its product grants; no authorization modes.
export function saveAccount(book,{organizationId,account,previousAccount,grants}){
 const data=clone(book),org=data.organizations.find(o=>o.id===organizationId);account=account.trim();
 if(!org||org.archived||org.legacyPaths)throw Error('请先配置该分类的共享路径');
 if(!validAccount(account))throw Error('请填写完整 Windows 账号：域或设备名\\用户名');
 const previous=previousAccount?org.members.find(a=>accountKey(a)===accountKey(previousAccount)):null;
 if(previousAccount&&!previous)throw Error('请重新打开要编辑的账号');
 const owner=data.organizations.find(o=>o.members.some(a=>accountKey(a)===accountKey(account)));
 if(owner&&(!previous||owner.id!==org.id||accountKey(account)!==accountKey(previous)))throw Error('该账号已经存在，请在对应名单中编辑；不能合并或覆盖其他账号');
 const canonical=account;
 data.accountHistory=migrate(data).accountHistory;
 if(!data.accountHistory.some(a=>accountKey(a)===accountKey(account)))data.accountHistory.push(account);
 if(previous)org.members[org.members.indexOf(previous)]=canonical;else org.members.push(canonical);
 for(const product of products){
  const choice=grants[product];if(!choice||typeof choice.selected!=='boolean'||typeof choice.enabled!=='boolean'||typeof choice.expiresUtc!=='string'||(choice.expiresUtc&&!Number.isFinite(Date.parse(choice.expiresUtc))))throw Error('产品设置无效');
  const lists=data.lists.filter(l=>l.organizationId===org.id&&l.product===product);if(lists.length>1)throw Error('此分类存在重复产品文件，请先整理旧名单');let list=lists[0];
  if(!list&&choice.selected){list=makeList(org,product);data.lists.push(list);}if(!list)continue;
  const index=list.users.findIndex(u=>accountKey(u.account)===accountKey(previous||canonical)),before=index>=0?list.users[index]:null;
  if(!choice.selected){if(index>=0){list.users.splice(index,1);list.dirty=true;list.previewed=false;}continue;}
  const next=before?clone(before):{id:crypto.randomUUID(),account:canonical,edition:'Standard',enabled:true,expiresUtc:''};
  next.account=canonical;next.enabled=choice.enabled;next.expiresUtc=choice.expiresUtc;
  if(JSON.stringify(next)!==JSON.stringify(before)){if(index>=0)list.users[index]=next;else list.users.push(next);list.dirty=true;list.previewed=false;}
 }
 validateBook(data);return data;
}
export function removeAccount(book,organizationId,account){
 const data=clone(book),org=data.organizations.find(o=>o.id===organizationId);if(!org)throw Error('分类不存在');
 data.accountHistory=migrate(data).accountHistory;
 org.members=org.members.filter(a=>accountKey(a)!==accountKey(account));
 for(const l of data.lists.filter(l=>l.organizationId===organizationId)){const remaining=l.users.filter(u=>accountKey(u.account)!==accountKey(account));if(remaining.length!==l.users.length){l.users=remaining;l.dirty=true;l.previewed=false;}}
 validateBook(data);return data;
}
