// Presentation guard only; the C# session remains the authorization boundary.
(function () {
  'use strict';
  async function unlock() {
    var allowed = false;
    try {
      allowed = !!(window.chrome && window.chrome.webview && window.STGDesktop &&
        await window.STGDesktop.requestPermission());
    } catch (_) {}
    if (allowed) {
      document.getElementById('desktop-auth-lock').remove();
      return;
    }
    document.body.replaceChildren();
    var message = document.createElement('p');
    message.textContent = '请通过使用包顶层的启动工具.exe 打开，并完成账号授权。';
    message.style.cssText = 'font:18px system-ui;padding:32px';
    document.body.appendChild(message);
    document.getElementById('desktop-auth-lock').remove();
    window.stop();
  }
  document.addEventListener('DOMContentLoaded', unlock, {once:true});
})();
