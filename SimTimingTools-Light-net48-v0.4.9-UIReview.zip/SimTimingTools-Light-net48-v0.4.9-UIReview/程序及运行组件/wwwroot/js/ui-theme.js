(function(){
 'use strict';
 var key='stg_ui_theme',choices=[['teal','浅色青绿'],['classic','经典深蓝'],['dark','暗黑']],root=document.documentElement;
 function valid(value){return choices.some(function(choice){return choice[0]===value;});}
 function apply(value,persist){value=valid(value)?value:'teal';root.dataset.uiTheme=value;root.style.colorScheme=value==='dark'?'dark':'light';var select=document.getElementById('ui-theme');if(select)select.value=value;if(persist)try{localStorage.setItem(key,value);}catch(_){} }
 var initial='teal';try{initial=localStorage.getItem(key)||initial;}catch(_){}apply(initial,false);
 function mount(){var actions=document.querySelector('.header-actions');if(!actions||document.getElementById('ui-theme'))return;var label=document.createElement('label');label.className='ui-theme-picker';if(window.STGIcons)label.appendChild(window.STGIcons.create('sun'));var title=document.createElement('span');title.className='ui-theme-caption';title.textContent='主题';label.appendChild(title);var select=document.createElement('select');select.id='ui-theme';select.setAttribute('aria-label','界面主题');choices.forEach(function(choice){var option=document.createElement('option');option.value=choice[0];option.textContent=choice[1];select.appendChild(option);});select.value=root.dataset.uiTheme;select.addEventListener('change',function(){apply(select.value,true);});label.appendChild(select);actions.appendChild(label);}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
 window.addEventListener('storage',function(event){if(event.key===key)apply(event.newValue,false);});
})();
