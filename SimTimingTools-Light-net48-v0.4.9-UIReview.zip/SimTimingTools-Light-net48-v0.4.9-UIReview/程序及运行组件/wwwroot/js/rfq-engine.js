(function(g){
 'use strict';
 var data=g.STGRFQWorkbook,parsed=new Map();
 function parse(source){
  if(parsed.has(source))return parsed.get(source);
  var tokens=[],re=/\s*(?:(\d+(?:\.\d*)?(?:[Ee][+-]?\d+)?|\.\d+)|"((?:[^"]|"")*)"|(\$?[A-Za-z]+\$?\d+)|([A-Za-z_]+)|(<>|<=|>=|[+\-*/^=<>(),:]))/gy,pos=1,m;
  while(pos<source.length){re.lastIndex=pos;m=re.exec(source);if(!m)throw Error('不支持的公式：'+source);pos=re.lastIndex;tokens.push(m[1]?{v:Number(m[1]),t:'n'}:m[2]!==undefined?{v:m[2].replace(/""/g,'"'),t:'s'}:m[3]?{v:m[3].replace(/\$/g,'').toUpperCase(),t:'c'}:{v:(m[4]||m[5]).toUpperCase(),t:'o'});}
  var at=0,prec={'=':1,'<>':1,'<':1,'>':1,'<=':1,'>=':1,'+':2,'-':2,'*':3,'/':3,'^':4};
  function expr(min){var t=tokens[at++],node;if(!t)throw Error('不完整公式：'+source);
   if(t.v==='-'||t.v==='+')node={op:'unary',sign:t.v,x:expr(4)};
   else if(t.v==='('){node=expr(0);if(!tokens[at]||tokens[at++].v!==')')throw Error('公式括号错误');}
   else if(t.t==='n'||t.t==='s')node={value:t.v};else if(t.t==='c')node={cell:t.v};
   else if(tokens[at]&&tokens[at].v==='('){at++;var args=[];if(tokens[at].v!==')')while(true){args.push(expr(0));if(tokens[at].v!==',')break;at++;}if(tokens[at++].v!==')')throw Error('函数括号错误');node={fn:t.v,args:args};}
   else throw Error('公式标记无效：'+t.v);
   while(tokens[at]&&prec[tokens[at].v]!==undefined&&prec[tokens[at].v]>=min){var op=tokens[at++].v;node={op:op,a:node,b:expr(prec[op]+(op==='^'?0:1))};}return node;
  }
  var result=expr(0);if(at!==tokens.length)throw Error('公式有未解析内容：'+source);parsed.set(source,result);return result;
 }
 function evaluator(sheet,overrides){var memo={},busy={};
  function cell(key){if(Object.prototype.hasOwnProperty.call(memo,key))return memo[key];if(busy[key])throw Error('公式循环：'+key);busy[key]=true;var raw=Object.prototype.hasOwnProperty.call(overrides,key)?overrides[key]:sheet.cells[key];var result=typeof raw==='string'&&raw.charAt(0)==='='?evaluate(parse(raw)):(raw===undefined||raw===null?0:raw);delete busy[key];memo[key]=result;return result;}
  function evaluate(n){if('value'in n)return n.value;if(n.cell)return cell(n.cell);if(n.fn){if(n.fn==='IF')return evaluate(n.args[0])?evaluate(n.args[1]):n.args[2]?evaluate(n.args[2]):false;var a=n.args.map(evaluate);if(n.fn==='SQRT')return Math.sqrt(Number(a[0]));if(n.fn==='ABS')return Math.abs(Number(a[0]));if(n.fn==='INT')return Math.floor(Number(a[0]));if(n.fn==='SUM')return a.reduce(function(v,x){return v+Number(x)},0);throw Error('未知函数：'+n.fn);}
   if(n.op==='unary')return(n.sign==='-'?-1:1)*Number(evaluate(n.x));var a=evaluate(n.a),b=evaluate(n.b);switch(n.op){case '+':return Number(a)+Number(b);case '-':return Number(a)-Number(b);case '*':return Number(a)*Number(b);case '/':if(Number(b)===0)throw Error('公式除以零');return Number(a)/Number(b);case '^':return Math.pow(Number(a),Number(b));case '=':return String(a).toUpperCase()===String(b).toUpperCase();case '<>':return String(a).toUpperCase()!==String(b).toUpperCase();case '>':return a>b;case '<':return a<b;case '>=':return a>=b;case '<=':return a<=b;}throw Error('未知运算');
  }return cell;
 }
 var outputs=[['CKV_period','CKV','period','J3'],['CKV_width','CKV','width','J4'],['CKV_tr','CKV','tr','J5'],['CKV_tf','CKV','tf','J6'],['CKV_gap','CKV','gap','J7'],['CKH_Width','CKH','width','J8'],['CKH_tr','CKH','tr','J9'],['CKH_tf','CKH','tf','J10'],['CKH_gap','CKH','gap','J11'],['VTH','CKH','VTH','J12'],['HTV','CKH','HTV','J13']];
 function refs(id){var s=data.sheets[id],codes=[...new Set(s.cells.J5.match(/C1="[^"]+"/g).map(function(x){return x.slice(4,-1)}))];return codes.filter(function(code,i){return Number(s.cached[String.fromCharCode(77+i)+'10'])>0;}).map(function(code){var i=codes.indexOf(code),c=String.fromCharCode(77+i);return{code:code,label:code+' · '+(s.cells[c+'9']||s.cells[c+'3']||'参考产品')};});}
 function defaults(id){var obj={};Object.keys(data.sheets[id].cells).forEach(function(c){var v=data.sheets[id].cells[c];if(typeof v!=='string'||v.charAt(0)!=='=')obj[c]=v;});return obj;}
 function calculate(id,inputs){var sheet=data.sheets[id],cell=evaluator(sheet,inputs||{}),patch={},warnings=[],errors=[];
  try{
   ['C4','C5','C9','C10','C11','C13','C18','J19','F4','F5','F6','F7','F8'].forEach(function(c){if(!Number.isFinite(Number(cell(c)))||Number(cell(c))<=0)errors.push(c+' 必须大于零');});
   ['C4','C5','C9','C18','C25','C27','C38','C39'].forEach(function(c){if(id==='cmos'&&c==='C27')return;if(!Number.isInteger(Number(cell(c))))errors.push(c+' 须为整数');});
   ['C14','C15','C31','C38','C39','I1','K1','M1','O1'].forEach(function(c){if(!Number.isFinite(Number(cell(c)))||Number(cell(c))<0)errors.push(c+' 须为非负数');});
   if(id!=='cmos'&&(['C35','C36'].some(function(c){return Number(cell(c))<=0})))errors.push('M1、M2膜厚必须大于零');
   if(Number(cell('C30'))<0||Number(cell('C30'))>=1)errors.push('展频占比须在 0 至 100% 之间');
   if(Number(cell('F6'))<=.4)errors.push('Gate_CD 须大于 0.4 μm');
   if(!refs(id).some(function(r){return r.code===cell('C1')}))errors.push('请选择有实测数据的参考产品');
   if(errors.length)return{errors:errors,warnings:warnings,patch:patch,cell:cell};
   outputs.forEach(function(o){var v=cell(o[3]);if(!Number.isFinite(v))errors.push(o[1]+' '+o[2]+' 无有效结果');patch[o[0]]=v;});
   if(cell('C32')<0||cell('C32')>1)warnings.push('fan1 占比超出 0–100%，fan2 电阻可能为负；请检查 fan1 length。');
   if(patch.CKV_width<0||patch.CKH_Width<0||patch.CKV_period<=0)errors.push('可用充电时间不足：检查刷新率、TP time、行数和时序间隔。');
   if([1,2,3,6].indexOf(Number(cell('C9')))===-1)warnings.push('原表没有此 Demux 数量的 CKH Overlay 分支，当前按原公式取 0。');
   if(Number(cell('F1'))!==3.8)warnings.push('原表标记 Pixel_Poly 3.0 / 2.5 模板待修正，结果需复核。');
   if(cell('F31')<0||cell('F32')<0||cell('F34')<0||cell('F35')<0)warnings.push('存在负电阻，中间计算结果不可直接用于设计。');
  }catch(e){errors.push(e.message);}
  return{errors:errors,warnings:warnings,patch:patch,cell:cell};
 }
 g.STGRFQ={evaluate:evaluator,calculate:calculate,defaults:defaults,references:refs,outputs:outputs,data:data};
})(window);
