// Metadata only: file contents and passwords never cross the WebView bridge.
let status={state:'loading',message:'正在读取密钥设置',path:''};
const $=s=>document.querySelector(s);
export function setKeyStatus(value){
 status=value||{state:'unavailable',message:'密钥状态无法读取，请检查设置',path:''};
 $('#keyStatus').textContent=status.message;
 $('#keyLocation').textContent=status.path||'尚未选择';
 $('#configureKey').textContent=status.state==='configured'?'重新选择密钥文件':'选择原加密密钥文件';
 $('#changeKeyPassword').disabled=status.state!=='configured';
 $('#keySummary').textContent=status.state==='configured'?'已配置':status.state==='loading'?'读取中':'需要配置';
}
export function setKeyBusy(value){for(const id of ['configureKey','refreshKeyStatus','backupKey','changeKeyPassword','restoreKey'])$('#'+id).disabled=value;if(!value)$('#changeKeyPassword').disabled=status.state!=='configured';}
export function requireKey(){
 if(status.state==='configured')return;
 $('#keySettings').open=true;$('#configureKey').focus();throw Error(status.message+'。请先完成签发密钥设置。');
}
export async function refreshKeyStatus(){setKeyStatus(await window.desktopAdmin.run('keyStatus'));}
$('#configureKey').onclick=async()=>{
 const button=$('#configureKey');button.disabled=true;$('#keyError').textContent='';
 try {setKeyStatus(await window.desktopAdmin.run('configureKey'));$('#keyError').textContent='验证通过，已记住密钥文件位置。后续签发只需输入这份密钥的管理密码。';}
 catch(e){$('#keyError').textContent=e.message;}
 finally{button.disabled=false;}
};
$('#refreshKeyStatus').onclick=()=>refreshKeyStatus().catch(e=>$('#keyError').textContent=e.message);

async function keyAction(operation,success){
 setKeyBusy(true);$('#keyError').textContent='';
 try{setKeyStatus(await window.desktopAdmin.run(operation));$('#keyError').textContent=success;}
 catch(e){$('#keyError').textContent=e.message;}
 finally{setKeyBusy(false);}
}
$('#changeKeyPassword').onclick=()=>keyAction('changeKeyPassword','管理密码已修改，后续签发使用新密码。原加密文件仍保留并使用旧密码，请妥善保管。');
$('#restoreKey').onclick=()=>keyAction('restoreKey','已从备份恢复同一把签发密钥。后续签发使用这份备份的密码；原备份文件未修改。');
