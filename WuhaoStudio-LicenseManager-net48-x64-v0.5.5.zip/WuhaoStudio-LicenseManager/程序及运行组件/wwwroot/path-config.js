// Format only the selected product's existing path. Never alter its saved/signing location.
export function licensePathSetting(path,separator='forward'){
 if(typeof path!=='string'||!path.trim()||/[\r\n\0]/.test(path))throw Error('授权文件路径无效');
 if(!['forward','backslash'].includes(separator))throw Error('请选择有效路径格式');
 const forward=path.replace(/\\/g,'/');
 return '"licensePath": '+JSON.stringify(separator==='backslash'?forward.replace(/\//g,'\\'):forward);
}
export function setupPathConfig({getBook,toast}){
 const $=s=>document.querySelector(s),dialog=$('#pathConfigDialog');let listId='';
 function update(){const list=getBook().lists.find(l=>l.id===listId);if(!list)throw Error('名单已变化，请重新打开产品文件');$('#pathConfigText').value=licensePathSetting(list.path,$('#pathSeparator').value);$('#pathConfigStatus').textContent='';}
 function open(id){const list=getBook().lists.find(l=>l.id===id);if(!list)throw Error('找不到产品文件');listId=id;$('#pathConfigProduct').textContent=list.product;$('#pathSeparator').value='forward';update();dialog.showModal();}
 $('#pathSeparator').onchange=()=>{try{update();}catch(e){toast(e.message);}};
 $('#closePathConfig').onclick=$('#cancelPathConfig').onclick=()=>dialog.close();
 $('#copyPathConfig').onclick=async()=>{
  try {
   update();const text=$('#pathConfigText').value;
   try {await navigator.clipboard.writeText(text);}
   catch {$('#pathConfigText').focus();$('#pathConfigText').select();if(!document.execCommand('copy')){$('#pathConfigStatus').textContent='自动复制不可用，内容已选中，请按 Ctrl+C 复制。';return;}}
   $('#pathConfigStatus').textContent='已复制，可替换 settings 中的 licensePath 配置项。';
  }catch(e){toast(e.message);}
 };
 return {open};
}
