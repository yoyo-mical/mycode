(function(){
 'use strict';var pending=false;
 function schedule(){if(pending)return;pending=true;requestAnimationFrame(function(){pending=false;var page=document.querySelector('.chart-page');if(!page)return;if(innerWidth<=640){page.style.removeProperty('height');return;}var top=page.getBoundingClientRect().top+scrollY;var height=Math.max(320,Math.floor(innerHeight-top-16))+'px';if(page.style.height!==height)page.style.height=height;});}
 addEventListener('resize',schedule);document.addEventListener('DOMContentLoaded',function(){var content=document.getElementById('content');if(content)new MutationObserver(schedule).observe(content,{childList:true});for(var node of document.querySelectorAll('.app-header,#tabnav'))new ResizeObserver(schedule).observe(node);schedule();});
})();
