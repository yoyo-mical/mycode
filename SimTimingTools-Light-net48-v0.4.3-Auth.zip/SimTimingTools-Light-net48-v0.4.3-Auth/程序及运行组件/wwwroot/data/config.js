// =====================================================================
// Sim-Timing-Generator 2026 —— 参数配置（等价翻译 Config.bas）
// 11 个参数分组、默认值与校验规则（从 Home 表读取逻辑逐项提取）
// =====================================================================
window.STG_CONFIG = (function () {
  'use strict';

  // 电压字符串选项（GetSTRVoltage 可识别的电压名）
  var VOLTAGE_OPTIONS = ['VGL', 'VGH', 'GND', 'Black', 'VCOM', 'VGH_Other_V', 'VGL_Other_V'];

  // 参数分组定义
  // 每个参数: key/label/type(number|select|string)/def(默认值)/unit/options/min/max
  var groups = [
    {
      id: 'eval', title: '1. 电性评估表', icon: '⚡',
      params: [
        { key: 'CKV_period', label: 'CKV_period', type: 'number', def: 18, unit: 'uS' },
        { key: 'CKV_width', label: 'CKV_width', type: 'number', def: 16, unit: 'uS' },
        { key: 'CKV_tr', label: 'CKV_tr', type: 'number', def: 0.5, unit: 'uS' },
        { key: 'CKV_tf', label: 'CKV_tf', type: 'number', def: 0.5, unit: 'uS' },
        { key: 'CKV_gap', label: 'CKV_gap', type: 'number', def: 1, unit: 'uS' },
        { key: 'CKH_Width', label: 'CKH_Width', type: 'number', def: 2, unit: 'uS' },
        { key: 'CKH_tr', label: 'CKH_tr', type: 'number', def: 0.5, unit: 'uS' },
        { key: 'CKH_tf', label: 'CKH_tf', type: 'number', def: 0.5, unit: 'uS' },
        { key: 'CKH_gap', label: 'CKH_gap', type: 'number', def: 1, unit: 'uS' },
        { key: 'VTH', label: 'VTH', type: 'number', def: 1, unit: 'uS' },
        { key: 'HTV', label: 'HTV', type: 'number', def: 1, unit: 'uS' },
        { key: 'CKHnum', label: 'CKHnum', type: 'number', def: 4 }
      ]
    },
    {
      id: 'basic', title: '2. 基础设置', icon: '⚙️',
      sections: [
        { title: '面板与仿真规模', keys: ['DisplayRow', 'DumVSR', 'endCKV', 'Videonum', 'SimCol', 'VSR_Mode', 'isTpExist', 'XCKHEnabled'] },
        { title: '帧结构', keys: ['delay', 'dumHeader_n', 'dumTail_m', 'BlankingTime'] },
        { title: '公共电压', keys: ['VGH', 'VGL', 'VCOM', 'GND', 'Black', 'VGH_Other_V', 'VGL_Other_V', 'Other_V'] },
        { title: '图案与 Video', keys: ['Pattenmode', 'VideoVoltage', 'Inversionmode', 'allPostV', 'cTalk'] },
        { title: '公共边沿时间', keys: ['tr_pub', 'tf_pub'] },
        { title: '输出格式', keys: ['SpiceWrap', 'Stringlong'] }
      ],
      params: [
        { key: 'DisplayRow', label: 'DisplayRow', type: 'number', def: 12 },
        { key: 'DumVSR', label: 'DumVSR(top+bottom)', type: 'number', def: 4 },
        { key: 'endCKV', label: 'EndCKV', type: 'number', def: 0 },
        { key: 'Videonum', label: 'Videonum', type: 'number', def: 6 },
        { key: 'SimCol', label: 'SimCol', type: 'number', def: 12 },
        { key: 'VSR_Mode', label: 'VSR_Mode', type: 'select', def: 'NMOS', options: ['NMOS', 'NMOS-2', 'CMOS'] },
        { key: 'XCKHEnabled', label: '启用 XCKH', type: 'select', def: '否', options: ['否', '是'] },
        { key: 'isTpExist', label: 'isTpExist', type: 'select', def: 'N', options: ['Y', 'N'] },
        { key: 'delay', label: 'delay', type: 'number', def: 20, unit: 'uS' },
        { key: 'dumHeader_n', label: 'dumHeader_n', type: 'number', def: 4 },
        { key: 'dumTail_m', label: 'dumTail_m', type: 'number', def: 4 },
        { key: 'BlankingTime', label: 'BlankingTime', type: 'number', def: 10, unit: 'uS' },
        { key: 'VGH', label: 'VGH', type: 'number', def: 10, unit: 'V' },
        { key: 'VGL', label: 'VGL', type: 'number', def: -7, unit: 'V' },
        { key: 'VCOM', label: 'VCOM', type: 'number', def: -0.1, unit: 'V' },
        { key: 'GND', label: 'GND', type: 'string', def: '0.2', unit: 'V' },
        { key: 'Black', label: 'Black', type: 'number', def: 0.2, unit: 'V' },
        { key: 'VGH_Other_V', label: 'VGH_Other_V', type: 'number', def: 4, unit: 'V' },
        { key: 'VGL_Other_V', label: 'VGL_Other_V', type: 'number', def: -4, unit: 'V' },
        { key: 'Other_V', label: 'Other_V', type: 'number', def: 5, unit: 'V' },
        { key: 'Pattenmode', label: 'Pattenmode', type: 'select', def: '1*1bar', options: ['1*1bar', 'Flicker', 'R', 'G', 'B', 'Black', 'White', 'Dotcheck', 'Pixcheck'] },
        { key: 'VideoVoltage', label: 'VideoVoltage', type: 'number', def: 5, unit: 'V' },
        { key: 'Inversionmode', label: 'Inversionmode', type: 'select', def: 'Column', options: ['Column', 'Zigzag'] },
        { key: 'allPostV', label: 'allPostV', type: 'select', def: '否', options: ['否', '是'] },
        { key: 'cTalk', label: 'cTalk中间框电压', type: 'number', def: 5.1, unit: 'V' },
        { key: 'tr_pub', label: 'tr_pub', type: 'number', def: 0.1, unit: 'uS' },
        { key: 'tf_pub', label: 'tf_pub', type: 'number', def: 0.1, unit: 'uS' },
        { key: 'SpiceWrap', label: '自动续行', type: 'select', def: '开启', options: ['开启', '关闭'] },
        { key: 'Stringlong', label: 'Stringlong（每行字符上限）', type: 'number', def: 2000, unit: '字符' },
      ]
    },
    {
      id: 'ckv', title: '3. CKV', icon: '📶',
      sections: [
        { title: '通道与起止', keys: ['CKVnum', 'CKVstart'] },
        { title: '分段电压与预充电', keys: ['CKVblankingVstr', 'CKVtpTermVstr', 'CKVpreCharge'], fullWidth: true },
        { title: 'EQ 总开关', keys: ['CKVEQ_SET'], fullWidth: true, compact: true },
        { title: '上升沿 EQ', keys: ['CKVtrEQ', 'CKVtrEQwidth', 'CKVtrEQVoltage', 'CKVtrEQVoltage2'] },
        { title: '下降沿 EQ', keys: ['CKVtfEQ', 'CKVtfEQwidth', 'CKVtfEQVoltage', 'CKVtfEQVoltage2'] }
      ],
      params: [
        { key: 'CKVnum', label: 'CKVnum', type: 'number', def: 4 },
        { key: 'CKVstart', label: 'CKVstart', type: 'number', def: 1 },
        { key: 'CKVEQ_SET', label: 'CKVEQ_SET', type: 'select', def: '否', options: ['否', '是'] },
        { key: 'CKVtrEQ', label: 'CKVtrEQ', type: 'number', def: 0 },
        { key: 'CKVtrEQVoltage', label: 'CKVtrEQVoltage', type: 'number', def: 0, unit: 'V' },
        { key: 'CKVtrEQVoltage2', label: 'CKVtrEQVoltage2', type: 'number', def: 0, unit: 'V' },
        { key: 'CKVtrEQwidth', label: 'CKVtrEQwidth', type: 'number', def: 0, unit: 'uS' },
        { key: 'CKVtfEQ', label: 'CKVtfEQ', type: 'number', def: 0 },
        { key: 'CKVtfEQVoltage', label: 'CKVtfEQVoltage', type: 'number', def: 0, unit: 'V' },
        { key: 'CKVtfEQVoltage2', label: 'CKVtfEQVoltage2', type: 'number', def: 0, unit: 'V' },
        { key: 'CKVtfEQwidth', label: 'CKVtfEQwidth', type: 'number', def: 0, unit: 'uS' },
        { key: 'CKVblankingVstr', label: 'CKVblankingV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'CKVtpTermVstr', label: 'CKVtpTermV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'CKVpreCharge', label: 'GatePreCharge', type: 'select', def: '否', options: ['否', '是'] }
      ]
    },
    {
      id: 'stv', title: '4. STV', icon: '📈',
      sections: [
        { title: '信号数量', keys: ['STVnum'] },
        { title: '与 CKV 的关系 · 负数提前，正数延后', keys: ['STVRiseOffset', 'STVFallOffset'] },
        { title: '边沿时间', keys: ['STVtr', 'STVtf'] },
        { title: '分段电压', keys: ['STVblankingVstr', 'STVtpTermVstr'] }
      ],
      params: [
        { key: 'STVnum', label: 'STVnum', type: 'number', def: 2, min: 1 },
        { key: 'STVRiseOffset', label: '上升偏移', type: 'number', def: -2.5, unit: 'uS' },
        { key: 'STVFallOffset', label: '下降偏移', type: 'number', def: 2.5, unit: 'uS' },

        { key: 'STVblankingVstr', label: 'STVblankingV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'STVtpTermVstr', label: 'STVtpTermV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'STVtr', label: 'STVtr', type: 'number', def: 0.5, unit: 'uS' },
        { key: 'STVtf', label: 'STVtf', type: 'number', def: 0.5, unit: 'uS' }
      ]
    },
    {
      id: 'u2d', title: '5. U2D', icon: '⬆️',
      params: [
        { key: 'U2DblankingVstr', label: 'U2DblankingV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'U2DtpTermVstr', label: 'U2DtpTermV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS }
      ]
    },
    {
      id: 'd2u', title: '6. D2U', icon: '⬇️',
      params: [
        { key: 'D2UblankingVstr', label: 'D2UblankingV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'D2UtpTermVstr', label: 'D2UtpTermV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS }
      ]
    },
    {
      id: 'gas', title: '7. GAS', icon: '🔀',
      params: [
        { key: 'GASblankingVstr', label: 'GASblankingV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'GAStpTermVstr', label: 'GAStpTermV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'GAStr', label: 'GAStr', type: 'number', def: 0.5, unit: 'uS' },
        { key: 'GAStr2', label: 'GAStr2', type: 'number', def: 0.5, unit: 'uS' }
      ]
    },
    {
      id: 'greset1', title: '8. GRESET1', icon: '🔄',
      params: [
        { key: 'GST1width', label: 'GST1width', type: 'number', def: 2, unit: 'uS' },
        { key: 'GST1Delay', label: 'GST1Delay', type: 'number', def: 0, unit: 'uS' },
        { key: 'GST1Value', label: 'GST1Value', type: 'select', def: 'VGH', options: ['VGH', 'VGL', 'VCOM'] },
        { key: 'GST1blankingVstr', label: 'GST1blankingV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'GST1tpTermVstr', label: 'GST1tpTermV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'GST1tr', label: 'GST1tr', type: 'number', def: 0.5, unit: 'uS' },
        { key: 'GST1tf', label: 'GST1tf', type: 'number', def: 0.5, unit: 'uS' }
      ]
    },
    {
      id: 'greset2', title: '9. GRESET2', icon: '🔄',
      params: [
        { key: 'GST2width', label: 'GST2width', type: 'number', def: 2, unit: 'uS' },
        { key: 'GST2Delay', label: 'GST2Delay', type: 'number', def: 0, unit: 'uS' },
        { key: 'GST2Value', label: 'GST2Value', type: 'select', def: 'VGH', options: ['VGH', 'VGL', 'VCOM'] },
        { key: 'GST2blankingVstr', label: 'GST2blankingV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'GST2tpTermVstr', label: 'GST2tpTermV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'GST2tr', label: 'GST2tr', type: 'number', def: 0.5, unit: 'uS' },
        { key: 'GST2tf', label: 'GST2tf', type: 'number', def: 0.5, unit: 'uS' }
      ]
    },
    {
      id: 'tp', title: '10. TP (Touch)', icon: '👆',
      sections: [
        { title: '插入位置', keys: ['TpPosition', 'TPstart'] },
        { title: '前后延时', keys: ['TPfrontDelay', 'TPbackDelay'] },
        { title: '脉冲时序', keys: ['TPpulseShape', 'TPnum', 'TPwidth', 'TPGap', 'TPtr', 'TPTf'] },
        { title: '电压', keys: ['TPbaseOffset', 'TPpulseDeltaV'] }
      ],
      params: [
        { key: 'TPfrontDelay', label: 'TPfrontDelay', type: 'number', def: 10, unit: 'uS' },
        { key: 'TPpulseShape', label: '脉冲形状（TPpulseShape）', type: 'select', def: '方波', options: ['方波', '正弦波'] },
        { key: 'TPbackDelay', label: 'TPbackDelay', type: 'number', def: 10, unit: 'uS' },
        // 整个 Touch（front + pulse + back）的底电压 = 各信号 Touch 基准 + TPbaseOffset。
        // pulse 的峰值 = 上述底电压 + TPpulseDeltaV；正值向上、负值向下。
        { key: 'TPpulseDeltaV', label: 'TPpulseDeltaV', type: 'number', def: 5, unit: 'V' },
        { key: 'TPbaseOffset', label: 'TPbaseOffset', type: 'number', def: 0, unit: 'V' },
        { key: 'TPwidth', label: 'TPwidth', type: 'number', def: 5, unit: 'uS' },
        { key: 'TPGap', label: 'TPGap', type: 'number', def: 5, unit: 'uS' },
        { key: 'TPnum', label: 'TPnum', type: 'number', def: 10 },
        { key: 'TPstart', label: 'TPstart', type: 'number', def: 4 },
        { key: 'TPtr', label: 'TPtr', type: 'number', def: 0.5, unit: 'uS' },
        { key: 'TPTf', label: 'TPTf', type: 'number', def: 0.5, unit: 'uS' },
        { key: 'TpPosition', label: 'TpPosition', type: 'select', def: 'displayLine', options: ['displayLine', 'dumHeader', 'dumTail'] }
      ]
    },
    {
      id: 'ckh', title: '10. CKH', icon: '📉',
      sections: [
        { title: '通道与排列', keys: ['RGBBGR'] },
        { title: '分段电压与预充电', keys: ['CKHBlankingVstr', 'CKHtpTermVstr', 'CKHPreCharge'] },
        { title: 'EQ 总开关', keys: ['CKHEQ_SET'], fullWidth: true, compact: true },
        { title: '上升沿 EQ', keys: ['CKHtrEQ', 'CKHtrEQwidth', 'CKHtrEQVoltage', 'CKHtrEQVoltage2'] },
        { title: '下降沿 EQ', keys: ['CKHtfEQ', 'CKHtfEQwidth', 'CKHtfEQVoltage', 'CKHtfEQVoltage2'] }
      ],
      params: [
        { key: 'RGBBGR', label: 'RGBBGR', type: 'select', def: '否', options: ['否', '是'] },
        { key: 'CKHEQ_SET', label: 'CKHEQ_SET', type: 'select', def: '否', options: ['否', '是'] },
        { key: 'CKHtrEQ', label: 'CKHtrEQ', type: 'number', def: 0 },
        { key: 'CKHtrEQVoltage', label: 'CKHtrEQVoltage', type: 'number', def: 0, unit: 'V' },
        { key: 'CKHtrEQVoltage2', label: 'CKHtrEQVoltage2', type: 'number', def: 0, unit: 'V' },
        { key: 'CKHtrEQwidth', label: 'CKHtrEQwidth', type: 'number', def: 0, unit: 'uS' },
        { key: 'CKHtfEQ', label: 'CKHtfEQ', type: 'number', def: 0 },
        { key: 'CKHtfEQVoltage', label: 'CKHtfEQVoltage', type: 'number', def: 0, unit: 'V' },
        { key: 'CKHtfEQVoltage2', label: 'CKHtfEQVoltage2', type: 'number', def: 0, unit: 'V' },
        { key: 'CKHtfEQwidth', label: 'CKHtfEQwidth', type: 'number', def: 0, unit: 'uS' },
        { key: 'CKHBlankingVstr', label: 'CKHBlankingV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'CKHtpTermVstr', label: 'CKHtpTermV', type: 'select', def: 'VGL', options: VOLTAGE_OPTIONS },
        { key: 'CKHPreCharge', label: 'DataPreCharge', type: 'number', def: 0 }
      ]
    },
    {
      id: 'video', title: '11. Video', icon: '🎬',
      params: [
        { key: 'Videotr', label: 'Videotr', type: 'number', def: 0.1, unit: 'uS' },
        { key: 'Videotf', label: 'Videotf', type: 'number', def: 0.1, unit: 'uS' },
        { key: 'VideoTCKH', label: 'VideoTCKH', type: 'number', def: 0.1, unit: 'uS' },
        { key: 'VideoBlankingVstr', label: 'VideoBlankingV', type: 'select', def: 'GND', options: VOLTAGE_OPTIONS },
        { key: 'VideoTPTermVstr', label: 'VideoTPTermV', type: 'select', def: 'GND', options: VOLTAGE_OPTIONS }
      ]
    }
  ];

  // 旧方案参数迁移：明确提供的规范键优先，不修改传入对象。
  // Home!CKH_Mode：每行是按时间先后排列的 CKH 通道编号。
  var modeParams = [];
  [2, 3, 4, 6].forEach(function (mux) {
    ['positive', 'negative'].forEach(function (frame) {
      modeParams.push({ key: 'CKHMode_' + mux + '_' + frame + '_rows', label: frame + ' 行数', type: 'number', def: 2 });
      for (var line = 1; line <= 4; line++) {
        var sequence = [];
        if (mux === 2 || mux === 3) {
          for (var channel = 1; channel <= mux; channel++) sequence.push(channel);
          if (line % 2 === 0) sequence.reverse();
        }
        modeParams.push({ key: 'CKHMode_' + mux + '_' + frame + '_' + line,
          label: frame + ' line' + line, type: 'string', def: sequence.join(' ') });
      }
    });
  });
  groups.push({ id: 'ckh-mode', title: '12. CKH_Mode', icon: '⇄', params: modeParams });


  var ckhGroup = groups.find(function(g){return g.id==='ckh';});
  var xparams = ckhGroup.params.map(function(p){
    var q=Object.assign({},p,{key:p.key==='RGBBGR'?'XCKHRGBBGR':p.key.replace(/^CKH/,'XCKH'),label:p.label.replace(/CKH/g,'XCKH')});
    if(/Vstr$/.test(p.key)){q.type='number';q.def=10;q.unit='V';delete q.options;}
    if(/Voltage/.test(p.key))q.def=-Number(p.def);
    return q;
  });
  ['CKH_tr','CKH_tf','CKH_Width','CKH_gap'].forEach(function(key){var p=groups[0].params.find(function(p){return p.key===key;});xparams.push(Object.assign({},p,{key:key.replace('CKH','XCKH'),label:key.replace('CKH','XCKH')}));});
  xparams.push({key:'XCKHOffset',label:'Offset CKH',type:'number',def:0,unit:'uS'});
  var xsections = ckhGroup.sections.map(function(section){
    return Object.assign({},section,{keys:section.keys.map(function(key){
      return key==='RGBBGR'?'XCKHRGBBGR':key.replace(/^CKH/,'XCKH');
    })});
  });
  xsections[0].keys.push('XCKHOffset');
  xsections.splice(1,0,
    {title:'脉冲形状',keys:['XCKH_tr','XCKH_Width','XCKH_tf','XCKH_gap']}
  );
  groups.push({id:'xckh',title:'XCKH',icon:'📉',sections:xsections,params:xparams});
  groups.push({id:'anomalies',title:'异常波形设置',icon:'〰',params:[]});
  var cardOrder=['eval','basic','ckv','ckh','xckh','ckh-mode','video','tp','stv','u2d','d2u','gas','greset1','greset2','anomalies'];
  groups.sort(function(a,b){return cardOrder.indexOf(a.id)-cardOrder.indexOf(b.id);});

  function normalizeValues(vals) {
    var out = Object.assign({}, vals || {});
    if (out.VSR_Mode === undefined) out.VSR_Mode = 'NMOS';
    // Migrate old edge-end offsets before defaults are merged; explicit new values win.
    if (out.STVRiseOffset === undefined && out.STVtCKV !== undefined)
      out.STVRiseOffset = -Number(out.STVtCKV) - Number(out.STVtr === undefined ? 0.5 : out.STVtr);
    if (out.STVFallOffset === undefined && out.CKVtSTV !== undefined)
      out.STVFallOffset = Number(out.CKVtSTV) + ckvTiming(Object.assign(defaults(), out)).fall;
    delete out.STVtCKV;
    delete out.CKVtSTV;

    var aliases = { GoutWidth: 'CKV_width', GoutGap: 'CKV_gap', CKVtr: 'CKV_tr', CKVtf: 'CKV_tf', VTHgap: 'VTH', HTvgap: 'HTV', TPdelay: 'TPfrontDelay', TPdelay2: 'TPbackDelay' };
    Object.keys(aliases).forEach(function (oldKey) {
      var key = aliases[oldKey];
      if (!Object.prototype.hasOwnProperty.call(out, key) && Object.prototype.hasOwnProperty.call(out, oldKey)) out[key] = out[oldKey];
      delete out[oldKey];
    });
    ['width', 'Delay', 'Value', 'blankingVstr', 'tpTermVstr', 'tr', 'tf'].forEach(function (suffix) {
      var oldKey = 'GST' + suffix, key = 'GST1' + suffix;
      if (!Object.prototype.hasOwnProperty.call(out, key) && Object.prototype.hasOwnProperty.call(out, oldKey)) out[key] = out[oldKey];
      delete out[oldKey];
    });
    // 旧绝对电压仅迁移压差；低电压不等于相对各信号基准的偏移。
    if (!Object.prototype.hasOwnProperty.call(out, 'TPpulseDeltaV') &&
        Object.prototype.hasOwnProperty.call(out, 'TPVH') && Object.prototype.hasOwnProperty.call(out, 'TPVL')) {
      out.TPpulseDeltaV = num(out.TPVH) - num(out.TPVL);
    }
    if (!Object.prototype.hasOwnProperty.call(out, 'TPbaseOffset')) out.TPbaseOffset = 0;
    delete out.TPVH;
    delete out.TPVL;
    ['Delay2','Delay3','Delay4'].forEach(function(key){delete out[key];});
    delete out.dualCKH;
    delete out.dualXCKH;
    delete out.VideoClock;
    delete out.XCKHHigh;
    delete out.XCKHBase;
    delete out.CKVinSTVnum; // 已移除，不再使用覆盖数量配置。
    delete out.TPtime; // 总时长由时序参数计算，不接受旧方案中的输入值。
    return out;
  }

  // 生成扁平默认值对象
  function defaults() {
    var d = {};
    groups.forEach(function (g) {
      g.params.forEach(function (p) { d[p.key] = p.def; });
    });
    var rows = deriveDummyRows(d);
    if (rows) Object.assign(d, rows);
    return d;
  }

  // 电压字符串 → 实际电压值（等价 GetSTRVoltage）
  function resolveVoltage(strV, vals) {
    switch (strV) {
      case 'VGL': return num(vals.VGL);
      case 'VGH': return num(vals.VGH);
      case 'VGH_Other_V': return num(vals.VGH_Other_V);
      case 'VGL_Other_V': return num(vals.VGL_Other_V);
      case 'GND': return num(vals.GND);
      case 'Black': return num(vals.Black);
      case 'VCOM': return num(vals.VCOM);
      default: return Number.isFinite(Number(strV)) ? Number(strV) : num(vals.VGL);
    }
  }

  // 各模式平分 dummy VSR；头部补行按模式，尾部统一追加2行和 EndCKV。
  // 显式提供的头尾行数仍可手动覆盖。
  function deriveDummyRows(vals) {
    var extra = { 'NMOS': 2, 'NMOS-2': 0, 'CMOS': 1 }[String(vals.VSR_Mode).toUpperCase()];
    if (extra === undefined) return null;
    if (vals.DumVSR === '' || vals.endCKV === '') return null;
    var dummy = Number(vals.DumVSR), end = Number(vals.endCKV);
    if (!Number.isInteger(dummy) || dummy < 0 || dummy % 2 !== 0 || !Number.isInteger(end) || end < 0) return null;
    return { dumHeader_n: dummy / 2 + extra, dumTail_m: dummy / 2 + 2 + end };
  }

  function validateSTV(vals) {
    var errors = [];
    var count = Number(vals.STVnum);
    if (!Number.isInteger(count) || count < 1) errors.push('STVnum 必须是大于等于1的整数。');
    if (count > Number(vals.dumHeader_n)) errors.push('STVnum 不能超过 dumHeader_n，每个 STV 需要对应一个头部 CKV 脉冲。');
    ['STVtr', 'STVtf'].forEach(function (key) {
      var raw = vals[key], value = Number(raw);
      if (raw === undefined || raw === null || String(raw).trim() === '' || !Number.isFinite(value) || value < 0) errors.push(key + ' 必须填写大于等于0的时间。');
    });
    ['STVRiseOffset', 'STVFallOffset'].forEach(function(key){
      var value=vals[key];
      if(value===undefined || value===null || String(value).trim()==='' || !Number.isFinite(Number(value)))
        errors.push((key==='STVRiseOffset'?'上升偏移':'下降偏移')+' 必须为有效时间，允许负数。');
    });
    if(!Number.isFinite(Number(vals.delay)) || String(vals.delay).trim()==='' || Number(vals.delay)<0)
      errors.push('delay 必须为非负有限时间。');
    var phase=stvPhase(vals);
    if(Number.isFinite(phase.hold) && phase.hold < -1e-6)
      errors.push('STV 上升尚未结束就开始下降：高电平保持时间为 '+Number(phase.hold.toFixed(6))+' μs，请提前上升或延后下降。');
    ['tr_pub', 'tf_pub'].forEach(function (key) {
      if (!Number.isFinite(Number(vals[key])) || Number(vals[key]) < 0) errors.push(key + ' 必须大于等于0。');
    });
    if (String(vals.isTpExist).toUpperCase() === 'Y') {
      ['TPfrontDelay', 'TPbackDelay', 'TPtr', 'TPTf', 'TPwidth', 'TPGap'].forEach(function (key) {
        if (vals[key] === '' || !Number.isFinite(Number(vals[key])) || Number(vals[key]) < 0) errors.push(key + ' 必须填写大于等于0的时间。');
      });
      if (!Number.isInteger(Number(vals.TPnum)) || Number(vals.TPnum) < 1) errors.push('TPnum 必须是大于等于1的整数。');
      ['TPbaseOffset', 'TPpulseDeltaV'].forEach(function (key) {
        if (vals[key] === '' || !Number.isFinite(Number(vals[key]))) errors.push(key + ' 必须填写有效电压。');
      });
    }
    return errors;
  }

  function validateCKV(vals) {
    var errors = [];
    ['CKV_tr', 'CKV_tf', 'CKV_width', 'CKV_gap', 'CKV_period'].forEach(function (key) {
      var raw = vals[key], value = Number(raw);
      if (raw === undefined || raw === null || String(raw).trim() === '' || !Number.isFinite(value) || (key !== 'CKV_gap' && value < 0) || (key === 'CKV_period' && value === 0)) {
        errors.push(key + (key === 'CKV_period' ? ' 必须大于 0。' : ' 必须填写大于等于 0 的时间。'));
      }
    });
    if (!errors.length) {
      var total = num(vals.CKV_tr) + num(vals.CKV_width) + num(vals.CKV_tf) + num(vals.CKV_gap);
      if (Math.abs(total - num(vals.CKV_period)) > 1e-6) {
        errors.push('CKV 周期不一致：CKV_tr + CKV_width + CKV_tf + CKV_gap = ' + total + ' μs，必须等于 CKV_period = ' + vals.CKV_period + ' μs。');
      }
    }
    return errors.concat(validateCKVEQ(vals));
  }

  function validateCKVEQ(vals) {
    if (String(vals.CKVEQ_SET) !== '是') return [];
    var errors = [];
    function read(key) {
      var raw = vals[key];
      var value = (raw === undefined || raw === null || String(raw).trim() === '') ? NaN : Number(raw);
      if (!Number.isFinite(value)) errors.push(key + ' 必须填写有效电压。');
      return value;
    }
    var low = read('VGL'), high = read('VGH');
    if (Number.isFinite(low) && Number.isFinite(high) && !(low < high)) errors.push('VGL 必须小于 VGH。');
    ['tr', 'tf'].forEach(function (edge) {
      var rampKey = 'CKV' + edge + 'EQ';
      var holdKey = rampKey + 'width';
      var ramp = Number(vals[rampKey]), hold = Number(vals[holdKey]);
      if (vals[rampKey] === '' || !Number.isFinite(ramp) || ramp < 0) errors.push(rampKey + ' 必须大于等于 0。');
      if (ramp === 0 && vals[rampKey] !== '') return; // 该边沿关闭 EQ，忽略平台参数并使用普通边沿。
      if (vals[holdKey] === '' || !Number.isFinite(hold) || hold < 0) errors.push(holdKey + ' 必须大于等于 0。');
      var key = 'CKV' + edge + 'EQVoltage';
      var first = read(key), second = read(key + '2');
      var name = edge === 'tr' ? '上升沿' : '下降沿';
      if (Number.isFinite(first) && Number.isFinite(low) && Number.isFinite(high) && !(low < first && first < high)) {
        errors.push(name + '：' + key + ' 必须严格位于 VGL 和 VGH 之间。');
      }
      if (!Number.isFinite(second) || second === 0) return; // 第二平台 0 表示关闭。
      if (Number.isFinite(low) && Number.isFinite(high) && !(low < second && second < high)) {
        errors.push(name + '：' + key + '2 必须严格位于 VGL 和 VGH 之间。');
      }
      if (Number.isFinite(first) && (edge === 'tr' ? !(first < second) : !(first > second))) {
        errors.push(name + '：' + key + '2 必须' + (edge === 'tr' ? '大于' : '小于') + ' ' + key + '。');
      }
    });
    if (!errors.length && ckvTiming(vals).width < -1e-9) {
      errors.push('CKV_width 不足以容纳 EQ 边沿：增加的边沿时间超过原高电平保持宽度，请减小 EQ 时间或调整脉冲参数。');
    }
    return errors;
  }

  // EQ 增量从高电平保持宽度扣除，普通脉冲周期及 gap 保持不变。
  function ckvTiming(vals) {
    var tr = num(vals.CKV_tr), tf = num(vals.CKV_tf);
    var rise = tr, fall = tf;
    if (String(vals.CKVEQ_SET) === '是') {
      function duration(edge) {
        if (num(vals['CKV' + edge + 'EQ']) === 0) return edge === 'tr' ? tr : tf;
        var platforms = num(vals['CKV' + edge + 'EQVoltage2']) === 0 ? 1 : 2;
        return (platforms + 1) * num(vals['CKV' + edge + 'EQ']) + platforms * num(vals['CKV' + edge + 'EQwidth']);
      }
      rise = duration('tr');
      fall = duration('tf');
    }
    return {
      rise: rise, fall: fall,
      width: num(vals.CKV_width) - (rise - tr) - (fall - tf),
      period: tr + num(vals.CKV_width) + tf + num(vals.CKV_gap)
    };
  }

  // CKH 使用与 CKV 相同的 EQ 校验和周期保持规则。
  function ckhEQValues(vals) {
    var mapped = Object.assign({}, vals);
    ['tr', 'tf'].forEach(function (edge) {
      ['', 'width', 'Voltage', 'Voltage2'].forEach(function (suffix) {
        mapped['CKV' + edge + 'EQ' + suffix] = vals['CKH' + edge + 'EQ' + suffix];
      });
    });
    mapped.CKVEQ_SET = vals.CKHEQ_SET;
    mapped.CKV_tr = vals.CKH_tr;
    mapped.CKV_tf = vals.CKH_tf;
    mapped.CKV_width = vals.CKH_Width;
    mapped.CKV_gap = vals.CKH_gap;
    return mapped;
  }
  function validateCKHEQ(vals) {
    return validateCKVEQ(ckhEQValues(vals)).map(function (error) {
      return error.replace(/CKV_width/g, 'CKH_Width').replace(/CKV/g, 'CKH');
    });
  }

  function stvPhase(vals) {
    var timing=ckvTiming(vals), c1=0, c2=timing.rise, c3=c2+timing.width+(String(vals.CKVpreCharge)==='是'?num(vals.CKV_period):0), c4=c3+timing.fall;
    var p1=Number(vals.STVRiseOffset), p2=p1+Number(vals.STVtr);
    var p3=c3+Number(vals.STVFallOffset), p4=p3+Number(vals.STVtf);
    var hold=p3-p2, relation='参数无效';
    if([p1,p2,p3,p4,c4].every(Number.isFinite) && hold>=-1e-6) {
      if(p4<=c1+1e-6)relation='③ STV 在 CKV 之前';
      else if(p1>=c4-1e-6)relation='STV 在 CKV 之后';
      else if(p1<=c1+1e-6 && p4>=c4-1e-6)relation='① STV 包含 CKV';
      else if(p1<=c1+1e-6)relation='② 提前上升、提前结束，有重叠';
      else if(p4>=c4-1e-6)relation='④ 延后上升、延后结束';
      else relation='⑤ STV 位于 CKV 内部';
    }
    return {stv:[p1,p2,p3,p4],ckv:[c1,c2,c3,c4],hold:hold,relation:relation,
      lead:Math.max(0,-p1),ckvStart:Number(vals.delay)+Math.max(0,-p1)};
  }

  function ckhTiming(vals) { return ckvTiming(ckhEQValues(vals)); }

  function touchDuration(vals) {
    return num(vals.TPfrontDelay) +
      (num(vals.TPtr) + num(vals.TPwidth) + num(vals.TPTf) + num(vals.TPGap)) * (parseInt(vals.TPnum, 10) || 0) +
      num(vals.TPbackDelay);
  }

  function num(v) { var n = parseFloat(v); return isNaN(n) ? 0 : n; }

  return {
    groups: groups,
    voltageOptions: VOLTAGE_OPTIONS,
    defaults: defaults,
    touchDuration: touchDuration,
    validateCKVEQ: validateCKVEQ,
    validateCKV: validateCKV,
    validateSTV: validateSTV,
    deriveDummyRows: deriveDummyRows,
    ckvTiming: ckvTiming,
    stvPhase: stvPhase,
    ckhTiming: ckhTiming,
    validateCKHEQ: validateCKHEQ,
    normalizeValues: normalizeValues,
    resolveVoltage: resolveVoltage
  };
})();
