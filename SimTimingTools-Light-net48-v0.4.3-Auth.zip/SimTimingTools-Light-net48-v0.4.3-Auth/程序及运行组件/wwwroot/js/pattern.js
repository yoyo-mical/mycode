(function (global) {
  'use strict';
  var COLORS = ['R', 'G', 'B'];
  function integer(value, fallback, max) { var n = Number(value); return Number.isInteger(n) && n >= 1 && n <= max ? n : fallback; }
  function source(vals) {
    var columns = Number(vals.Videonum) * Number(vals.CKHnum);
    return { mode: String(vals.Pattenmode || '1*1bar'), voltage: Number(vals.VideoVoltage), inversion: String(vals.Inversionmode || 'Column'), black: Number(vals.Black),
      rows: integer(vals.DisplayRow, 12, 100000), dataColumns: integer(columns, 12, 100000), cols: Math.ceil(integer(columns, 12, 100000) / 3) };
  }
  function presetValue(vals, row, col, color) {
    var mode=String(vals.Pattenmode || '1*1bar'), amplitude=Math.abs(Number(vals.VideoVoltage));
    if (!Number.isFinite(amplitude)) return null;
    var subcolumn=(col-1)*3+COLORS.indexOf(color)+1;
    if (mode === 'Flicker') {
      var shifted=(vals.Inversionmode === 'Zigzag' || vals.Inversionmode === 'Frame') && row%2 === 0;
      var data=subcolumn+(shifted?1:0), columns=Number(vals.Videonum)*Number(vals.CKHnum);
      return data>columns?0:data%2===1?amplitude:0;
    }
    if (mode === '1*1bar') return row % 2 === 0 ? 0 : amplitude * (subcolumn%2===0?-1:1);
    var data=subcolumn+((vals.Inversionmode === 'Zigzag' || vals.Inversionmode === 'Frame') && row%2===0?1:0);
    if(data>Number(vals.Videonum)*Number(vals.CKHnum))return 0;
    var black=Math.abs(Number(vals.Black));if(!Number.isFinite(black))return null;
    var magnitude;
    if(COLORS.includes(mode))magnitude=color===mode?amplitude:black;
    else if(mode==='Black')magnitude=black;
    else if(mode==='White')magnitude=amplitude;
    else if(mode==='Dotcheck')magnitude=(row+subcolumn)%2===0?amplitude:black;
    else if(mode==='Pixcheck')magnitude=(row+col)%2===0?amplitude:black;
    else return null;
    return magnitude*(data%2===1?1:-1);
  }
  function matchesBarPreset(values, rows, cols) {
    var first = values['1:1:R'];
    if (first === '' || first === null || first === undefined || !Number.isFinite(Number(first)) || Number(first) < 0) return false;
    var magnitude = Number(first);
    for (var row = 1; row <= rows; row++) for (var col = 1; col <= cols; col++) for (var color = 0; color < 3; color++) {
      var value = values[row + ':' + col + ':' + COLORS[color]];
      var expected = row % 2 === 0 ? 0 : magnitude * (((col - 1) * 3 + color) % 2 ? -1 : 1);
      if (value === '' || value === null || value === undefined || !Number.isFinite(Number(value)) || Math.abs(Number(value) - expected) > 1e-9) return false;
    }
    return true;
  }
  function prepare(raw, vals) {
    var config = raw && typeof raw === 'object' && !Array.isArray(raw) ? JSON.parse(JSON.stringify(raw)) : {};
    var current = source(vals);
    config.maps = config.maps && typeof config.maps === 'object' ? config.maps : {};
    config.pixelColumns = integer(config.pixelColumns, Math.min(128, current.cols), 128);
    if (config.format !== 'full-image-v1') {
      var old = config.cells || {}, oldRows = integer(config.rows, 2, 16), oldCols = integer(config.cols, 4, 16);
      config.values = {}; config.modified = {};
      config.custom = Object.keys(old).length > 0;
      if (config.custom) {
        for (var r = 1; r <= current.rows; r++) for (var c = 1; c <= current.cols; c++) COLORS.forEach(function (color) {
          var cell = old[((r - 1) % oldRows + 1) + ':' + ((c - 1) % oldCols + 1) + ':' + color];
          if (cell) config.values[r + ':' + c + ':' + color] = cell.magnitude === '' ? '' : Number(cell.magnitude) * Number(cell.polarity);
        });
      }
      delete config.cells;
      config.format = 'full-image-v1'; config.source = current;
      config.rows = current.rows; config.cols = current.cols; config.dataColumns = current.dataColumns; config.pixelColumns = current.cols;
    }
    // 老版本没有编辑标记；只将完整符合1*1bar、且未记录手动修改的数据恢复为预设。
    if (!config.presetMigrationChecked && config.custom && Object.keys(config.modified || {}).length === 0 &&
        matchesBarPreset(config.values || {}, integer(config.rows, current.rows, 100000), integer(config.cols, current.cols, 100000))) {
      config.custom = false;
    }
    config.presetMigrationChecked = true;
    config.rows = current.rows; config.cols = current.cols; config.dataColumns = current.dataColumns; config.pixelColumns = current.cols;
    config.values = config.values || {}; config.modified = config.modified || {};
    for (var row = 1; row <= config.rows; row++) for (var col = 1; col <= config.cols; col++) COLORS.forEach(function (color) {
      var key = row + ':' + col + ':' + color;
      if (!config.custom || !Object.prototype.hasOwnProperty.call(config.values, key)) config.values[key] = presetValue(vals, row, col, color);
    });
    if (!config.custom) config.source = current;
    if (!config.wiring || config.wiring.grouping !== 'custom') {
      var mux = Number(vals.CKHnum), videos = Number(vals.Videonum), map = {};
      config.wiring = config.wiring || {grouping: "interleaved", order: "forward"};
      for (var v = 1; v <= videos; v++) for (var h = 1; h <= mux; h++) {
        var slot = config.wiring.order === 'reverse' ? mux - h : h - 1;
        var d = Math.floor((v-1)/2)*mux*2+(v-1)%2+slot*2+1;
        map[v+':'+h] = d <= current.dataColumns ? {pixel:Math.floor((d-1)/3)+1,color:COLORS[(d-1)%3]} : {pixel:'',color:'R'};
      }
      config.maps[String(mux)] = map; config.wiring.grouping = 'interleaved';
    }
    if (config.wiring.grouping === 'custom') {
      var mux = Number(vals.CKHnum), videos = Number(vals.Videonum), map = config.maps[String(mux)] || {}, used = {}, missing = [];
      for (var v = 1; v <= videos; v++) for (var h = 1; h <= mux; h++) {
        var key = v+':'+h, target = map[key], d = target && target.pixel ? (Number(target.pixel)-1)*3+COLORS.indexOf(target.color)+1 : 0;
        if (Number.isInteger(d) && d > 0 && d <= current.dataColumns && !used[d]) used[d] = true;
        else missing.push({key:key, preferred:Math.floor((v-1)/2)*mux*2+(v-1)%2+(h-1)*2+1});
      }
      missing.forEach(function(slot) {
        var d = slot.preferred;
        if (used[d]) {for (d=1; d<=current.dataColumns && used[d]; d++);}
        map[slot.key] = {pixel:Math.floor((d-1)/3)+1,color:COLORS[(d-1)%3]}; used[d]=true;
      });
      config.maps[String(mux)] = map;
    }
    config.description = describe(config, vals);
    return config;
  }
  function voltage(config, row, pixel, color, frame) {
    if (!Number.isInteger(row) || row < 1 || row > config.rows || !Number.isInteger(pixel) || pixel < 1 || pixel > config.cols || !COLORS.includes(color)) return null;
    if ((pixel - 1) * 3 + COLORS.indexOf(color) >= config.dataColumns) return null;
    var value = config.values[row + ':' + pixel + ':' + color];
    if (value === '' || value === null || value === undefined || !Number.isFinite(Number(value))) return null;
    return Number(value) * (frame === 'negative' ? -1 : 1);
  }
  var RULES = { uniform: '同值填充', rows: '隔行填值', cols: '隔列填值', checker: '棋盘格', rowSequence: '按行周期序列', colSequence: '按列周期序列' };
  function applyRule(config, rule) {
    var bounds = [rule.rowFrom, rule.rowTo, rule.colFrom, rule.colTo];
    if (bounds.some(function (x) { return !Number.isInteger(x) || x < 1; }) || rule.rowFrom > rule.rowTo || rule.colFrom > rule.colTo || rule.rowTo > config.rows || rule.colTo > config.cols || !RULES[rule.kind] || !['all', 'R', 'G', 'B'].includes(rule.color)) throw new Error('请填写有效的行列范围。');
    var repeating = rule.kind === 'rowSequence' || rule.kind === 'colSequence';
    if (repeating ? !Array.isArray(rule.sequence) || !rule.sequence.length || rule.sequence.some(function (x) { return !Number.isFinite(x); }) : !Number.isFinite(rule.a) || (rule.kind !== 'uniform' && !Number.isFinite(rule.b))) throw new Error('请填写有效电压；周期序列用空格或逗号分隔。');
    for (var r = rule.rowFrom; r <= rule.rowTo; r++) for (var c = rule.colFrom; c <= rule.colTo; c++) COLORS.forEach(function (color) {
      if ((c - 1) * 3 + COLORS.indexOf(color) >= config.dataColumns) return;
      if (rule.color !== 'all' && rule.color !== color) return;
      var dr = r - rule.rowFrom, dc = c - rule.colFrom, value = rule.a;
      if (rule.kind === 'rows') value = dr % 2 ? rule.b : rule.a;
      else if (rule.kind === 'cols') value = dc % 2 ? rule.b : rule.a;
      else if (rule.kind === 'checker') value = (dr + dc) % 2 ? rule.b : rule.a;
      else if (repeating) value = rule.sequence[(rule.kind === 'rowSequence' ? dr : dc) % rule.sequence.length];
      var key = r + ':' + c + ':' + color;
      config.values[key] = value; config.modified[key] = true;
    });
    config.custom = true; config.editor = { kind: 'rule', rule: JSON.parse(JSON.stringify(rule)) };
  }
  function describe(config, vals) {
    var title, editor = config.editor || { kind: 'manual' };
    if (!config.custom) title = source(vals).mode + ' · ' + Number(vals.VideoVoltage) + ' V';
    else {
      var min = Infinity, max = -Infinity, invalid = false;
      for (var r = 1; r <= config.rows; r++) for (var c = 1; c <= config.cols; c++) COLORS.forEach(function (color) {
        if ((c - 1) * 3 + COLORS.indexOf(color) >= config.dataColumns) return;
        var v = voltage(config, r, c, color); if (v === null) invalid = true; else { min = Math.min(min, v); max = Math.max(max, v); }
      });
      var range = min === Infinity ? '无有效电压' : min === max ? min + ' V' : min + '～' + max + ' V';
      if (editor.kind === 'rule' && editor.rule && RULES[editor.rule.kind]) {
        var rule = editor.rule;
        var full = rule.rowFrom === 1 && rule.rowTo === config.rows && rule.colFrom === 1 && rule.colTo === config.cols && rule.color === 'all';
        var values = /Sequence$/.test(rule.kind) ? '序列 ' + rule.sequence.join(', ') + ' V' : rule.kind === 'uniform' ? rule.a + ' V' : 'A=' + rule.a + ' V / B=' + rule.b + ' V';
        title = (full ? '' : '自定义图案 · 局部') + RULES[rule.kind] + ' · ' + values;
      } else title = '自定义图案 · 手动修改';
      title += ' · 电压 ' + range + (invalid ? '（含无效值）' : '');
    }
    return title + ' · ' + config.rows + ' 行 × ' + config.cols + ' 像素列 · ' + config.dataColumns + ' 子列';
  }
  function sequence(vals, row, frame) {
    var mux = Number(vals.CKHnum), prefix = 'CKHMode_' + mux + '_' + frame;
    var repeat = Number(vals[prefix + '_rows']);
    if (!Number.isInteger(repeat) || repeat < 1) return null;
    var items = String(vals[prefix + '_' + ((row - 1) % repeat + 1)] || '').trim().split(/[\s,，]+/).map(Number);
    return items.length === mux && new Set(items).size === mux && items.every(function (x) { return Number.isInteger(x) && x >= 1 && x <= mux; }) ? items : null;
  }
  function aaTarget(vals, row, data, columns) {
    if (!Number.isInteger(data) || data < 1 || data > columns) return null;
    var shifted = (vals.Inversionmode === 'Zigzag' || vals.Inversionmode === 'Frame') && row % 2 === 0;
    var subcolumn = data - (shifted ? 1 : 0);
    return subcolumn < 1 ? null : {pixel:Math.floor((subcolumn-1)/3)+1,color:COLORS[(subcolumn-1)%3],subcolumn:subcolumn};
  }
  function preview(config, vals, row, video, frame) {
    var order = sequence(vals, row, frame), map = config.maps[String(vals.CKHnum)] || {};
    if (!order) return null;
    return order.map(function (channel) {
      var target = map[video + ':' + channel];
      if (!target || !Number.isInteger(Number(target.pixel)) || target.pixel < 1 || target.pixel > config.pixelColumns || !COLORS.includes(target.color)) return { channel: channel, target: null, voltage: null };
      var data = (Number(target.pixel)-1)*3+COLORS.indexOf(target.color)+1;
      var pixel = aaTarget(vals,row,data,config.dataColumns);
      return {channel:channel,data:data,target:pixel,unconnected:!pixel,voltage:pixel ? voltage(config,row,pixel.pixel,pixel.color,frame) : null};
    });
  }
  function render(container, vals, onSave, onParameters) {
    var config = prepare(vals.PatternConfig, vals), mux = Number(vals.CKHnum), videos = Number(vals.Videonum);
    if (!Number.isInteger(videos) || videos < 2 || videos % 2 !== 0 || ![2,3,4,6].includes(mux)) { container.textContent = '请先将 Video 条数设为正偶数，CKHnum 设为 2、3、4、6；仿真子列数自动计算。'; return; }
    var activeRow = 1, activeVideo = 1, frame = vals.CKHModeFrame === 'negative' ? 'negative' : 'positive';
    var previewArea, frameInput, patternStatus, frameButtons = [];
    function node(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
    function save() { config.description = describe(config, vals); onSave(config); }
    function field(label, control) { control.setAttribute('aria-label', label); var wrap = node('label', 'pattern-field'); wrap.appendChild(node('span', '', label)); wrap.appendChild(control); return wrap; }
    function number(value, min, max) { var e = node('input'); e.type = 'number'; e.min = min; if (max) e.max = max; e.step = '1'; e.value = value; return e; }
    function select(options, value) { var e = node('select'); options.forEach(function (o) { var opt = node('option', '', o[1]); opt.value = o[0]; e.appendChild(opt); }); e.value = String(value); return e; }
    function button(label, action) { var e = node('button', 'tbtn', label); e.type = 'button'; e.onclick = action; return e; }
    function section(title, subtitle) {
      var e = node('section', 'pattern-card'); e.appendChild(node('h2', '', title));
      var help = node('details', 'pattern-help-panel'); help.appendChild(node('summary', '', '使用说明'));
      var text = '方格显示 Pattern 电压，下方为 Data、CKH 和 Video 连接。正帧可直接编辑，负帧自动取反并只读；支持规律填值。自定义连接可直接修改 Data 编号，已占用编号可交换。点连线高亮，点空白或按 Escape 取消。Column 每行直连；Zigzag 偶数行接左邻，边缘不连接。';
      help.appendChild(node('p', 'pattern-help', text)); e.appendChild(help); container.appendChild(e); return e;
    }
    function rebuild() { container.innerHTML = ''; render(container, Object.assign({}, vals, { PatternConfig: config }), onSave, onParameters); }
    function updatePreview() { if (panelView) drawWiring(); }
    container.classList.add('pattern-page');

    var card = section('Pattern / Video 映射');
    card.appendChild(node('h3','','图案与 Video'));
    var sharedControls=node('div','pattern-controls pattern-shared-parameters');
    var sharedKeys=['Pattenmode','VideoVoltage','Inversionmode'];
    var params=[];global.STG_CONFIG.groups.forEach(function(group){group.params.forEach(function(param){if(sharedKeys.includes(param.key))params.push(param);});});
    params.forEach(function(param){
      var input=param.type==='select'?select(param.options.map(function(value){return [value,value];}),vals[param.key]):number(vals[param.key],undefined);
      if(param.type!=='select'){input.removeAttribute('min');input.step='any';}
      input.setAttribute('data-key',param.key);
      input.onchange=function(){var patch={};patch[param.key]=input.value;if(onParameters)onParameters(patch);else{Object.assign(vals,patch);rebuild();}};
      sharedControls.appendChild(field(param.label+(param.unit?'（'+param.unit+'）':''),input));
    });
    card.appendChild(sharedControls);
    var controls = node('div', 'pattern-controls');
    var summary = node('span', 'pattern-summary');
    controls.appendChild(summary);
    controls.appendChild(button('按当前参数重新生成', function () {
      config.custom = false; config.modified = {}; config = prepare(config, vals); save(); refreshStatus(); drawGrid(); updatePreview();
    }));
    card.appendChild(controls);
    var metadataControls=controls;
    sharedControls.appendChild(metadataControls.querySelector('button'));
    patternStatus = node('p', 'pattern-status'); patternStatus.setAttribute('role', 'status');
    function refreshStatus() {
      summary.textContent = describe(config, vals);
      var changed = JSON.stringify(config.source) !== JSON.stringify(source(vals));
      patternStatus.textContent = config.custom ? '自定义' + (changed ? ' · 参数已变化，保留手动值' : '') : '按参数生成';
    }
    controls = node('div', 'pattern-controls');
    ['positive', 'negative'].forEach(function (which) {
      var btn = button(which === 'positive' ? '正帧（可编辑）' : '负帧', function () { changeFrame(which); });
      btn.dataset.frame = which; frameButtons.push(btn); controls.appendChild(btn);
    });

    card.appendChild(controls);
    var frameControls=controls;
    var bulkDetails = node('details', 'pattern-bulk'); bulkDetails.appendChild(node('summary', '', '规律填值（正帧）'));
    var bulkControls = node('div', 'pattern-controls');
    var rowFrom = number(1, 1, config.rows), rowTo = number(config.rows, 1, config.rows);
    var colFrom = number(1, 1, config.cols), colTo = number(config.cols, 1, config.cols);
    var sub = select([['all', '全部 R/G/B'], ['R', 'R'], ['G', 'G'], ['B', 'B']], 'all');
    var ruleInput = select(Object.keys(RULES).map(function (key) { return [key, RULES[key]]; }), 'uniform');
    var bulk = number(Number(vals.VideoVoltage), undefined); bulk.removeAttribute('min'); bulk.step = 'any';
    var valueB = number(0, undefined); valueB.removeAttribute('min'); valueB.step = 'any';
    var sequenceInput = node('input'); sequenceInput.type = 'text'; sequenceInput.value = '5, 0, -5'; sequenceInput.placeholder = '例如 5, 0, -5';
    [['规律', ruleInput], ['起始行', rowFrom], ['结束行', rowTo], ['起始像素列', colFrom], ['结束像素列', colTo], ['子像素', sub]].forEach(function (pair) { bulkControls.appendChild(field(pair[0], pair[1])); });
    var aField = field('电压 A（V）', bulk), bField = field('电压 B（V）', valueB), seqField = field('电压序列（V）', sequenceInput);
    bulkControls.appendChild(aField); bulkControls.appendChild(bField); bulkControls.appendChild(seqField);
    function updateRuleFields() {
      var repeating = /Sequence$/.test(ruleInput.value);
      aField.hidden = repeating; bField.hidden = repeating || ruleInput.value === 'uniform'; seqField.hidden = !repeating;
    }
    ruleInput.onchange = updateRuleFields; updateRuleFields();
    var bulkMessage = node('p', 'pattern-error');
    var fill = button('应用规律', function () {
      var sequenceText = sequenceInput.value.trim();
      var rule = { kind: ruleInput.value, rowFrom: Number(rowFrom.value), rowTo: Number(rowTo.value), colFrom: Number(colFrom.value), colTo: Number(colTo.value), color: sub.value,
        a: bulk.value === '' ? NaN : Number(bulk.value), b: valueB.value === '' ? NaN : Number(valueB.value), sequence: sequenceText ? sequenceText.split(/[\s,，]+/).map(Number) : [] };
      try { applyRule(config, rule); }
      catch (error) { bulkMessage.textContent = error.message; return; }
      bulkMessage.textContent = ''; save(); refreshStatus(); drawGrid(); updatePreview();
    });
    bulkControls.appendChild(fill); bulkDetails.appendChild(bulkControls);
    bulkDetails.appendChild(node('p', 'pattern-help', '规律从所选区域左上角开始；隔列与棋盘格按像素列计算。'));
    bulkDetails.appendChild(bulkMessage); card.appendChild(bulkDetails);

    function changeFrame(which) {
      frame = which; if (frameInput) frameInput.value = which;
      drawGrid(); updatePreview();
    }
    function drawGrid() {
      frameButtons.forEach(function (btn) { var selected = btn.dataset.frame === frame; btn.classList.toggle('active', selected); btn.setAttribute('aria-pressed', String(selected)); });
      bulkDetails.hidden = frame === 'negative';
    }
    refreshStatus(); drawGrid();
    card.appendChild(node('h3', '', 'Video · Data 连接'));
    controls = node('div', 'pattern-controls');
    controls.appendChild(node('span', 'pattern-help', videos + ' 条 Video · ' + mux + 'mux · ' + config.dataColumns + ' 条 Data · ' + (config.wiring.grouping === 'custom' ? '自定义连接' : '默认隔列连接')));
    controls.appendChild(button('恢复默认连接', function () { config.wiring = {grouping:'interleaved',order:'forward'}; config.connectionEditorOpen = false; save(); rebuild(); }));
    card.appendChild(controls);
    var connectionMessage = node('p', 'pattern-error'); card.appendChild(connectionMessage);
    card.appendChild(node('p', 'pattern-help', 'AA 连接：' + (vals.Inversionmode === 'Zigzag' || vals.Inversionmode === 'Frame' ? 'Zigzag · 奇数行直连，偶数行左移一子列' : 'Column · 每行直连')));
    var allConnections = node('details', 'pattern-bulk connection-editor'); allConnections.open = !!config.connectionEditorOpen;
    allConnections.appendChild(node('summary', '', '自定义连接'));
    var editorMessage = node('div', 'connection-actions'); allConnections.appendChild(editorMessage);
    function dataNumber(target) { return target && target.pixel ? (Number(target.pixel)-1)*3+COLORS.indexOf(target.color)+1 : 0; }
    function setConnection(key, n, otherKey) {
      var old = map[key]; if (otherKey) map[otherKey] = old;
      map[key] = {pixel:Math.floor((n-1)/3)+1,color:COLORS[(n-1)%3]};
      config.wiring = {grouping:'custom',order:'custom'}; config.connectionEditorOpen = true; save(); rebuild();
    }
    var scroll = node('div', 'pattern-scroll'); var table = node('table', 'pattern-grid mapping-grid'), head = node('tr'); head.appendChild(node('th', '', 'Video 线'));
    for (var h = 1; h <= mux; h++) head.appendChild(node('th', '', 'CKH' + h)); table.appendChild(head);
    if (Number.isInteger(mux) && mux >= 1 && mux <= 16) {
      var map = config.maps[String(mux)] || {}; config.maps[String(mux)] = map;
      var used = {};
      for (var v = 1; v <= videos; v++) { var row = node('tr'); row.appendChild(node('th', '', 'Video' + v));
        for (var h = 1; h <= mux; h++) (function (video, channel) {
          var key = video + ':' + channel, target = map[key], td = node('td');
          var d = target && target.pixel ? (Number(target.pixel) - 1) * 3 + COLORS.indexOf(target.color) + 1 : '';
          var data = number(d || '',1,config.dataColumns); data.step = 1;
          data.setAttribute('aria-label', 'Video' + video + ' CKH' + channel + ' Data'); data.setAttribute('data-connection-key',key);
          if (d) { if (used[d]) connectionMessage.textContent = '存在重复 Data 连接，请检查。'; used[d] = true; }
          data.onchange = function () {
            var n = Number(data.value); editorMessage.innerHTML = '';
            if (!Number.isInteger(n) || n < 1 || n > config.dataColumns) {editorMessage.textContent='请输入 1～'+config.dataColumns+' 的 Data 编号。';data.value=d;return;}
            var otherKey = Object.keys(map).find(function(k){return k !== key && dataNumber(map[k]) === n;});
            if (!otherKey) {setConnection(key,n);return;}
            data.value=d;
            editorMessage.appendChild(node('span','', 'Data'+n+' 已连接到 Video'+otherKey.split(':')[0]+' / CKH'+otherKey.split(':')[1]+'。'));
            editorMessage.appendChild(button('交换这两路连接', function(){setConnection(key,n,otherKey);}));
            editorMessage.appendChild(button('取消', function(){editorMessage.innerHTML='';}));
          };
          td.appendChild(data);
          row.appendChild(td);
        })(v, h); table.appendChild(row);
      }
      if (videos * mux !== config.dataColumns && !connectionMessage.textContent) connectionMessage.textContent = '当前 Video × mux = ' + videos * mux + ' 个开关位，图像有 ' + config.dataColumns + ' 条 Data；末组超出范围的开关位保持未连接。';
    } else card.appendChild(node('p', 'pattern-error', '请先设置有效 CKHnum。'));
    var panelDrawing = node('div', 'panel-drawing'); card.appendChild(panelDrawing);
    var panelView = select([['full', '完整行数'], ['repeat', '最小重复单元']], 'full');
    frameControls.appendChild(field('示意图行数', panelView));
    card.insertBefore(panelDrawing,bulkDetails);
    card.insertBefore(metadataControls,bulkDetails);
    panelView.onchange = drawWiring;
    function repeatRows() {
      for (var n = 1; n < config.rows; n++) {
        var matches = true;
        for (var r = n + 1; r <= config.rows && matches; r++) for (var d = 1; d <= config.dataColumns; d++) {
          var pixel = Math.floor((d - 1) / 3) + 1, color = COLORS[(d - 1) % 3];
          if (JSON.stringify(aaTarget(vals,r,d,config.dataColumns)) !== JSON.stringify(aaTarget(vals,(r-1)%n+1,d,config.dataColumns)) || voltage(config, r, pixel, color) !== voltage(config, (r - 1) % n + 1, pixel, color)) { matches = false; break; }
        }
        if (matches) return n;
      }
      return config.rows;
    }
    function drawWiring() {
      panelDrawing.innerHTML = '';
      var drawRows = panelView.value === 'repeat' ? repeatRows() : config.rows;
      panelDrawing.appendChild(node('p', 'pattern-help', drawRows + ' 行 / 共 ' + config.rows + ' 行'));
      var ns = 'http://www.w3.org/2000/svg', step = 56, left = 82, width = Math.max(650, left + Math.max(config.dataColumns, videos * mux) * step + 50), switchTop = 150 + videos * mux * 5, gateTop = switchTop + 52, bottom = gateTop + mux * 26, rowHeight = 38, panelOffset = drawRows * rowHeight - 26;
      var svg = document.createElementNS(ns, 'svg'); svg.classList.add('pattern-connection-canvas'); svg.setAttribute('viewBox', '0 0 ' + width + ' ' + (bottom + 62 + panelOffset)); svg.style.width = width + 'px'; svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', 'RGB、Data、TFT、CKH 与 Video 面板连接示意图');
      function shape(tag, attrs, text) { var e = document.createElementNS(ns, tag); if (!attrs.transform) attrs.transform = 'translate(0 ' + panelOffset + ')'; Object.keys(attrs).forEach(function (k) { e.setAttribute(k, attrs[k]); }); if (text !== undefined) e.textContent = text; svg.appendChild(e); return e; }
      function line(x1, y1, x2, y2, color, w) { shape('line', {x1:x1,y1:y1,x2:x2,y2:y2,stroke:color,'stroke-width':w || 2}); }
      var brightnessMax=Math.max(1,Math.abs(Number(vals.VideoVoltage)||0));
      Object.keys(config.values).forEach(function(key){var v=Number(config.values[key]);if(Number.isFinite(v))brightnessMax=Math.max(brightnessMax,Math.abs(v));});
      function pixelFill(value,color){var amount=Math.min(1,Math.abs(Number(value)||0)/brightnessMax),gray=[85,93,104],rgb={R:[255,74,90],G:[97,220,112],B:[70,156,255]}[color];return 'rgb('+gray.map(function(n,i){return Math.round(n+(rgb[i]-n)*amount);}).join(',')+')';}
      for (var d = 1; d <= config.dataColumns; d++) {
        var x = left + (d - 1) * step, color = COLORS[(d - 1) % 3];
        shape('text',{x:x,y:18,'text-anchor':'middle',fill:{R:'#d72d40',G:'#238331',B:'#2469be'}[color],'font-size':14,'font-weight':700,transform:'translate(0 0)',class:'panel-column-color'},color);
        shape('text',{x:x,y:40,'text-anchor':'middle',fill:'#224d76','font-size':13,'font-weight':600,transform:'translate(0 0)',class:'panel-column-number'},d);
        for (var r = 1; r <= drawRows; r++) {
          var py = 52 + (r - 1) * rowHeight;
          var background=shape('rect', {x:x-16,y:py,width:32,height:32,rx:2,fill:pixelFill(voltage(config,r,Math.floor((d-1)/3)+1,color,frame),color),transform:'translate(0 0)',class:'panel-pixel-background','data-row':r,'data-subcolumn':d});
          (function(row, data, pixelX, pixelY, subColor, background) {
            var pixel = Math.floor((data-1)/3)+1, key=row+':'+pixel+':'+subColor;
            var val=voltage(config,row,pixel,subColor,frame);
            var box=shape('foreignObject',{x:pixelX-16,y:pixelY,width:32,height:32,transform:'translate(0 0)',class:'panel-voltage-cell','data-row':row,'data-subcolumn':data});
            var input=node('input','panel-voltage-input');input.type='number';input.step='any';input.value=val===null?'':Number(val.toFixed(6));input.readOnly=frame==='negative';
            input.setAttribute('aria-label',(frame==='negative'?'负帧':'正帧')+'第'+row+'行 第'+pixel+'列 '+subColor+'电压');
            input.setAttribute('aria-invalid',String(val===null));input.classList.toggle('modified',!!config.modified[key]);
            input.onclick=function(event){event.stopPropagation();};
            input.oninput=function(){var valid=input.value!==''&&input.checkValidity();input.setAttribute('aria-invalid',String(!valid));config.values[key]=valid?Number(input.value):'';config.modified[key]=true;config.custom=true;config.editor={kind:'manual'};input.classList.add('modified');background.setAttribute('fill',pixelFill(valid?Number(input.value):0,subColor));save();refreshStatus();};
            input.onchange=function(){updatePreview();};box.appendChild(input);
          })(r,d,x,py,color,background);
          shape('line',{x1:x-24,y1:py,x2:x-24,y2:py+rowHeight,stroke:'#1468af','stroke-width':2,transform:'translate(0 0)'});
          var aa = aaTarget(vals,r,d,config.dataColumns);
          if (aa) {
            var connection = shape('line',{x1:x-24,y1:py+16,x2:aa.subcolumn === d ? x-16 : x-step+16,y2:py+16,stroke:'#1468af','stroke-width':2,transform:'translate(0 0)',class:'aa-connection','data-row':r,'data-data':d,'data-subcolumn':aa.subcolumn});
            var tip = document.createElementNS(ns,'title');tip.textContent='第'+r+'行 · Data'+d+' → 第'+aa.pixel+'列 '+aa.color;connection.appendChild(tip);
          }
          if ((vals.Inversionmode === 'Zigzag' || vals.Inversionmode === 'Frame') && r % 2 === 0 && d === config.dataColumns) shape('rect',{x:x-17,y:py-1,width:34,height:34,fill:'none',stroke:'#8898aa','stroke-dasharray':'3 2',transform:'translate(0 0)',class:'aa-unconnected'});
          if (d === 1) shape('text',{x:8,y:py+16,fill:'#53728c','font-size':11,transform:'translate(0 0)'},'第'+r+'行');
        }
        shape('path',{d:'M '+(x-24)+' '+(52+drawRows*rowHeight)+' V '+(88+panelOffset)+' H '+x+' V '+(100+panelOffset),fill:'none',stroke:'#1468af','stroke-width':2,transform:'translate(0 0)'});
        shape('text', {x:x+7,y:104,'text-anchor':'start',fill:'#224d76','font-size':10}, 'Data' + d);
        line(x,100,x,120,'#1468af');
      }
      for (var h = 1; h <= mux; h++) { var y = gateTop + (h - 1) * 26;
        line(45,y,width-25,y,'#ec5396',5); shape('text',{x:8,y:y-7,fill:'#b72b70','font-size':12,'font-weight':700},'CKH'+h);
      }
      var routes = [], palette = ['#1864ab','#9c36b5','#087f5b','#d9480f','#5c7cfa','#a06116','#0b7285','#c2255c'];
      for (var rv = 1; rv <= videos; rv++) for (var rh = 1; rh <= mux; rh++) {
        var target = map[rv+':'+rh], data = target && target.pixel ? (Number(target.pixel)-1)*3+COLORS.indexOf(target.color)+1 : 0;
        if (data < 1 || data > config.dataColumns) continue;
        var index = (rv-1)*mux+rh-1;
        routes.push({key:rv+':'+rh, dx:left+(data-1)*step, x:left+index*step, track:128+index*5, color:palette[index%palette.length]});
      }
      routes.forEach(function(r) {
        var sourceOverlap = routes.some(function(o){return o !== r && (o.dx === r.dx || o.x === r.dx && o.track < r.track);});
        var sinkOverlap = routes.some(function(o){return o !== r && (o.x === r.x || o.dx === r.x && o.track > r.track);});
        r.start = r.dx - (sourceOverlap ? 8 : 0); r.end = r.x + (sinkOverlap ? 8 : 0);
      });
      function routePath(r) {
        if (r.dx === r.x && r.start === r.dx && r.end === r.x) return 'M '+r.dx+' 120 V '+switchTop;
        var start = r.start, end = r.end, direction = end >= start ? 1 : -1, crossings = [];
        routes.forEach(function(other) {
          if (other.key === r.key) return;
          [[other.start,other.start === other.dx ? 120 : 124,other.track],[other.end,other.track,other.end === other.x ? switchTop : switchTop-22]].forEach(function(seg) {
            if (r.track > seg[1] && r.track < seg[2] && seg[0] > Math.min(start,end)+5 && seg[0] < Math.max(start,end)-5) crossings.push(seg[0]);
          });
        });
        crossings = Array.from(new Set(crossings)).sort(function(a,b){return direction*(a-b);});
        var path = 'M '+r.dx+' 120'+(start === r.dx ? '' : ' V 124 H '+start)+' V '+r.track;
        crossings.forEach(function(cx){path += ' H '+(cx-direction*4)+' Q '+cx+' '+(r.track-4)+' '+(cx+direction*4)+' '+r.track;});
        return path+' H '+end+(end === r.x ? '' : ' V '+(switchTop-22)+' H '+r.x)+' V '+switchTop;
      }
      var connectionReadout = node('p', 'connection-readout', '点击开关上方标签或连线，突出显示该路连接。'); panelDrawing.appendChild(connectionReadout);
      for (var v = 1; v <= videos; v++) {
        var first = left + (v - 1) * mux * step, last = first + (mux - 1) * step, vy = bottom + 18;
        line(first,vy,last,vy,'#1d8b83',4); shape('text',{x:(first+last)/2,y:vy+25,'text-anchor':'middle',fill:'#18776f','font-size':14,'font-weight':700},'Video'+v);
        for (var h = 1; h <= mux; h++) {
          var x = first + (h - 1) * step, t = map[v + ':' + h], d = t && t.pixel ? (Number(t.pixel)-1)*3 + COLORS.indexOf(t.color)+1 : 0;
          var label = 'Video' + v + ' · CKH' + h + ' → ' + (d > 0 && d <= config.dataColumns ? 'Data' + d : '未连接');
          var route = null;
          if (d > 0 && d <= config.dataColumns) {
            var geometry = routes.find(function(r){return r.key === v+':'+h;});
            var path = routePath(geometry);
            route = shape('path',{d:path,fill:'none',stroke:geometry.color,'stroke-width':2.5,'stroke-linejoin':'round',class:'panel-route','data-color':geometry.color,'data-connection':label});
            shape('circle',{cx:geometry.dx,cy:120,r:3,fill:'#18202a'});
            shape('circle',{cx:x,cy:switchTop,r:3,fill:'#18202a'});
            var title = document.createElementNS(ns,'title'); title.textContent=label; route.appendChild(title);
          }
          var endpoint = shape('text',{x:x,y:switchTop-8,'text-anchor':'middle',fill:'#224d76','font-size':10,class:'panel-endpoint'}, (d ? 'D'+d : '未接'));
          endpoint.style.cursor = 'pointer'; endpoint.setAttribute('tabindex','0'); endpoint.setAttribute('role','button'); endpoint.setAttribute('aria-label',label);
          function focusConnection(route, endpoint, label, connectionKey) {
            return function (event) { if(event) event.stopPropagation(); svg.querySelectorAll('.panel-route').forEach(function (p) {p.setAttribute('stroke','#b5c9dc');p.setAttribute('stroke-width',2);}); svg.querySelectorAll('.panel-endpoint').forEach(function (p) {p.setAttribute('fill','#6f8498');});
              if (route) { route.setAttribute('stroke','#e97916'); route.setAttribute('stroke-width',4); svg.appendChild(route); }
              endpoint.setAttribute('fill','#bd5500'); connectionReadout.textContent=label;
              var selectedData=dataNumber(map[connectionKey]);
              svg.querySelectorAll('.aa-connection').forEach(function(p){p.setAttribute('stroke',Number(p.getAttribute('data-data'))===selectedData?'#e97916':'#1468af');});
              svg.querySelectorAll('.panel-voltage-cell').forEach(function(p){var target=aaTarget(vals,Number(p.getAttribute('data-row')),selectedData,config.dataColumns);p.style.outline=target&&target.subcolumn===Number(p.getAttribute('data-subcolumn'))?'2px solid #e97916':'';});
              allConnections.open = true; config.connectionEditorOpen = true;
              table.querySelectorAll('td').forEach(function(td){td.classList.remove('connection-selected');});
              var input = table.querySelector('[data-connection-key="'+connectionKey+'"]');
              if(input){input.parentElement.classList.add('connection-selected');input.focus({preventScroll:true});}
            };
          }
          var focus = focusConnection(route,endpoint,label,v+':'+h); endpoint.onclick=focus; endpoint.onkeydown=function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();this.onclick();}};
          if (route) { route.style.cursor='pointer';route.onclick=focus; }
          // TFT drain, channel, gate and source; CKH gate remains separate from Video source.
          line(x,switchTop,x,switchTop+10,'#1468af'); line(x,switchTop+10,x-10,switchTop+10,'#202d3a'); line(x-10,switchTop+10,x-10,switchTop+30,'#202d3a'); line(x-10,switchTop+30,x,switchTop+30,'#202d3a');
          line(x,switchTop+30,x,vy,'#1468af'); line(x-20,switchTop+9,x-20,switchTop+31,'#1468af',2);
          var gy = gateTop+(h-1)*26; shape('path',{d:'M '+(x-20)+' '+(switchTop+20)+' L '+(x-30)+' '+(switchTop+20)+' L '+(x-30)+' '+gy,fill:'none',stroke:'#1468af','stroke-width':2});
          shape('circle',{cx:x-30,cy:gy,r:4,fill:'#18202a'});
        }
      }
      function clearHighlight() {
        svg.querySelectorAll('.panel-route').forEach(function(p){p.setAttribute('stroke',p.getAttribute('data-color'));p.setAttribute('stroke-width',2.5);});
        svg.querySelectorAll('.panel-endpoint').forEach(function(p){p.setAttribute('fill','#224d76');});
        svg.querySelectorAll('.aa-connection').forEach(function(p){p.setAttribute('stroke','#1468af');});
        svg.querySelectorAll('.panel-voltage-cell').forEach(function(p){p.style.outline='';});
        connectionReadout.textContent='点击连线查看对应关系；点击空白处或按 Escape 取消高亮。';
      }
      svg.onclick=clearHighlight; svg.onkeydown=function(event){if(event.key==='Escape') clearHighlight();};
      panelDrawing.appendChild(svg);
      panelDrawing.appendChild(connectionReadout);
    }
    drawWiring();
    scroll.appendChild(table); allConnections.appendChild(scroll); card.appendChild(allConnections);
    save();
  }
  global.STGPattern = { prepare: prepare, presetValue: presetValue, applyRule: applyRule, describe: describe, voltage: voltage, sequence: sequence, preview: preview, aaTarget: aaTarget, render: render };
})(window);
