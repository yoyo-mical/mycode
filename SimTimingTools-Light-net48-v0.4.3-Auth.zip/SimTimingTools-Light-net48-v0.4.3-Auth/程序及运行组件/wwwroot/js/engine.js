// UI-only transport. Waveforms and timelines are calculated by the compiled C# core.
(function(global){
 'use strict';var pending=new Map(),next=0;
 function invoke(operation,values){return new Promise(function(resolve,reject){
  if(!global.chrome||!global.chrome.webview){reject(new Error('请通过启动工具打开。'));return;}
  var encoded=JSON.stringify(values);if(encoded.length>15*1024*1024){reject(new Error('参数规模过大，请减少图像行列数。'));return;}
  var id=String(++next),timer=setTimeout(function(){pending.delete(id);reject(new Error('核心计算响应超时，请减少生成规模后重试。'));},120000);
  pending.set(id,{resolve:resolve,reject:reject,timer:timer});
  global.chrome.webview.postMessage('core:'+JSON.stringify({id:id,operation:operation,values:encoded}));
 });}
 if(global.chrome&&global.chrome.webview)global.chrome.webview.addEventListener('message',function(e){var data=e.data;if(!data||typeof data!=='object'||data.type!=='core')return;var item=pending.get(data.id);if(!item)return;pending.delete(data.id);clearTimeout(item.timer);if(data.ok)item.resolve(data.result);else item.reject(new Error(data.error||'核心计算失败。'));});
 global.STGEngine={generateAll:function(values){return invoke('generate',values);},initTimeline:function(values){return invoke('timeline',values);}};
})(window);
